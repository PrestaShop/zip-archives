tinyMCE.addI18n('pl.paste_dlg',{
text_title:"U\u017Cyj skr\u00F3tu CTRL+V, aby wklei\u0107 tekst do okna.",
text_linebreaks:"Zachowaj ko\u0144ce linii.",
word_title:"U\u017Cyj skr\u00F3tu CTRL+V, aby wklei\u0107 tekst do okna."
});