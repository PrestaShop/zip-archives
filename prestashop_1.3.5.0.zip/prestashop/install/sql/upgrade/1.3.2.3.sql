SET NAMES 'utf8';

ALTER TABLE `PREFIX_state` CHANGE `iso_code` `iso_code` CHAR(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;
