<?php

global $_LANGADM;
$_LANGADM = array();
$_LANGADM['AdminEmails0c9c8983886a80c25ec49ced4a83c9d2'] = 'Send e-mail as HTML';
$_LANGADM['AdminEmails1d4f4376ecd104b52b7e805f7277f46e'] = 'Send e-mail as Text';
$_LANGADM['AdminEmailsc23370df50e7f5c6d161da0096b1dd9d'] = 'Test your e-mail configuration';
$_LANGADM['AdminEmailsf1251a7f9b3741c1be21596cc52f30b0'] = 'Send a e-mail test at:';
$_LANGADM['AdminEmails9b161d94627dcda71b2df1391107f00c'] = 'Send a e-mail test';
$_LANGADM['AdminGenerator8f106af7bcea3cc7150abc9519345ef3'] = 'This tool will automatically generate a \"robots.txt\" file that will grant you the possibility to deny access to search engines for some pages.';
$_LANGADM['AdminImport287234a1ff35a314b5b6bc4e5828e745'] = 'Combinations';
$_LANGADM['AdminModulesPositionsc89a9e08172e8c615c6d908fd3d982b5'] = 'Display non-positionable hook';
$_LANGADM['AdminStatuses0133c7a0fa55069df27f8d9be2c6ab89'] = 'Order statuses';
$_LANGADM['AdminStatusesdc0d0ea31daf9b78138943e8fd06e3a3'] = 'Order return statuses';
$_LANGADM['AdminTranslations228e51fac119b96085eae54fe69644f6'] = 'Error messages translations';

?>