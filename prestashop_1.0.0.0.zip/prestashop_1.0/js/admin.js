var id_language = Number(1);

function str2url(str,encoding,ucfirst)
{
	str = str.toUpperCase();
	str = str.toLowerCase();

	str = str.replace(/[\u00E0\u00E1\u00E2\u00E3\u00E4\u00E5]/g,'a');
	str = str.replace(/[\u00E7]/g,'c');
	str = str.replace(/[\u00E8\u00E9\u00EA\u00EB]/g,'e');
	str = str.replace(/[\u00EC\u00ED\u00EE\u00EF]/g,'i');
	str = str.replace(/[\u00F2\u00F3\u00F4\u00F5\u00F6\u00F8]/g,'o');
	str = str.replace(/[\u00F9\u00FA\u00FB\u00FC]/g,'u');
	str = str.replace(/[\u00FD\u00FF]/g,'y');
	str = str.replace(/[\u00F1]/g,'n');
	str = str.replace(/[\u0153]/g,'oe');
	str = str.replace(/[\u00E6]/g,'ae');
	str = str.replace(/[\u00DF]/g,'ss');

	str = str.replace(/[^a-z0-9\s\'\:\/\[\]-]/g,'');
	str = str.replace(/[\s\'\:\/\[\]-]+/g,' ');
	str = str.replace(/[ ]/g,'-');

	if (ucfirst == 1) {
		c = str.charAt(0);
		str = c.toUpperCase()+str.slice(1);
	}

	return str;
}

function strToAltImgAttr(str,encoding,ucfirst)
{
	str = str.replace(/[\u00E0\u00E1\u00E2\u00E3\u00E4\u00E5]/g,'a');
	str = str.replace(/[\u00E7]/g,'c');
	str = str.replace(/[\u00E8\u00E9\u00EA\u00EB]/g,'e');
	str = str.replace(/[\u00EC\u00ED\u00EE\u00EF]/g,'i');
	str = str.replace(/[\u00F2\u00F3\u00F4\u00F5\u00F6\u00F8]/g,'o');
	str = str.replace(/[\u00F9\u00FA\u00FB\u00FC]/g,'u');
	str = str.replace(/[\u00FD\u00FF]/g,'y');
	str = str.replace(/[\u00F1]/g,'n');
	str = str.replace(/[\u0153]/g,'oe');
	str = str.replace(/[\u00E6]/g,'ae');
	str = str.replace(/[\u00DF]/g,'ss');

	str = str.replace(/[^a-zA-Z0-9\s\'\:\/\[\]-]/g,'');
	str = str.replace(/[\s\'\:\/\[\]-]+/g,' ');

	if (ucfirst == 1) {
		c = str.charAt(0);
		str = c.toUpperCase()+str.slice(1);
	}

	return str;
}

function copy2friendlyURL()
{
	getE('link_rewrite_' + id_language).value = str2url(getE('name_' + id_language).value.replace(/^[0-9]+\./, ''), 'UTF-8');
}

function updateCurrentText(field, span)
{
	if (span)
		getE(span).innerHTML = getE(field).value;
	else
	{
		getE('current_product').innerHTML = getE(field).value;
		getE('current_product2').innerHTML = getE(field).value;
		getE('current_product3').innerHTML = getE(field).value;
		getE('current_product4').innerHTML = getE(field).value;
	}
}

function updateFriendlyURL()
{
	getE('link_rewrite_' + id_language).value = str2url(getE('link_rewrite_' + id_language).value,'UTF-8');
	getE('friendly-url').innerHTML = getE('link_rewrite_' + id_language).value;
}

function	showLanguages(id)
{
	getE('languages_' + id).style.display = 'block';
}

function	changeLanguage(field, fieldsString, id_language_new, iso_code)
{
	var fields = fieldsString.split('¤');
	for (var i = 0; i < fields.length; ++i)
	{
		getE(fields[i] + '_' + id_language).style.display = 'none';
		getE(fields[i] + '_' + id_language_new).style.display = 'block';
		getE('language_current_' + fields[i]).src = '../img/l/' + id_language_new + '.jpg';
	}
 	getE('languages_' + field).style.display = 'none';
	id_language = id_language_new;
}

function checkAll(pForm)
{
	for (i = 0, n = pForm.elements.length; i < n; i++)
	{
		var objName = pForm.elements[i].name;
		var objType = pForm.elements[i].type;
		if (objType = 'checkbox' && objName != 'checkme')
		{
			box = eval(pForm.elements[i]);
			box.checked = !box.checked;
		}
	}
}

function checkDelBoxes(pForm, boxName, parent)
{
	for (i = 0; i < pForm.elements.length; i++)
		if (pForm.elements[i].name == boxName)
			pForm.elements[i].checked = parent;
}

function getE(name)
{
	if (document.getElementById)
		var elem = document.getElementById(name);
	else if (document.all)
		var elem = document.all[name];
	else if (document.layers)
		var elem = document.layers[name];
	return elem;
}

function changeFormParam(pForm, url, gid)
{
	pForm.action = url;
	pForm.elements["groupid"].value = gid;
}

function addAccessory()
{
	var div = getE('divAccessories');
	var input = getE('inputAccessories');
	var name = getE('nameAccessories');
	var select = getE('selectAccessories');

	if (select.value == '0')
		return;
	var reg = new RegExp('\-', 'g');
	var cut = select.value.split(reg);

	// delete accessory selected from select options
	for(i=0;i<select.length;++i)
		if(select.options[i].selected == true)
			select.options[i] = null;
	
	select.selectedIndex = 0;

	var name = '';
	for (i=1; i<cut.length; i++)
		name += cut[i];

	input.value += cut[0] + '-';
	name.value += name + '¤';
	div.innerHTML += name + ' <span onclick="delAccessory(' + cut[0] + ');" style="cursor: pointer;"><img src="../img/admin/delete.gif" /></span><br />';
}

function delAccessory(id)
{
	var div = getE('divAccessories');
	var input = getE('inputAccessories');
	var name = getE('nameAccessories');

	var reg = new RegExp('-', 'g');
	var inputCut = input.value.split(reg);
	var reg2 = new RegExp('¤', 'g');
	var nameCut = name.value.split(reg2);

	input.value = '';
	name.value = '';
	div.innerHTML = '';

	for (var i = 0; i < inputCut.length; ++i)
		if (inputCut[i] && inputCut[i] != id)
		{
			input.value += inputCut[i] + '-';
			name.value += nameCut[i] + '¤';
			div.innerHTML += nameCut[i] + ' <span onclick="delAccessory(' + inputCut[i] + ');" style="cursor: pointer;"><img src="../img/admin/delete.gif" /></span><br />';
		}
}

function dontChange(srcText)
{
	if (srcText == '')
		return false;
	for (var i in search_texts)
		if (srcText == search_texts[i])
			return false;
	return true;
}

function queryType()
{
	var search_type = getE('bo_search_type').value;
	var bo_query = getE('bo_query');

	if (search_type == 1)
	{
		if (!dontChange(bo_query.value))
			bo_query.value = search_texts[0];
	}
	else if (search_type == 2)
	{
		if (!dontChange(bo_query.value))
			bo_query.value = search_texts[1];
	}
	else if (search_type == 3)
	{
		if (!dontChange(bo_query.value))
			bo_query.value = search_texts[2];
	}
}

function formSubmit(e, button)
{
	var key;

	key = window.event ? window.event.keyCode : e.which;
	if (key == 13)
	{
		getE(button).focus();
		getE(button).click();
	}
}

function	noComma(elem)
{
 	getE(elem).value = getE(elem).value.replace(new RegExp(',', 'g'), '.');
}

/* Help boxes */
function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      oldonload();
      func();
    }
  }
}

function helpboxParser(current) {
 	// While the span exists and we didn't find the right one
	for (var j = 0; j < current.parentNode.getElementsByTagName('span').length; j++) {

		// For each attribut
		for(var k = 0; k < current.parentNode.getElementsByTagName('span')[j].attributes.length; k++)
			// If it's the attribut "name" and its value is "help_box"
			if (current.parentNode.getElementsByTagName('span')[j].attributes[k].name === 'name' && current.parentNode.getElementsByTagName('span')[j].attributes[k].nodeValue === 'help_box') {
				// We finaly found it
				return j;
			}
	}
	return -1;
}

function prepareInputsForHints() {
	var inputs = document.getElementsByTagName('input');
	var found;

	// For each input
	for (var i=0; i<inputs.length; i++) {
		// on focus, show the hint
		inputs[i].onfocus = function () {
			var id = helpboxParser(this);
			if (id > -1)
				this.parentNode.getElementsByTagName('span')[id].style.display = 'inline';
		}
		// when the cursor moves away from the field, hide the hint
		inputs[i].onblur = function () {
		 	var id = helpboxParser(this);
		 	if (id > -1)
				this.parentNode.getElementsByTagName('span')[id].style.display = 'none';
		}
	}
}
if (helpboxes)
	addLoadEvent(prepareInputsForHints);

function changePic(id_product, id_image)
{
 	if (id_image == -1)
 	{
 		getE('pic').style.display = 'none';
 		return;
 	}
 	getE('pic').style.display = 'block';
	getE('pic').src = '../img/p/'+parseInt(id_product)+'-'+parseInt(id_image)+'.jpg';
}

/* Code generator for Affiliation and vourchers */
function gencode(size)
{
	getE('code').value = '';
	var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for (var i = 1; i <= size; ++i)
		getE('code').value += chars.charAt(Math.floor(Math.random() * chars.length));
}

function free_shipping()
{
	if (getE('id_discount_type').value == 3 && getE('discount_value').value == '')
		getE('discount_value').value = '0';
}

var newWin = null;

function closeWin ()
{
	if (newWin != null)
		if (!newWin.closed)
			newWin.close();
}

function openWin(url, title, width, height, top, left)
{
	var options;
	var sizes;

	closeWin();
	options = 'toolbar=0, location=0, directories=0, statfr=no, menubar=0, scrollbars=yes, resizable=yes';
	sizes = 'width='+width+', height='+height+', top='+top+', left='+left+'';
	newWin = window.open(url, title, options+', '+sizes);
	newWin.focus();
}

function	viewTemplates(id_select, id_lang, prefix, ext)
{
	var id_list = document.getElementById(id_select);
	var loc = id_list.options[id_list.selectedIndex].value;
	if (loc != 0)
		openWin (prefix+loc+ext, 'tpl_viewing', '520', '400', '50', '300');
	return ;
}

function validateImportation(mandatory)
{
    var type_value = [];
	var seted_value = [];
	var elem;
	var col = 'unknow';

	toggle(getE('error_duplicate_type'), false);
	toggle(getE('required_column'), false);
    for (i = 0; elem = getE('type_value['+i+']'); i++)
		if (seted_value[elem.options[elem.selectedIndex].value])
		{
			scroll(0,0);
			toggle(getE('error_duplicate_type'), true);
			return false;
		}
		else if (elem.options[elem.selectedIndex].value != 'no')
			seted_value[elem.options[elem.selectedIndex].value] = true;

	for (needed in mandatory)
		if (!seted_value[mandatory[needed]])
		{
			scroll(0,0);
			toggle(getE('required_column'), true);
			getE('missing_column').innerHTML = mandatory[needed];
			elem = getE('type_value[0]');
			for (i = 0; i < elem.length; ++i)
			{
				if (elem.options[i].value == mandatory[needed])
				{
					getE('missing_column').innerHTML = elem.options[i].innerHTML;
					break ;
				}
			}
			return false
		}
}


/* Manage default category on page: edit product */
function checkDefaultCategory(category_id)
{
	var oldCheckbox = $('.id_category_default');
	oldCheckbox.removeClass('id_category_default');
	var checkbox = $('#categoryBox_'+category_id);
	checkbox.attr('checked', 'checked');
	checkbox.addClass('id_category_default');
}

function chooseTypeTranslation(id_lang)
{
	getE('translation_lang').value = id_lang;
	document.getElementById('typeTranslationForm').submit();
}


function showDiv(select_id, while_id, dest)
{
	var select = document.getElementById(select_id);
	if (select.options[select.selectedIndex].value == while_id)
		return toggle(getE(dest), true);
	return toggle(getE(dest));
}

function orderDeleteProduct(txtConfirm, txtExplain)
{
	ret = true;
	$('table#orderProducts input[type=checkbox]:checked').each(
		function()
		{
			totalCancel = parseInt($(this).parent().parent().find('td.cancelQuantity input[type=text]').val());
			totalQty = parseInt($(this).parent().parent().find('td.productQuantity').text());
			productName = $(this).parent().parent().find('span.productName').text();
			
			if (totalCancel > totalQty)
			{
				alert(txtConfirm + ' : \'' + ' ' + productName + '\' ! \n\n' + txtExplain + ' ('+ totalCancel + ' > ' + totalQty +')' + '\n ');
				ret = false;
			}
		}
	);
	return ret;
}
