tinyMCE.addI18n('sk.paste_dlg',{
text_title:"Pou\u017Ei CTRL+V na kl\u00E1vesnici pre vlo\u017Eenie textu do okna.",
text_linebreaks:"Zachova\u0165 zalamovanie riadkov",
word_title:"Pou\u017Ei CTRL+V na kl\u00E1vesnici pre vlo\u017Eenie textu do okna."
});