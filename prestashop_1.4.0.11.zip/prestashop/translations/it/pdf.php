<?php

global $_LANGPDF;
$_LANGPDF = array();

?>