<?php

global $_FIELDS;
$_FIELDS = array();

?>