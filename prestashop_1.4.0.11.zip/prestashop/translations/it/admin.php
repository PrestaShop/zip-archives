<?php

global $_LANGADM;
$_LANGADM = array();

?>