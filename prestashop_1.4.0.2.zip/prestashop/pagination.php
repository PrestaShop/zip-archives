<?php

$controller = new FrontController();
$controller->pagination();

?>