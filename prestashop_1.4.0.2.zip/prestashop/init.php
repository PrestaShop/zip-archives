<?php

$controller = new FrontController();
$controller->init();

?>