<?php

global $_LANGPDF;
$_LANGPDF = array();
$_LANGPDF['submitTranslationsPdf'] = '1';

?>