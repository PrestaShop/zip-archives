<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Welcome!'] = 'Bienvenido !';
$_LANGMAIL['Message from contact form'] = 'Mensaje desde el formulario de contacto';
$_LANGMAIL['Your message has been correctly sent'] = '';
$_LANGMAIL['New credit slip regarding your order'] = '';
$_LANGMAIL['Virtual product to download'] = '';
$_LANGMAIL['Fwd: Customer message'] = '';
$_LANGMAIL['Your guest account has been transformed to customer account'] = '';
$_LANGMAIL['Package in transit'] = '';
$_LANGMAIL['Log: You have a new alert from your shop'] = '';
$_LANGMAIL['Order confirmation'] = 'Confirmacion de pedido';
$_LANGMAIL['Message from a customer'] = 'Mensaje de un cliente';
$_LANGMAIL['New message regarding your order'] = '';
$_LANGMAIL['Your order return state has changed'] = '';
$_LANGMAIL['Your password'] = 'Tu contrase�a';
$_LANGMAIL['Password query confirmation'] = '';
$_LANGMAIL['An answer to your message is available'] = '';
$_LANGMAIL['New voucher regarding your order'] = '';
$_LANGMAIL['Happy birthday!'] = '';
$_LANGMAIL['Newsletter confirmation'] = '';
$_LANGMAIL['Newsletter voucher'] = '';
$_LANGMAIL['Your wishlist\\\'s link'] = '';
$_LANGMAIL['Message from \').$customer->lastname.\' '] = '';
$_LANGMAIL[' $subject'] = '';
$_LANGMAIL['Your cart and your discount'] = 'Su cesta y su descuento';
$_LANGMAIL['Thanks for your order'] = 'Gracias por su pedido';
$_LANGMAIL['You are one of our best customers'] = 'Usted es uno de nuestros mejores clientes';
$_LANGMAIL['We miss you'] = 'Te extrañamos';
$_LANGMAIL['Product available'] = '';
$_LANGMAIL['Product out of stock'] = '';
$_LANGMAIL['Error reporting from your PayPal module'] = '';
$_LANGMAIL['Congratulations!'] = '';
$_LANGMAIL['Referral Program'] = '';
$_LANGMAIL['A friend sent you a link to\').\' '] = '';

?>