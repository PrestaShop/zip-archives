<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL[' \'Welcome!\''] = '';
$_LANGMAIL['Message from contact form'] = 'Message depuis le formulaire de contact';
$_LANGMAIL['Your message has been correctly sent'] = 'Votre message a bien été envoyé';
$_LANGMAIL['New credit slip regarding your order'] = 'Nouvel avoir concernant votre commande';
$_LANGMAIL['Virtual product to download'] = 'Produit virtuel à télécharger';
$_LANGMAIL[' \'Fwd: Customer message\''] = '';
$_LANGMAIL['Your guest account has been transformed to customer account'] = 'Votre compte invité a été transformé en compte client';
$_LANGMAIL[' ((is_array($_LANGMAIL) AND key_exists($subject'] = 'Livraison en cours';
$_LANGMAIL['Order confirmation'] = 'Confirmation de commande';
$_LANGMAIL['Message from a customer'] = 'Message d\'un client';
$_LANGMAIL['New message regarding your order'] = 'Nouveau message concernant votre commande';
$_LANGMAIL['Your order return state has changed'] = 'Nouveau statut de commande';
$_LANGMAIL['Your password'] = 'Votre nouveau mot de passe';
$_LANGMAIL['Password query confirmation'] = 'Confirmation de demande de mot de passe';
$_LANGMAIL['\'An answer to your message is available\''] = '';
$_LANGMAIL['New voucher regarding your order'] = 'Nouveau bon de réduction concernant votre commande';
$_LANGMAIL['Happy birthday!'] = 'Bon anniversaire !';
$_LANGMAIL['Newsletter confirmation'] = 'Confirmation newsletter';
$_LANGMAIL['Newsletter voucher'] = 'Bon de réduction newsletter';
$_LANGMAIL['Your wishlist\\\'s link'] = '';
$_LANGMAIL['Message from '] = 'Message de ';
$_LANGMAIL['Your cart and your discount'] = 'Votre panier et votre bon de réduction';
$_LANGMAIL['Thanks for your order'] = 'Merci pour votre commande';
$_LANGMAIL['You are one of our best customers'] = 'Vous êtes l\'un de nos meilleurs clients';
$_LANGMAIL['We miss you'] = 'Vous nous manquez';
$_LANGMAIL['Product available'] = 'Produit disponible';
$_LANGMAIL[' $this->l(\'Product out of stock\')'] = '';
$_LANGMAIL[' \'Error reporting from your PayPal module\''] = '';
$_LANGMAIL['Congratulations!'] = 'Bravo !';
$_LANGMAIL['Referral Program'] = 'Programme de parrainage';
$_LANGMAIL['A friend sent you a link to'] = 'Un ami vous a envoyé un lien vers';

?>