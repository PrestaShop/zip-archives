<?php

global $_LANGADM;
$_LANGADM = array();
$_LANGADM['AdminEmails0c9c8983886a80c25ec49ced4a83c9d2'] = 'Send e-mail as HTML';
$_LANGADM['AdminEmails1d4f4376ecd104b52b7e805f7277f46e'] = 'Send e-mail as Text';
$_LANGADM['AdminEmailsc23370df50e7f5c6d161da0096b1dd9d'] = 'Test your e-mail configuration';
$_LANGADM['AdminEmailsf1251a7f9b3741c1be21596cc52f30b0'] = 'Send a e-mail test at:';
$_LANGADM['AdminEmails9b161d94627dcda71b2df1391107f00c'] = 'Send a e-mail test';
$_LANGADM['AdminGenerator8f106af7bcea3cc7150abc9519345ef3'] = 'This tool will automatically generate a \"robots.txt\" file that will grant you the possibility to deny access to search engines for some pages.';
$_LANGADM['AdminImport287234a1ff35a314b5b6bc4e5828e745'] = 'Combinations';
$_LANGADM['AdminModulesPositionsc89a9e08172e8c615c6d908fd3d982b5'] = 'Display non-positionable hook';
$_LANGADM['AdminPerformancec925cc437c6aa8a943c19774b8a74059'] = 'High risk HTML compression';
$_LANGADM['AdminProducts0f317a01fd0c6c66853a02fa41b690ba'] = 'Click here to edit the unit prices';
$_LANGADM['AdminProducts32e5f5aa47b9eb6c3d5e1756ea603242'] = 'Unit price without tax:';
$_LANGADM['AdminProducts43b090faa8f69eaccffab8424f0eccd9'] = 'per unit';
$_LANGADM['AdminProducts179848d41777c5c5bd13bff5411c1eda'] = 'Minimum quantity:';
$_LANGADM['AdminProducts4c95c2e91f3ee35993bc3d9aacdaa501'] = 'The minimum quantity to buy this product (set to 1 to disable this feature)';
$_LANGADM['AdminStatuses0133c7a0fa55069df27f8d9be2c6ab89'] = 'Order statuses';
$_LANGADM['AdminStatusesdc0d0ea31daf9b78138943e8fd06e3a3'] = 'Order return statuses';

?>