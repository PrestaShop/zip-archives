<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statssales}prestashop>statssales_45c4b3e103155326596d6ccd2fea0f25'] = 'Ventas y pedidos';
$_MODULE['<{statssales}prestashop>statssales_09a6e97d1ccb13182c8fd316450dbebf'] = 'Mostrar la evolución de las ventas y de los pedidos por estados';
$_MODULE['<{statssales}prestashop>statssales_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Todos';
$_MODULE['<{statssales}prestashop>statssales_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtrar';
$_MODULE['<{statssales}prestashop>statssales_a252c24ec397a14367098b74b482d7a0'] = 'Estos gráficos representan la evolución de los pedidos y del volumen de ventas en un periodo dado. No son herramientas de análisis avanzadas pero le permiten ver la rentabilidad de su tienda inmediatamente. También puede observar variaciones en periodos concretos, como Navidad. Sólo los pedidos válidos se incluyen en estos gráficos. ';
$_MODULE['<{statssales}prestashop>statssales_0d6f98eca901ce80817bfe6a475fa45c'] = 'Total de pedidos realizados:';
$_MODULE['<{statssales}prestashop>statssales_4d2aaca86fca7a268ce7b6a512d68fd5'] = 'Total de pedidos realizados (válidos):';
$_MODULE['<{statssales}prestashop>statssales_667c4007914c8a5d3ffd9f704aea2c3b'] = 'Total de productos pedidos (pedidos válidos)';
$_MODULE['<{statssales}prestashop>statssales_ec3e48bb9aa902ba2ad608547fdcbfdc'] = 'Ventas:';
$_MODULE['<{statssales}prestashop>statssales_0718e1ec4754e199aa9cb4bc43a6ff53'] = 'Puede ver la distribución del estado del pedido a continuación.';
$_MODULE['<{statssales}prestashop>statssales_3991390ca135c8c780b4a7d9c7c7daf5'] = 'No hay pedidos para este periodo';
$_MODULE['<{statssales}prestashop>statssales_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statssales}prestashop>statssales_cc23e852e21d85a834defe24867e3d05'] = 'Varios estados de pedidos';
$_MODULE['<{statssales}prestashop>statssales_1ac658f97c9370fb579beca0d7277d56'] = 'En su Back office, hay varios estados de pedido disponibles: En espera de pago por cheque, Pago aceptado, Preparación en curso, Envío en curso, Enviado, Anulado, Reembolsado, Error en el pago, Productos no disponibles y en espera de pago por giro bancario.';
$_MODULE['<{statssales}prestashop>statssales_ba3224a4f47de7a622fa8e17236b01e3'] = 'estos estados no pueden suprimirse del back office, pero puede añadir otros nuevos.';
$_MODULE['<{statssales}prestashop>statssales_bb7ad89807bf69ddca986c142311f936'] = 'Productos y pedidos';
$_MODULE['<{statssales}prestashop>statssales_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Pedidos';
$_MODULE['<{statssales}prestashop>statssales_14f1c54626d722168ee62dff05ed811e'] = 'Ventas en';
$_MODULE['<{statssales}prestashop>statssales_33eee7690a8cd62490ed9eeadd47d163'] = 'Porcentaje de pedidos por estado';
