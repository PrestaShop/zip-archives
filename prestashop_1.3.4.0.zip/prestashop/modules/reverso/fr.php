<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{reverso}prestashop>reverso_86774f1550b9ad3cc207184b35afb514'] = 'ReversoForm';
$_MODULE['<{reverso}prestashop>reverso_1e9fcdadfd0ced6424c9692da9373fbf'] = 'Remplir le formulaire d\'authentification avec ReversoForm';
$_MODULE['<{reverso}prestashop>reverso_254f642527b45bc260048e30704edb39'] = 'Configuration';
$_MODULE['<{reverso}prestashop>reverso_3460276ef9eb483d13aa31b870077a0d'] = 'Numéro de série';
$_MODULE['<{reverso}prestashop>reverso_af53b10cb956fa2562af3c3fcd1c08f6'] = 'Adresse du site';
$_MODULE['<{reverso}prestashop>reverso_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_MODULE['<{reverso}prestashop>reverso_a67fe5b600cc617a0cc6f782b2b466e1'] = 'Configuration compte Reverso';
$_MODULE['<{reverso}prestashop>reverso_945ef080522eaee1f20529606281d2bf'] = 'Vous n\'avez pas de compte Reverso ?';
$_MODULE['<{reverso}prestashop>reverso_15e80d88e64872dffe151e5ba783270b'] = 'Enregistrez vous maintenant !';
$_MODULE['<{reverso}prestashop>reverso_88d543504a205e581ff03188b6abdc0b'] = 'Impossible de trouver ce numéro';
$_MODULE['<{reverso}prestashop>reverso_87094afb0ee64892a41b1f6acab60b02'] = 'Complétez automatiquement le formulaire avec votre numéro de téléphone';
