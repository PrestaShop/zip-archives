<pre>Array
(
    [currentFolderPath] => /media/host-1/img/cms/
    [new_folder] => test
)
</pre>

30/Jan/2014 14:34:27