<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_4f29d8c727dcf2022ac241cb96c31083'] = 'Aucun résultat';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_eab2b4237a7cd89c309119e35f62d168'] = 'Affichage de';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_8bf8854bebe108183caeb845c7676ae4'] = 'sur';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_12d3c7a4296542c62474856ec452c045'] = 'Ref.';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_bfc1bb98d808d46b4a1d234a0970d004'] = 'Qté';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_6771f2d557a34bd89ea7abc92a0a069c'] = 'Prix de vente';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'CA';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_999097243cf851ed681041eaa1ba2573'] = 'Qté / jour';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_57f32d7d0e6672cc2b60bc7a49f91453'] = 'Pages vues';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_27ce7f8b5623b2e2df568d64cf051607'] = 'Stock';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_71a5c322b7f69a8a4e40b3eb20da5559'] = 'Meilleurs produits';
$_MODULE['<{statsbestproducts}prestashop>statsbestproducts_1784296dda47f4d571a179aad8106018'] = 'Liste des meilleurs produits';
