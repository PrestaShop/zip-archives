tinyMCE.addI18n('tr.paste_dlg',{
text_title:"Pencereye metin yap\u0131\u015Ft\u0131rmak i\u00E7in CTRL+V tu\u015Funu kullan\u0131n\u0131z.",
text_linebreaks:"Sat\u0131r k\u0131r\u0131l\u0131mlar\u0131n\u0131 koru",
word_title:"Pencereye metin yap\u0131\u015Ft\u0131rmak i\u00E7in CTRL+V tu\u015Funu kullan\u0131n\u0131z."
});