<?php

include_once(PS_ADMIN_DIR.'/../classes/AdminTab.php');

class AdminSearch extends AdminTab
{
	/**
	* Search a specific string in the products and categories
	*
	* @params string $query String to find in the catalog
	*/
	public function searchCatalog($query)
	{
		global $cookie;

		$products = false;
		if (Validate::isCatalogName($query))
		{
			$this->_list['products'] = Product::searchByName(intval($cookie->id_lang), $query);
			if (!empty($this->_list['products']))
				for ($i = 0; $i < count($this->_list['products']); $i++)
					$this->_list['products'][$i]['nameh'] = str_ireplace($query, '<span class="highlight">'.$query.'</span>', $this->_list['products'][$i]['name']);
		}
		if (Validate::isCatalogName($query))
			$this->_list['categories'] = Category::searchByName(intval($cookie->id_lang), $query);
	}

	/**
	* Search a specific name in the customers
	*
	* @params string $query String to find in the catalog
	*/
	public function	searchCustomer($query)
	{
		$this->_list['customers'] = Customer::searchByName($query);
	}

	function postProcess()
	{
		/* Handle empty search field */
		if (!isset($_POST['bo_query']) OR empty($_POST['bo_query']) OR !isset($_POST['bo_search_type']))
		{
			echo '<h2>'.$this->l('Search results').'</h2>';
			$this->_errors[] = Tools::displayError('please fill in search form first');
		}
		else
		{
			/* Product research */
			if (intval($_POST['bo_search_type']) == 1)
			{
				$this->fieldsDisplay = (array(
					'id' => array('title' => $this->l('id')),
					'manufacturer' => array('title' => $this->l('Manufacturer')),
					'reference' => array('title' => $this->l('Reference')),
					'name' => array('title' => $this->l('Name')),
					'price' => array('title' => $this->l('Price')),
					'tax' => array('title' => $this->l('Tax')),
					'stock' => array('title' => $this->l('Stock')),
					'weight' => array('title' => $this->l('Weight')),
					'status' => array('title' => $this->l('Status')),
					'action' => array('title' => $this->l('Actions'))
				));
				$this->searchCatalog(trim(strval($_POST['bo_query'])));
			}

			/* Customer */
			elseif (intval($_POST['bo_search_type']) == 2)
			{
				$this->fieldsDisplay = (array(
					'id' => array('title' => $this->l('id')),
					'sex' => array('title' => $this->l('Sex')),
					'name' => array('title' => $this->l('Name')),
					'email' => array('title' => $this->l('email')),
					'birthdate' => array('title' => $this->l('Birth date')),
					'register_date' => array('title' => $this->l('Register date')),
					'addresses' => array('title' => $this->l('Addresses')),
					'orders' => array('title' => $this->l('Orders')),
					'newsletter' => array('title' => $this->l('Newsletter')),
					'opt-in' => array('title' => $this->l('Opt-in')),
					'status' => array('title' => $this->l('Status')),
					'actions' => array('title' => $this->l('Actions'))
				));
				/* Handle customer ID */
				if (intval($_POST['bo_query']) AND Validate::isUnsignedInt(intval($_POST['bo_query'])))
				{
					$customer = new Customer(intval($_POST['bo_query']));
					if ($customer->id)
						Tools::redirectAdmin('index.php?tab=AdminCustomers&id_customer='.intval($_POST['bo_query']).'&viewcustomer');
					else
						$this->_errors[] = Tools::displayError('customer #').intval($_POST['bo_query']).' '.Tools::displayError('not found');
				}
				/* Search customers by name */
				else
					self::searchCustomer($_POST['bo_query']);
			}

			/* Order */
			elseif (intval($_POST['bo_search_type']) == 3)
			{
				if (intval($_POST['bo_query']) AND Validate::isUnsignedInt(intval($_POST['bo_query'])))
				{
					$order = new Order(intval($_POST['bo_query']));
					if ($order->id)
						Tools::redirectAdmin('index.php?tab=AdminOrders&id_order='.intval($_POST['bo_query']).'&vieworder');
					else
						$this->_errors[] = Tools::displayError('order #').intval($_POST['bo_query']).' '.Tools::displayError('not found');
				}
				else
					$this->_errors[] = Tools::displayError('please type an order ID');
			}
			else
				Tools::displayError('please fill in search form first.');
		}
	}

	public function display()
	{
		$currentIndex = 'index.php';
		$currency = new Currency(Configuration::get('PS_CURRENCY_DEFAULT'));

		$query = isset($_POST['bo_query']) ? trim(strval($_POST['bo_query'])) : '';
		/* Display categories if any has been matching */
		if (isset($this->_list['categories']) AND $nbCategories = sizeof($this->_list['categories']))
		{
			echo '<h3>'.$nbCategories.' '.($nbCategories > 1 ? $this->l('categories found with') : $this->l('category found with')).' <b>"'.$query.'"</b></h3>';
			echo '
			<table cellspacing="0" cellpadding="0" class="table">';
			$irow = 0;
			foreach ($this->_list['categories'] AS $k => $category)
				echo '<tr class="'.($irow++ % 2 ? 'alt_row' : '').'"><td>'.rtrim(getPath($currentIndex.'?tab=AdminCatalog', $category['id_category'], '', $query), ' >').'</td></tr>';
			echo '</table><br /><br />';
		}
		else
			$nbCategories = 0;

		/* Display products if any has been matching */
		if (isset($this->_list['products']) AND !empty($this->_list['products']) AND $nbProducts = sizeof($this->_list['products']))
		{
			echo '<h3>'.$nbProducts.' '.($nbProducts > 1 ? $this->l('products found with') : $this->l('product found with')).' <b>"'.$query.'"</b></h3>
			<table class="table" cellpadding="0" cellspacing="0">
				<tr>';
			foreach ($this->fieldsDisplay AS $field)
				echo '<th'.(isset($field['width']) ? 'style="width: '.$field['width'].'"' : '').'>'.$field['title'].'</th>';
			echo '
				</tr>';
			foreach ($this->_list['products'] AS $k => $product)
			{
				echo '
				<tr>
					<td>'.$product['id_product'].'</td>
					<td align="center">'.($product['manufacturer_name'] != NULL ? stripslashes($product['manufacturer_name']) : '--').'</td>
					<td>'.$product['reference'].'</td>
					<td><a href="'.$currentIndex.'?tab=AdminCatalog&id_product='.$product['id_product'].'&addproduct">'.stripslashes($product['nameh']).'</a></td>
					<td>'.Tools::displayPrice($product['price'], $currency).'</td>
					<td>'.stripslashes($product['tax_name']).'</td>
					<td align="center">'.$product['quantity'].'</td>
					<td align="center">'.$product['weight'].' '.Configuration::get('PS_WEIGHT_UNIT').'</td>
					<td align="center"><a href="'.$currentIndex.'?tab=AdminCatalog&id_product='.$product['id_product'].'&status">
					<img src="../img/admin/'.($product['active'] ? 'enabled.gif' : 'forbbiden.gif').'" alt="" /></a></td>
					<td>
						<a href="'.$currentIndex.'?tab=AdminCatalog&id_product='.$product['id_product'].'&addproduct">
						<img src="../img/admin/edit.gif" alt="'.$this->l('Modify this product').'" /></a>&nbsp;
						<a href="'.$currentIndex.'?tab=AdminCatalog&id_product='.$product['id_product'].'&deleteproduct" onclick="return confirm(\''.addslashes($this->l('Do you want to delete').' '.$product['name']).' ?\');">
						<img src="../img/admin/delete.gif" alt="'.$this->l('Delete this product').'" /></a>
					</td>
				</tr>';
			}
			echo '</table>';
		}
		else
			$nbProducts = 0;

		/* Display customers if any has been matching */
		if (isset($this->_list['customer']) AND !empty($this->_list['products']) AND $nbCustomers = sizeof($customers))
		{
			echo '<h3>'.$nbCustomers.' '.($nbCustomers > 1 ? $this->l('customers') : $this->l('customer')).' '.$this->l('found with').' <b>"'.$query.'"</b></h3>
			<table cellspacing="0" cellpadding="0" class="table widthfull">
				<tr>';
			foreach ($this->fieldsDisplay AS $field)
				echo '<th'.(isset($field['width']) ? 'style="width: '.$field['width'].'"' : '').'>'.$field['title'].'</th>';
			echo '
				</tr>';
			$irow = 0;
			foreach ($this->_list['customers'] AS $k => $customer)
			{
				$imgGender = $customer['iso_code'] == 1 ? '<img src="../img/admin/male.gif" alt="'.lsearch('Male').'" />' : ($customer['iso_code'] == 2 ? '<img src="../img/admin/female.gif" alt="'.lsearch('Female').'" />' : '');
				$customerAddressTotal = Customer::getAddressesTotalById($customer['id_customer']);
				echo '
				<tr class="'.($irow++ % 2 ? 'alt_row' : '').'">
					<td>'.$customer['id_customer'].'</td>
					<td class="center">'.$imgGender.'</td>
					<td>'.stripslashes($customer['lastname']).' '.stripslashes($customer['firstname']).'</td>
					<td><a href="mailto:'.stripslashes($customer['email']).'">
					<img src="../img/admin/email_edit.gif" alt="'.$this->l('Write to this customer').'" /></a>
					'.stripslashes($customer['email']).'</td>
					<td>'.displayDate($customer['birthday']).'</td>
					<td>'.displayDate($customer['date_add']).'</td>
					<td class="center"><img src="../img/admin/employee.gif" alt="'.$this->l('Addresses').'" /> '.intval($customerAddressTotal).'</td>
					<td>'.Order::getCustomerNbOrders($customer['id_customer']).'</td>
					<td class="center"><img src="../img/admin/'.($customer['newsletter'] ? 'enabled.gif' : 'delete.gif').'" alt="" /></td>
					<td class="center"><img src="../img/admin/'.($customer['optin'] ? 'enabled.gif' : 'delete.gif').'" alt="" /></td>
					<td class="center"><img src="../img/admin/'.($customer['active'] ? 'enabled.gif' : 'forbbiden.gif').'" alt="" /></td>
					<td class="center" width="60px">
						<a href="'.$currentIndex.'?tab=AdminCustomers&id_customer='.$customer['id_customer'].'&viewcustomer">
						<img src="../img/admin/details.gif" alt="'.$this->l('View orders').'" /></a>
						<a href="'.$currentIndex.'?tab=AdminCustomers&id_customer='.$customer['id_customer'].'&addcustomer">
						<img src="../img/admin/edit.gif" alt="'.$this->l('Modify this customer').'" /></a>
						<a href="'.$currentIndex.'?tab=AdminCustomers&id_customer='.$customer['id_customer'].'&deletecustomer" onclick="return confirm(\''.addslashes($this->l('Are you sure?')).'\');">
						<img src="../img/admin/delete.gif" alt="'.$this->l('Delete this customer').'" /></a>
					</td>
				</tr>';
			}
			echo '</table>';
		}
		else
			$nbCustomers = 0;

		/* Display error if nothing has been matching */
		if (!$nbCategories AND !$nbProducts AND !$nbCustomers)
			echo '<h3>'.$this->l('Nothing found').'.</h3>';
	}
}

?>
