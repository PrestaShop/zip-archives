<?php

/**
  * Admin panel footer, footer.inc.php
  * @category admin
  *
  * @author PrestaShop <support@prestashop.com>
  * @copyright PrestaShop
  * @license http://www.opensource.org/licenses/osl-3.0.php Open-source licence 3.0
  * @version 1.0
  *
  */

if (!defined('_PS_VERSION_'))
	exit();
?>

				</div>
			</div>
			<p id="footer">
				Powered by <a href="http://www.prestashop.com/" target="_blank">PrestaShop&trade;</a>&nbsp;[&nbsp;<a href="http://www.prestashop.com/forum/" target="_blank">forum</a>&nbsp;&amp;&nbsp;<a href="http://www.prestashop.com/contact.php" target="_blank">contact</a>&nbsp;]
				- Version <?php echo _PS_VERSION_; ?>
				- <?php echo number_format(microtime(true) - $timerStart, 3, '.', ''); ?>s
			</p>
		</div>
	</body>
</html>