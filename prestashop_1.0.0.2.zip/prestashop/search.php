<?php

include(dirname(__FILE__).'/config/config.inc.php');
include(dirname(__FILE__).'/header.php');


/* Classic search */
if ($query = trim(Tools::getValue('search_query')))
{
	if (!Validate::isValidSearch($query))
		$smarty->assign('errors', array(Tools::displayError('invalid search')));
	else
	{
		$search = new Search();
		$nbProducts = intval($search->find(intval($cookie->id_lang), $query, true));
		include(dirname(__FILE__).'/pagination.php');
		$smarty->assign(array(
			'products' => $search->find(intval($cookie->id_lang), $query, false, $p, $n),
			'nbProducts' => $nbProducts,
			'query' => $query));
	}
}

/* Tags */
elseif ($tag = Tools::getValue('tag'))
{
	$search = new Search();
	$nbProducts = intval($search->tag(intval($cookie->id_lang), $tag, true));
	include(dirname(__FILE__).'/pagination.php');
	$smarty->assign(array(
		'tag' => $tag,
		'query' => $tag,
		'products' => $search->tag(intval($cookie->id_lang), $tag, false, $p, $n),
		'nbProducts' => $nbProducts));
}
else
{
	$smarty->assign('products', array());
	$smarty->assign('pages_nb', 1);
	$smarty->assign('nbProducts', 0);
}

$smarty->display(_PS_THEME_DIR_.'search.tpl');

include(dirname(__FILE__).'/footer.php');

?>