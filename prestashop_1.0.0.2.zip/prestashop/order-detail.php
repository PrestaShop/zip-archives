<?php

/* SSL Management */
$useSSL = true;

include(dirname(__FILE__).'/config/config.inc.php');
require_once(dirname(__FILE__).'/init.php');
$errors = array();

if (!$cookie->isLogged())
	Tools::redirect('authentication.php?back=history.php');

if (Tools::isSubmit('submitMessage'))
{
	$idOrder = Tools::getValue('id_order');
	$msgText = Tools::getValue('msgText');
	
	if (!isset($idOrder) OR !Validate::isUnsignedId($idOrder))
		$errors[] = Tools::displayError('order is no longer valid');
	elseif (empty($msgText))
		$errors[] = Tools::displayError('message cannot be blank');
	elseif (!Validate::isMessage($msgText))
		$errors[] = Tools::displayError('message is not valid (HTML is not allowed)');
	if(!sizeof($errors))
	{
	 	$order = new Order(intval($idOrder));
	 	if (Validate::isLoadedObject($order) AND $order->id_customer == $cookie->id_customer)
	 	{
			$message = new Message();
			$message->id_customer = intval($cookie->id_customer);
			$message->message = $msgText;
			$message->id_order = intval($idOrder);
			$message->private = false;
			$message->add();
			$to = strval(Configuration::get('PS_SHOP_EMAIL'));
			$toName = strval(Configuration::get('PS_SHOP_NAME'));
			$customer = new Customer(intval($cookie->id_customer));
			if (Validate::isLoadedObject($customer))
				Mail::Send(intval($cookie->id_lang), 'order_customer_comment', 'Message from a customer', 
				array(
				'{lastname}' => $customer->lastname, 
				'{firstname}' => $customer->firstname, 
				'{id_order}' => $message->id_order, 
				'{message}' => $message->message),
				$to, $toName, $customer->email, $customer->firstname.' '.$customer->lastname);
			if (Tools::getValue('ajax') != 'true')
				Tools::redirect('order-detail.php?id_order='.intval($idOrder));
		}
		else
		{
			$errors[] = Tools::displayError('order not found');
		}
	}
}

if (!isset($_GET['id_order']) OR !Validate::isUnsignedId($_GET['id_order']))
	$errors[] = Tools::displayError('order ID is required');
else
{
	$order = new Order(intval($_GET['id_order']));	
	if (Validate::isLoadedObject($order) AND $order->id_customer == $cookie->id_customer)
	{
		$id_order_state = intval($order->getCurrentState());
		$carrier = new Carrier(intval($order->id_carrier), intval($order->id_lang));
		if ($order->total_discounts > 0)
		    $smarty->assign('total_old', floatval($order->total_paid - $order->total_discounts));
	
		$smarty->assign(array(
			'order' => $order,
			'currency' => new Currency($order->id_currency),
			'order_state' => intval($id_order_state),
			'invoice' => OrderState::invoiceAvailable(intval($id_order_state)),
			'order_history' => $order->getHistory(intval($cookie->id_lang)),
			'products' => $order->getProducts(),
			'discounts' => $order->getDiscounts(),
			'carrier' => $carrier,
			'address_invoice' => new Address(intval($order->id_address_invoice)),
			'address_delivery' => new Address(intval($order->id_address_delivery)),
			'messages' => Message::getMessagesByOrderId(intval($order->id), true)));
		if ($carrier->url AND $order->shipping_number)
			$smarty->assign('followup', str_replace('@', $order->shipping_number, $carrier->url));
	}
	else
	{
		$errors[] = Tools::displayError('cannot find this order');
	}
}

$smarty->assign('errors', $errors);
if (Tools::getValue('ajax') == 'true')
{
	$smarty->display(_PS_THEME_DIR_.'order-detail.tpl');
}
else
{
	include(dirname(__FILE__).'/header.php');
	$smarty->display(_PS_THEME_DIR_.'order-detail.tpl');
	include(dirname(__FILE__).'/footer.php');
}

?>
