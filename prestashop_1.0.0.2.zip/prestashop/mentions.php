<?php

include(dirname(__FILE__).'/config/config.inc.php');
include(dirname(__FILE__).'/header.php');

$smarty->assign('conf', array_map(array('Tools','safeOutput'), Configuration::getMultiple(array('PS_SHOP_NAME', 'PS_SHOP_ADDR1', 'PS_SHOP_ADDR2', 'PS_SHOP_CODE', 'PS_SHOP_CITY', 'PS_SHOP_COUNTRY'))));
$smarty->display(_PS_THEME_DIR_.'mentions.tpl');

include(dirname(__FILE__).'/footer.php');

?>