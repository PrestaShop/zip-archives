//show the order-details with ajax
function showOrder(id_order){
	$.get(
		baseDir + "order-detail.php",
		{id_order: id_order, ajax: true},
		function(data){
			$('#block-order-detail').fadeOut('slow', function() {
				$(this).html(data);
				
				//catch the submit event of sendOrderMessage form
				$('form#sendOrderMessage').submit(function(){
					return sendOrderMessage();
				});
				
				$(this).fadeIn('slow');
			});
			
		}
	);
}

//send a message in relation to the order with ajax
function sendOrderMessage (){
	paramString = "ajax=true";
	$('form#sendOrderMessage').find('input, textarea').each(function(){
		paramString += '&' + $(this).attr('name') + '=' + $(this).val();
	});
	$.ajax({
		type: "GET",
		url: baseDir + "order-detail.php",
		data: paramString,
		success: function(msg){
			$('#block-order-detail').fadeOut('slow', function() {
				$(this).html(msg);
				//catch the submit event of sendOrderMessage form
				$('form#sendOrderMessage').submit(function(){
					return sendOrderMessage();
				});

				$(this).fadeIn('slow');
			});			
		}
	});
	return false;
}
