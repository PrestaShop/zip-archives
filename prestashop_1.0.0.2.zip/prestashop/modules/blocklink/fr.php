<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklink}prestashop>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Bloc liens';
$_MODULE['<{blocklink}prestashop>blocklink_96d999e6e6aa28eb520d4273e8da8eea'] = 'Ajoute un bloc avec des liens additionnels';
$_MODULE['<{blocklink}prestashop>blocklink_fe3f38c46c80813d94b6775299e59f13'] = 'Vous devez remplir l\'ensemble des champs';
$_MODULE['<{blocklink}prestashop>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'Mauvaise URL';
$_MODULE['<{blocklink}prestashop>blocklink_c95df8ad4297e9cb6bc0019e4462ddbb'] = 'Le lien a été ajouté avec succès';
$_MODULE['<{blocklink}prestashop>blocklink_7a2bf0efa79ed479a71cb42f43ded325'] = 'Une erreur est survenue lors de la création du lien';
$_MODULE['<{blocklink}prestashop>blocklink_1273b5375e3f183e84f5d9ffb6b198a2'] = 'Une erreur est survenue lors de la mise à jour du lien';
$_MODULE['<{blocklink}prestashop>blocklink_a9ab0ddae6fc226287f528411cc83396'] = 'Le lien a été mis à jour avec succès';
$_MODULE['<{blocklink}prestashop>blocklink_8e49763b0be4b758960b153dfe8b8052'] = 'The champs \"titre\" ne peut être laissé vide.';
$_MODULE['<{blocklink}prestashop>blocklink_1464bf989ae8160fae8d9425913c0057'] = 'Le champs \'\'url\' est invalide.';
$_MODULE['<{blocklink}prestashop>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'Le titre est invalide';
$_MODULE['<{blocklink}prestashop>blocklink_75db1048fa2d4862710d04c7e08a3484'] = 'Une erreur est survenue lors de la mise à jour du titre';
$_MODULE['<{blocklink}prestashop>blocklink_b34eed9974e03b40600d8e2ba12e50fa'] = 'Le titre du bloc a été mis à jour avec succès';
$_MODULE['<{blocklink}prestashop>blocklink_b505bd74ce8e725a6872589a7c4e7263'] = 'Une erreur est survenue lors de la suppression du lien';
$_MODULE['<{blocklink}prestashop>blocklink_4475056d7e1ad8864a01a9c952447c15'] = 'Le lien a été supprimé avec succès';
$_MODULE['<{blocklink}prestashop>blocklink_389b3acba9645372ff52bdb40b373131'] = 'Ordre de tri mis à jour avec succès';
$_MODULE['<{blocklink}prestashop>blocklink_c8316bfce0a265eab0dc99ae4a749888'] = 'Une erreur est survenue lors du changement de l\'ordre de tri';
$_MODULE['<{blocklink}prestashop>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Ajouter un nouveau lien';
$_MODULE['<{blocklink}prestashop>blocklink_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Texte :';
$_MODULE['<{blocklink}prestashop>blocklink_3b3d06023f6353f8fd05f859b298573e'] = 'URL :';
$_MODULE['<{blocklink}prestashop>blocklink_1f3674ab0d54a38327e8e4a0d97788d4'] = 'Ouvrir nouvelle fenêtre :';
$_MODULE['<{blocklink}prestashop>blocklink_7f3ee1818e42cfd668e361d89b8595fb'] = 'Ajouter ce lien';
$_MODULE['<{blocklink}prestashop>blocklink_27a5ff9957ea16466ef085b53381e26a'] = 'Editer ce lien';
$_MODULE['<{blocklink}prestashop>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Titre du bloc';
$_MODULE['<{blocklink}prestashop>blocklink_2c906769e7f8b03cc1fedce4e24a20c2'] = 'Titre du bloc :';
$_MODULE['<{blocklink}prestashop>blocklink_67c94c1cba852f2d13eed115c938baf6'] = 'URL du bloc :';
$_MODULE['<{blocklink}prestashop>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_MODULE['<{blocklink}prestashop>blocklink_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuration';
$_MODULE['<{blocklink}prestashop>blocklink_53db43446b84dd2e9ddac626fc02ead3'] = 'Trier la liste :';
$_MODULE['<{blocklink}prestashop>blocklink_d36e9f57ea37903f81d28f7a189b9649'] = 'par liens les plus récents';
$_MODULE['<{blocklink}prestashop>blocklink_6ccdff04699ffe6956a6b1465907414a'] = 'les premiers liens entrés';
$_MODULE['<{blocklink}prestashop>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Liste de lien';
$_MODULE['<{blocklink}prestashop>blocklink_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blocklink}prestashop>blocklink_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Texte';
$_MODULE['<{blocklink}prestashop>blocklink_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklink}prestashop>blocklink_06df33001c1d7187fdd81ea1f5b277aa'] = 'Actions';
$_MODULE['<{blocklink}prestashop>blocklink_fa83ae80c36586f0bc221f15784c5d5c'] = 'Il n\'y a pas encore de liens';

?>