<?php

class BlockVariousLinks extends Module
{
	function __construct()
	{
		$this->name = 'blockvariouslinks';
		$this->tab = 'Blocks';
		$this->version = 0.1;

		parent::__construct(); // The parent construct is required for translations

		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('Miscellaneous links block');
		$this->description = $this->l('Displays miscellaneous links (generally in footer)');
	}

	function install()
	{
		if (!parent::install())
			return false;
		if (!$this->registerHook('footer'))
			return false;
		return true;
	}

	/**
	* Returns module content
	*
	* @param array $params Parameters
	* @return string Content
	*/
	function hookFooter($params)
	{
		return $this->display(__FILE__, 'blockvariouslinks.tpl');
	}

}

?>
