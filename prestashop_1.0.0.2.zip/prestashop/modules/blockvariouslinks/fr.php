<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_549b3ed89aa5d9caf731babe6f498cfb'] = 'Bloc liens divers';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_29bb2b1824eb758128d5abce02e15d4b'] = 'Affiche des liens dans le pied de page';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_d1aa22a3126f04664e0fe3f598994014'] = 'Promotions';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveaux produits';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez nous';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_a10a9bcd450087de1ce1f80b35f44883'] = 'Mentions légales';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_229eb04083e06f419f9ac494329f957d'] = 'Conditions d\'utilisation';
$_MODULE['<{blockvariouslinks}prestashop>blockvariouslinks_7a52e36bf4a1caa031c75a742fb9927a'] = 'Propulsé par';

?>