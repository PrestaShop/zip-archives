<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}prestashop>blockadvertising_fd4c71c948857cce596a69fbaea7426b'] = 'Bloc publicité';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_2c6706322b2b9f670251533d907d2bbc'] = 'Ajoute un bloc affichant une publicité';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_2ce5fc289845ce826261032b9c6749ea'] = 'Publicité';

?>