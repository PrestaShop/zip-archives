<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mailalerts}prestashop>mailalerts_fd30254803e8db32521d3390131a44da'] = 'Alertes email';
$_MODULE['<{mailalerts}prestashop>mailalerts_ab4b19c3e9db97c21357d9c23a053e38'] = 'Envoi des e-mails au marchand lorsqu\'une commande est validée';
$_MODULE['<{mailalerts}prestashop>mailalerts_a9199a42a34f3a6004c9cd2cb268c10f'] = 'Aucune réduction';
$_MODULE['<{mailalerts}prestashop>mailalerts_4c9120f1a5947445c0e9620254ceb30b'] = 'Nouvelle commande';
$_MODULE['<{mailalerts}prestashop>mailalerts_644f9c907ef5a8315916bd1e2f61f783'] = 'Rupture de stock';
$_MODULE['<{mailalerts}prestashop>mailalerts_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour';
$_MODULE['<{mailalerts}prestashop>mailalerts_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuration';
$_MODULE['<{mailalerts}prestashop>mailalerts_898666bd9212d29c2848ce0dfd9165e9'] = 'Recevoir des alertes';
$_MODULE['<{mailalerts}prestashop>mailalerts_32c7bf1822115a70a76cb818ea65ec7e'] = 'Alerte lors d\'une nouvelle commande';
$_MODULE['<{mailalerts}prestashop>mailalerts_0bdf18fef8b9c3e18ecb111427fc7642'] = 'Alerte lors d\'une rupture de stock';
$_MODULE['<{mailalerts}prestashop>mailalerts_4c3c81fd56b02829a5a1cf953396cd55'] = 'Adresses e-mails';
$_MODULE['<{mailalerts}prestashop>mailalerts_2d085869166439734e6e7274bdad3f26'] = 'Ex : bob@example.com';
$_MODULE['<{mailalerts}prestashop>mailalerts_c888438d14855d7d96a2724ee9c306bd'] = 'Configuration mise à jour';
$_MODULE['<{mailalerts}prestashop>mailalerts_4047b7efafb2b501e8f402f864ee386c'] = 'Aucune adresse e-mail n\'a été spécifiée';
$_MODULE['<{mailalerts}prestashop>mailalerts_954d9f1f83672ba47f1c65c27910313b'] = 'Adresse e-mail invalide :';

?>