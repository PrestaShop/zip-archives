<?php

class BlockMyAccount extends Module
{
	public function __construct()
	{
		$this->name = 'blockmyaccount';
		$this->tab = 'Blocks';
		$this->version = 1.0;

		/* The parent construct is required for translations */
		parent::__construct();

		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('My Account block');
		$this->description = $this->l('Displays a block with links relative to user account');
	}

	function install()
	{
		if (!parent::install() OR !$this->registerHook('leftColumn'))
			return false;
		return true;
	}

	function hookLeftColumn($params)
	{
		if (!$params['cookie']->isLogged())
			return false;
		global $smarty;
		$smarty->assign('voucherAllowed', intval(Configuration::get('PS_VOUCHERS')));
		return $this->display(__FILE__, $this->name.'.tpl');
	}

	function hookRightColumn($params)
	{
		return $this->hookLeftColumn($params);
	}

}

?>
