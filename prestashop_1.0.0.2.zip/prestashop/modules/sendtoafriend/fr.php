<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sendtoafriend}prestashop>product_page_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Envoyer à un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2074615eb70699e55b1f9289c6c77c25'] = 'Module envoyer à un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_b6835a400c888d666e6e5aee9f2a7bc6'] = 'Permet à vos clients d\'envoyer des liens à leurs amis';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_c5f09f37e1e182ec28fa64732d9b712c'] = 'Retour à';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_c38f24359344dada5d54e7eef08de8bb'] = 'Vous devez remplir tous les champs.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_47f11ea69ec3161cab7c3434290efc8a'] = 'L\'email de votre ami est invalide.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_97d4e28297c641ed0dbe3f0172f17fa6'] = 'Le nom de votre ami est invalide.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_c029b957c5cfa940881e4a29f12add4c'] = 'Une erreur est survenu lors de l\'envoi.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_22c4733a9ceb239bf825a0cecd1cfaec'] = 'Un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_70b133fd251d38f98e7d94d54ea06314'] = 'vous envoi un liens vers';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_7658669075a2cccabef076d2d41a7742'] = 'Une erreur est survenu lors de l\'envoi.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_af7ad7a1e379f72b06c2e8d8bd6356ec'] = 'Un email vient d\'être envoyé à';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Envoyer à un ami';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_20589174124c25654cac3736e737d2a3'] = 'Envoyer cette page à un ami succeptible d\'être interessé par le produit ci-dessous';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_cc5fd9b9f1cad59fcff97a1f21f34304'] = 'Envoyer un message';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_19d305aea0ccec77d23362111ebdb6b4'] = 'Nom de votre ami :';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_7ae8a9a7a5d8fa40d4515fc52f16bb2e'] = 'Email de votre ami :';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2541d938b0a58946090d7abdde0d3890'] = 'envoyer';

?>