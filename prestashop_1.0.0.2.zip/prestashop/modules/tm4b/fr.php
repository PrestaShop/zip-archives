<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tm4b}prestashop>tm4b_fce86d40d5cb31bf5118f4bdc7f331c0'] = 'Envoyer un SMS à chaque nouvelle commande';
$_MODULE['<{tm4b}prestashop>tm4b_0c478a7069ab13f446e9e765cffd1550'] = 'Message bien envoyé';
$_MODULE['<{tm4b}prestashop>tm4b_0cda570a27de3fbd0940da019f759721'] = 'Erreur lors de l\'envoie du message';
$_MODULE['<{tm4b}prestashop>tm4b_884b60418e2f1f9a6a40f12e8ca0a64d'] = 'Identifiant et numéro de téléphone';
$_MODULE['<{tm4b}prestashop>tm4b_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{tm4b}prestashop>tm4b_8b58aafd28dcaee7f6e92442c96e31db'] = 'Envoyer un SMS de test :';
$_MODULE['<{tm4b}prestashop>tm4b_43e9e66e3a7acefd0663287c95acd407'] = 'Entrez votre numéro de téléphonne';
$_MODULE['<{tm4b}prestashop>tm4b_35ba634a7df95f937550c54b7b94d2c5'] = 'ex: 33642424242';
$_MODULE['<{tm4b}prestashop>tm4b_2e1779891f69b099b16616ae7ea2e76c'] = 'Crédits SMS :';
$_MODULE['<{tm4b}prestashop>tm4b_00db7aae85aecb79c75afca7daa8f22e'] = 'Vous avez';
$_MODULE['<{tm4b}prestashop>tm4b_928735d6f2c63bee316dd511c8ccaf55'] = 'crédits';
$_MODULE['<{tm4b}prestashop>tm4b_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{tm4b}prestashop>tm4b_cac81c648846c9b8c3e6085a45782c7e'] = 'Identifiant :';
$_MODULE['<{tm4b}prestashop>tm4b_b341a59d5636ed3d6a819137495b08a0'] = 'Mot de passe :';
$_MODULE['<{tm4b}prestashop>tm4b_6c47d739c79e0f93ec0cd90663a68ebf'] = 'Relaie :';
$_MODULE['<{tm4b}prestashop>tm4b_43e7396afc9f4633157a47bf5f5af96c'] = 'Numéro de téléphone de l\'expéditeur du SMS';
$_MODULE['<{tm4b}prestashop>tm4b_1ee1c44c2dc81681f961235604247b81'] = 'Mode :';
$_MODULE['<{tm4b}prestashop>tm4b_4f502b57d2835715eaa382c7d4c32e94'] = 'Simulation';
$_MODULE['<{tm4b}prestashop>tm4b_756d97bb256b8580d4d71ee0c547804e'] = 'Production';
$_MODULE['<{tm4b}prestashop>tm4b_ea24be6a78dd661afe60448e87b75065'] = 'Alerter lors de nouvelles commandes :';
$_MODULE['<{tm4b}prestashop>tm4b_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{tm4b}prestashop>tm4b_cca3b493c2bf4e51982b263ecc65ef50'] = 'Envoie un SMS si une nouvelle commande est fakite';
$_MODULE['<{tm4b}prestashop>tm4b_ff914fecb4b37bd6edb2e4515ec1d4dc'] = 'Alerter sur la quantité des produits :';
$_MODULE['<{tm4b}prestashop>tm4b_6be6362559125c3f97fb4a9fb06a0874'] = 'Envoie un SMS si la quantité des produits est mise à jour';
$_MODULE['<{tm4b}prestashop>tm4b_481bfc100d0a3590edb72f53679e310c'] = 'Numéro de téléphone du destinataire du SMS';
$_MODULE['<{tm4b}prestashop>tm4b_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour les informations';
$_MODULE['<{tm4b}prestashop>tm4b_c888438d14855d7d96a2724ee9c306bd'] = 'Informations mises à jour';
$_MODULE['<{tm4b}prestashop>tm4b_b1a293b0efa4e1e7c35ef375c3cd7a44'] = 'Identifiant obligatoire';
$_MODULE['<{tm4b}prestashop>tm4b_8c194fef39e0d251494686926884733e'] = 'Mot de passe obligatoire';
$_MODULE['<{tm4b}prestashop>tm4b_6ac6840e86a7b09bf9eb326228060981'] = 'Route obligatoire';
$_MODULE['<{tm4b}prestashop>tm4b_486493b98a473ebb777dd86bbf264e06'] = 'Origine obligatoire';
$_MODULE['<{tm4b}prestashop>tm4b_30c94c563402b0a87e4b5411518ab542'] = 'Mode obligatoire';
$_MODULE['<{tm4b}prestashop>tm4b_aea21c9ea4f10d22071eb479eee918c3'] = 'Merci d\'entrer un numéro de téléphone';
$_MODULE['<{tm4b}prestashop>tm4b_713569f69019a591adfda481f6668a06'] = 'Numéro de téléphone invalide';

?>