<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{editorial}prestashop>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Editeur de page d\'accueil';
$_MODULE['<{editorial}prestashop>editorial_1051bed4568ad9936781f20fb0536509'] = 'Un éditeur de texte pour votre page d\'accueil';
$_MODULE['<{editorial}prestashop>editorial_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Impossible d\'écrire dans le fichier XML. Merci de vérifier les permissions en écriture.';
$_MODULE['<{editorial}prestashop>editorial_8072bc856691062b88d30354ab28a27a'] = 'Impossible de refermer le fichier XML. Merci de vérifier les permissions en écriture.';
$_MODULE['<{editorial}prestashop>editorial_93314199c1f5be182040fd88370f44f4'] = 'Impossible de mettre à jour le fichier XML. Merci de vérifier les permissions en écriture.';
$_MODULE['<{editorial}prestashop>editorial_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Une erreur est survenue lors de l\'upload de l\'image';
$_MODULE['<{editorial}prestashop>editorial_eec34a41e732e39809721bab40e601cd'] = 'Votre fichier XML est vide.';
$_MODULE['<{editorial}prestashop>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Titre principal';
$_MODULE['<{editorial}prestashop>editorial_7496c27605d7ac3462a5dab8ecf1b569'] = 'Apparaît en haut de la page d\'accueil';
$_MODULE['<{editorial}prestashop>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Pré-en-tête';
$_MODULE['<{editorial}prestashop>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Texte d\'introduction';
$_MODULE['<{editorial}prestashop>editorial_0a9ce580a59ece76cad698332fd53887'] = 'Texte d\'introduction de votre choix; par exemple expliquez ce que vous vendez ou mettez en avant un produit';
$_MODULE['<{editorial}prestashop>editorial_22c2adcb89e2f2d9c5f6fe3731fad3b3'] = 'Logo de la page d\'accueil';
$_MODULE['<{editorial}prestashop>editorial_f85e125f2a9ebcd47f420c94b535f50a'] = 'Apparaitra à côté du texte d\'introduction';
$_MODULE['<{editorial}prestashop>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Lien de l\'image';
$_MODULE['<{editorial}prestashop>editorial_62f6077d6d15a35ff4929a225205892f'] = 'Lien utilisé sur le second logo';
$_MODULE['<{editorial}prestashop>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Sous-titre de l\'image';
$_MODULE['<{editorial}prestashop>editorial_c260ede55f0be17068302e7f842802f3'] = 'Mettre à jour';

?>