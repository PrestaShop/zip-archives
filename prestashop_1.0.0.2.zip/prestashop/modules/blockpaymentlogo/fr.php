<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_1bd130f5640104712b3c7dec66b7b0a1'] = 'Bloc logo de paiement';
$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_524bb57a2d122b48b63270c1dc37d8aa'] = 'Ajoute un bloc affichant tous les logos des modes de paiement';

?>