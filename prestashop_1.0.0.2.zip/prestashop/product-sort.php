<?php

$orderByValues = array(0 => 'name', 1 => 'price', 2 => 'date_add', 3 => 'date_upd', 4 => 'position');
$orderWayValues = array(0 => 'ASC', 1 => 'DESC');

$orderBy = Tools::strtolower(Tools::getValue('orderby', $orderByValues[intval(Configuration::get('PS_PRODUCTS_ORDER_BY'))]));
$orderWay = Tools::strtoupper(Tools::getValue('orderway', $orderWayValues[intval(Configuration::get('PS_PRODUCTS_ORDER_WAY'))]));
if (!in_array($orderWay, array('DESC', 'ASC'))) $orderWay = 'ASC';

$smarty->assign(array(
	'orderby' => $orderBy,
	'orderway' => $orderWay));

?>