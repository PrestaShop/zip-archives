<?php

include(INSTALL_PATH.'/classes/ToolsInstall.php');

$smtpChecked = (trim($_POST['mailMethod']) ==  'smtp');
$smtpServer = $_POST['smtpSrv'];
$content = $_POST['testMsg'];
$subject = $_POST['testSubject'];
$type = 'text/html';
$to =  $_POST['testEmail'];
$from = 'no-reply@'.$_SERVER['HTTP_HOST'];
$smtpLogin = $_POST['smtpLogin'];
$smtpPassword = $_POST['smtpPassword'];
$smtpPort = $_POST['smtpPort'];
$smtpEncryption = $_POST['smtpEnc'];

$result = ToolsInstall::sendMail($smtpChecked, $smtpServer, $content, $subject, $type, $to, $from, $smtpLogin, $smtpPassword, $smtpPort, $smtpEncryption);
die($result ? '<action result="ok"/>' : '<action result="fail"/>');

?>