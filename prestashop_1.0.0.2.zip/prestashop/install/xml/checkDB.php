<?php

include(INSTALL_PATH.'/classes/ToolsInstall.php');

$resultDB = ToolsInstall::checkDB($_POST['server'], $_POST['login'], $_POST['password'], $_POST['name']);
die("<action result='".($resultDB === true ? "ok" : "fail")."' error='".($resultDB === true ? "" : $resultDB)."'/>\n");

?>