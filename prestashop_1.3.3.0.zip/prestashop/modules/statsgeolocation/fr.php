<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_323d4eb70b252acb4a04eaf9e0882597'] = 'Géolocalisation';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_621bd20bc26d0f67bacffc7785616372'] = 'Affiche la provenance de vos clients';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_5f0392f75031c55f27ee9a0bf29cae0f'] = 'Ce module montre la répartition de vos clients par un point plus ou moins gros sur la carte ci-dessous. Constatez la popularité qu\'a votre boutique à l\'échelle du monde et sachez quels continents vous n\'avez pas encore conquis.';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_e346362c256cd1ff6efd70288f769d89'] = 'S\'ouvrir au monde';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_1b625393440dce51a25ccb43a38ddf67'] = 'Ajoutez une nouvelle langue à votre boutique si vous constatez que suffisamment de clients viennent d\'un autre pays.';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_a2f24ad94046ee38db78c336564acd30'] = 'Elargissez votre zone de livraison pour répondre à une potentielle demande.';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_25e8f2fd2871c8423bbe4e254066cd98'] = 'Patientez...';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_e7173e323991c8c33ad2dae1d528fc2e'] = 'Mise à jour des coordonnées';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_60e421611f85e8faa9f6950ce71dab7a'] = 'Cliquez sur le nom d\'un pays puis sur la carte afin de définir son emplacement';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_64d80b7a177f4bd0a1f1dde09741852d'] = 'Cliquez sur la carte pour mettre à jour les coordonnées de :';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_4906a7c99f469d8d3ebb110bf3194fb0'] = 'Erreur : vous devez cliquer sur la carte ou sur le bouton Annuler';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{statsgeolocation}prestashop>statsgeolocation_ad3d06d03d94223fa652babc913de686'] = 'Valider';
