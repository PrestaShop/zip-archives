<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{producttooltip}prestashop>producttooltip_4776f7eb5998034f7bbc63b6457d1ff4'] = 'Ventana de información producto';
$_MODULE['<{producttooltip}prestashop>producttooltip_f4fe2ee6c6c8e0f1b13c02d6dd2c4b99'] = 'Mostrar cuántas personas están viendo la página del producto, así como la fecha del último producto pedido o incluido en el carrito';
$_MODULE['<{producttooltip}prestashop>producttooltip_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{producttooltip}prestashop>producttooltip_e548d0d6a94a27306b8b31472a3e5ec3'] = '¿Mostrar el número de personas que están viendo este producto?';
$_MODULE['<{producttooltip}prestashop>producttooltip_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{producttooltip}prestashop>producttooltip_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{producttooltip}prestashop>producttooltip_2c8de3180924949acc5f6250af689802'] = 'Periodo de validez:';
$_MODULE['<{producttooltip}prestashop>producttooltip_640fd0cc0ffa0316ae087652871f4486'] = 'minutos';
$_MODULE['<{producttooltip}prestashop>producttooltip_1e358b149c2d4105f3a74c1961d1d9fb'] = '¿Mostrar la fecha del último pedido?';
$_MODULE['<{producttooltip}prestashop>producttooltip_011b9877bbda2534eefeb3cb6ab3594f'] = 'Si no hay pedido, ¿mostrar la última vez que un producto ha sido añadido al carrito?';
$_MODULE['<{producttooltip}prestashop>producttooltip_a536f110cc080569666e95e8f49fda9b'] = 'No mostrar los acontecimientos de más de:';
$_MODULE['<{producttooltip}prestashop>producttooltip_44fdec47036f482b68b748f9d786801b'] = 'días';
$_MODULE['<{producttooltip}prestashop>producttooltip_b17f3f4dcf653a5776792498a9b44d6a'] = 'Actualizar configuración';
$_MODULE['<{producttooltip}prestashop>producttooltip_f0f5fac9602d88bc27f0edf960dda8b8'] = 'Mostrar:';
$_MODULE['<{producttooltip}prestashop>producttooltip_975f3743bcce9c5a2e30001aab592fb1'] = 'la persona que está viendo en este momento';
$_MODULE['<{producttooltip}prestashop>producttooltip_e1a1dc1574c9f178c14e2952351aa47d'] = 'las personas que están viendo en este momento';
$_MODULE['<{producttooltip}prestashop>producttooltip_d296e0c3a7dffc0f4d02574bd502653f'] = 'este producto';
$_MODULE['<{producttooltip}prestashop>producttooltip_71736c614b237f4368128077411f1699'] = 'Este producto fue comprado por última vez el';
$_MODULE['<{producttooltip}prestashop>producttooltip_4dda321f0231c2d50fcee5c20075dbbd'] = 'Este producto fue añadido al carrito por última vez el';
