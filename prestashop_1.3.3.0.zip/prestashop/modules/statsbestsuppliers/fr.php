<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_4f29d8c727dcf2022ac241cb96c31083'] = 'Aucun résultat';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_eab2b4237a7cd89c309119e35f62d168'] = 'Affichage';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_8bf8854bebe108183caeb845c7676ae4'] = 'sur';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_2a0440eec72540c5b30d9199c01f348c'] = 'Quantité';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_ea067eb37801c5aab1a1c685eb97d601'] = 'CA';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_cc3eb9ba7d0e236f33023a4744d0693a'] = 'Meilleurs fournisseurs';
$_MODULE['<{statsbestsuppliers}prestashop>statsbestsuppliers_0fbee5f62b2695e84a5eb275bcf98c6f'] = 'Liste des meilleurs fournisseurs';
