<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockinfos}prestashop>blockinfos_14e7895288c0eb3947753ac42df8074a'] = 'Bloque de información';
$_MODULE['<{blockinfos}prestashop>blockinfos_7570e5ca31c582e7a2d3ee759ccf5c86'] = 'Añadir un bloque con distintos enlaces de información';
$_MODULE['<{blockinfos}prestashop>blockinfos_f0f2c414f4953aa7d9b9c5e087f809de'] = 'Archivos seleccionados a mostrar';
$_MODULE['<{blockinfos}prestashop>blockinfos_930e6728b148ce5509c6478f0670baae'] = 'Por favor, compruebe los archivos que se mostrarán en este módulo';
$_MODULE['<{blockinfos}prestashop>blockinfos_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blockinfos}prestashop>blockinfos_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{blockinfos}prestashop>blockinfos_06933067aafd48425d67bcb01bba5cb6'] = 'Actualizar';
$_MODULE['<{blockinfos}prestashop>blockinfos_1f4fa45ebc93811596333e8b2e3a6f31'] = 'Csm actualizados';
$_MODULE['<{blockinfos}prestashop>blockinfos_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Información';
