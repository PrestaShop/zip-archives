<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statssearch}prestashop>statssearch_8c3c245232744602822902b97e65d6f9'] = 'Recherches de la boutique';
$_MODULE['<{statssearch}prestashop>statssearch_8bd5e5a265ca16af735b925ac9d6d7f4'] = 'Affiche les mots clés recherchés par vos visiteurs';
$_MODULE['<{statssearch}prestashop>statssearch_59aeb2c9970b7b25be2fab2317e31fcb'] = 'Mots clés';
$_MODULE['<{statssearch}prestashop>statssearch_40d28e924bb30a0c3d5e45dab97861b5'] = 'Occurences';
$_MODULE['<{statssearch}prestashop>statssearch_fd69c5cf902969e6fb71d043085ddee6'] = 'Résultats';
$_MODULE['<{statssearch}prestashop>statssearch_df7e8db30f72561b6c3f3941ce88722a'] = 'Aucun mot clé recherché plus d\'une fois.';
$_MODULE['<{statssearch}prestashop>statssearch_8d01ac22a68176ddd7067da99508751d'] = '10 premiers mots clés';
$_MODULE['<{statssearch}prestashop>statssearch_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Autres';
