<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Newsletter';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_eb4337ccc2c2e7d7622d21554e1bcc25'] = 'Affiche les inscriptions à la newsletter';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_39d3d2445552ee17e870d7f64262669f'] = 'Inscriptions depuis le compte client :';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_a6152725246f91ab908781d1d6345bc3'] = 'Inscriptions depuis le block sur le front office :';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_64342cd480b27dfeefb08bace6e82fdc'] = 'Les deux :';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_ce182d3cf87db4fd00942a586f16170a'] = 'Le module block newsletter doit être installé';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_cf74c2815ab62be1efa55a4a5d3f46a4'] = 'Statistiques de la newsletter';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_e6d0e1c8fc6a4fcf47869df87e04cd88'] = 'Clients';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visiteurs';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_130c5b3473c57faa76e2a1c54e26f88e'] = 'Les deux';
