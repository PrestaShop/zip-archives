<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sendtoafriend}prestashop>product_page_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Enviar a un amigo';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2074615eb70699e55b1f9289c6c77c25'] = 'Módulo enviar a un amigo';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_b6835a400c888d666e6e5aee9f2a7bc6'] = 'Permitir a los clientes enviar un enlace del producto a un amigo';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_c38f24359344dada5d54e7eef08de8bb'] = 'Debe rellenar todos los campos.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_47f11ea69ec3161cab7c3434290efc8a'] = 'El email de su amigo no es correcto';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_97d4e28297c641ed0dbe3f0172f17fa6'] = 'El nombre de su amigo no es correcto';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_98db77c121d8acdba66ec89626ae896c'] = 'Se ha producido un error durante el proceso.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_22c4733a9ceb239bf825a0cecd1cfaec'] = 'Un amigo';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_ffa719e6b8863717a9e86579249c7d9b'] = 'te ha enviado un enlace a';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_bc8f7bbaaf366a6e4e174fd80dfece40'] = 'se ha enviado con éxito un email a';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Enviar a un amigo';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_20589174124c25654cac3736e737d2a3'] = 'Enviar esta página a un amigo al que podía interesarle este artículo.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_cc5fd9b9f1cad59fcff97a1f21f34304'] = 'Enviar un mensaje';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_19d305aea0ccec77d23362111ebdb6b4'] = 'nombre del amigo:';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_7ae8a9a7a5d8fa40d4515fc52f16bb2e'] = 'Email del amigo:';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2541d938b0a58946090d7abdde0d3890'] = 'enviar';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_68728c1897e5936032fe21ffb6b10c2e'] = 'Volver a la página del producto';
