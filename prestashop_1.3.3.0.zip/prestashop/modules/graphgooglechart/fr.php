<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphgooglechart}prestashop>graphgooglechart_b3b8abce7e542a30dc415f612d4e0f23'] = 'Google Chart';
$_MODULE['<{graphgooglechart}prestashop>graphgooglechart_e01118a336bd13f2f0e70bf7178c1fdc'] = 'L\'API Google Chart permet de générer dynamiquement des graphiques.';
