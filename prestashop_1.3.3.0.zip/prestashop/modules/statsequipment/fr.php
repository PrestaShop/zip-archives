<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}prestashop>statsequipment_719d067b229178f03bcfa1da4ac4dede'] = 'Equipement';
$_MODULE['<{statsequipment}prestashop>statsequipment_503a1fac5cb1efc3f60a0a318ae7caae'] = 'Affiche l\'équipement de vos visiteurs';
$_MODULE['<{statsequipment}prestashop>statsequipment_2578610f8dbf2ffe5dfdd8dd5c6181c2'] = 'Déterminez la répartition des navigateurs web utilisés par vos clients';
$_MODULE['<{statsequipment}prestashop>statsequipment_dc29a12c359732b223367cb61df2196d'] = 'Déterminez la répartition des systèmes d\'exploitation utilisés par vos clients';
$_MODULE['<{statsequipment}prestashop>statsequipment_575e3c9cac82aacd649b1196d845588a'] = 'Extensions';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsequipment}prestashop>statsequipment_955114028663527c20093ff65028f47d'] = 'Veillez à ce que votre site soit accessible à tous';
$_MODULE['<{statsequipment}prestashop>statsequipment_e503bccaa7a7649e8b062d692c1620bd'] = 'Lorsque l\'on gère des sites web, il est important de garder une trace des logiciels utilisés par les visiteurs afin de s\'assurer que le site s\'affiche de la même façon pour tout le monde. Et PrestaShop a été construit de manière à être compatible avec la plupart des navigateurs Web récents et les systèmes d\'exploitation. Toutefois, dans le cas où vous auriez ajouté des fonctionnalités avancées à votre site Web ou même modifié le code de base PrestaShop, ces ajouts pourraient ne pas être accessibles par tous. C\'est pourquoi il est bon de contrôler le pourcentage de visiteurs pour chaque système avant de songer à ajouter ce type de fonctionnalités trop spécifiques.';
$_MODULE['<{statsequipment}prestashop>statsequipment_8ce59076ab4eaa3570ff2a931706d3c1'] = 'Navigateurs utilisés';
$_MODULE['<{statsequipment}prestashop>statsequipment_eb84ea9e8324beffd94fdeff011edfd7'] = 'Systèmes d\'exploitation utilisés';
