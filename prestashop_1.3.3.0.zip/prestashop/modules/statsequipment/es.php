<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}prestashop>statsequipment_719d067b229178f03bcfa1da4ac4dede'] = 'Software';
$_MODULE['<{statsequipment}prestashop>statsequipment_503a1fac5cb1efc3f60a0a318ae7caae'] = 'Mostrar el Software utilizado por sus visitantes';
$_MODULE['<{statsequipment}prestashop>statsequipment_2578610f8dbf2ffe5dfdd8dd5c6181c2'] = 'Determine la repartición de los buscadores que utilizan sus clientes';
$_MODULE['<{statsequipment}prestashop>statsequipment_dc29a12c359732b223367cb61df2196d'] = 'Determine la repartición de los sistemas operativo que utilizan sus clientes';
$_MODULE['<{statsequipment}prestashop>statsequipment_575e3c9cac82aacd649b1196d845588a'] = 'Plug-ins';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statsequipment}prestashop>statsequipment_955114028663527c20093ff65028f47d'] = 'Asegúrese de que su sitio Web sea accesible a todos';
$_MODULE['<{statsequipment}prestashop>statsequipment_e503bccaa7a7649e8b062d692c1620bd'] = 'Cuando se administran sitios web, es importante no perder de vista el software utilizado por los visitantes con el fin de asegurarse de que el sitio se muestra de manera idéntica para cada uno. PrestaShop fue creado para ser compatible con la mayoría de los buscadores recientes y de los sistemas operativos de ordenadores (OS) de la red. Sin embargo, puesto que usted puede terminar agregando características avanzadas a su sitio Web o incluso modificar el código de base de PrestaShop, estas adiciones pueden no ser accesibles para todos. Por esa razón es una buena idea guardar en pestañas una relación del porcentaje de usuarios para cada tipo de software antes de hacer algún cambio al que sólo podrá acceder un número limitado de usuarios. ';
$_MODULE['<{statsequipment}prestashop>statsequipment_8ce59076ab4eaa3570ff2a931706d3c1'] = 'Buscador utilizado';
$_MODULE['<{statsequipment}prestashop>statsequipment_eb84ea9e8324beffd94fdeff011edfd7'] = 'Sistema operativo utilizado';
