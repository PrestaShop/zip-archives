<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsdata}prestashop>statsdata_a51950bf91ba55cd93a33ce3f8d448c2'] = 'Récupération des données statistiques';
$_MODULE['<{statsdata}prestashop>statsdata_7bf6ca30111df3fa9a2f915819628c1d'] = 'Ce module doit être activé pour bénéficier des statistiques';
