<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c2796655c25e1b0b8582716036aece08'] = 'Cadeau d\'anniversaire';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d1f5899bf2af57ed816390d9d740daf6'] = 'Offrez automatiquement à vos clients des cadeaux d\'anniversaire';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ccfcf858237a83953c1ac03b5abde35e'] = 'Créé un bon de réduction pour les clients célébrant leur anniversaire et utilisable une seule fois';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Actif';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_59cb7946b9d916e80a7e05defd004120'] = 'De plus, vous devez installer une règle CRON qui appellera le fichier';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_9939846b096f52609cb7c31de24e20e7'] = 'chaque jour';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Type';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_689202409e48743b914713f96d93947c'] = 'Valeur';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_998d08a9606f9656e8d1fcab8b762155'] = 'Soit le montant soit le pourcentage selon votre choix précédent';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c7778a6285eb4d3ab3e63577d01d8c9e'] = 'Commande minimum';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7965459711eef00cc851228b488a46f4'] = 'Montant minimum de la commande pour que le bon soit utilisable';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_38fb7d24e0d60a048f540ecb18e13376'] = 'Sauvegarder';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Champ requis';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_cb21e843b037359d0fb5b793fccf964f'] = 'Fidéliser le client';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d7310108a7af8ab125b7b69d602f9a8a'] = 'Offrir un cadeau d\'anniversaire à un client est une manière comme une autre d\'agir sur sa fidélité.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_0dc42f38b35e45090e1a1c94755c2d43'] = 'Que faire ?';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_e1b9cd2cf691574ade4e2e1077b03441'] = 'Garder un client est plus rentable que d’en conquérir un nouveau. Il est donc impératif de le fidéliser, c\'est-à-dire de le faire revenir sur votre boutique. ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7b6ac3f2cdb42a4462ff7ca3c4358f71'] = 'Le bouche à oreille est également un moyen d\'avoir de nouveaux clients satisfaits ; car un client non satisfait n\'en attirera pas de nouveaux. ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_410008089d5bb723438103a84d48a59c'] = 'Pour y parvenir, plusieurs moyens existent :';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_3e788301a1b0ce341aa5ce15bc520545'] = 'Les opérations ponctuelles : les récompenses marchandes (offres promotionnelles ciblées et personnalisées, cadeaux -produit ou service offert-), les récompenses non marchandes (traitement prioritaire d\'une commande ou d\'un produit), les récompenses pécuniaires (bons d\'achat, de réduction, de remboursement). ';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f299b58558601a85c98a2d1d7867d523'] = 'Les opérations pérennes : (carte de fidélité, points de fidélité) qui non seulement justifient la communication marchand-clients, et aussi offre des avantages aux clients (offres privatives, réductions).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_49c8045b620233da0fa2d7088b2cb1c9'] = 'Ces opérations incitent non seulement le client à acheter, mais aussi à revenir régulièrement sur votre boutique.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d46bd07675d08116e85f8a4c7866de53'] = 'Votre cadeau d\'anniversaire !';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ae1e2f44f5d28cf8e14e1a30cc105060'] = 'Bon anniversaire !';
