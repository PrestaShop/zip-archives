<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c2796655c25e1b0b8582716036aece08'] = 'Regalo de cumpleaños';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d1f5899bf2af57ed816390d9d740daf6'] = 'Haga a sus clientes regalos de cumpleaños automáticamente';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ccfcf858237a83953c1ac03b5abde35e'] = 'Cree un vale descuento para los clientes que celebren su cumpleaños y que pueda usarse una sola vez';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_59cb7946b9d916e80a7e05defd004120'] = 'Adicionalemente, debe establecer una regla CRON que pida el archivo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_9939846b096f52609cb7c31de24e20e7'] = 'todos los días';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_a1fa27779242b4902f7ae3bdd5c6d508'] = 'Tipo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_689202409e48743b914713f96d93947c'] = 'Valor';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_998d08a9606f9656e8d1fcab8b762155'] = 'cantidad monetaria o porcentaje dependiendo del tipo seleccionado anteriormente';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_c7778a6285eb4d3ab3e63577d01d8c9e'] = 'Pedido mínimo';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7965459711eef00cc851228b488a46f4'] = 'Cantidad de pedido mínimo para utilizar el vale';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_38fb7d24e0d60a048f540ecb18e13376'] = 'Guardar';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Archivo necesario';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_cb21e843b037359d0fb5b793fccf964f'] = 'Desarrolle la fidelización de sus clientes';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d7310108a7af8ab125b7b69d602f9a8a'] = 'Haciendo regalos a sus clientes está seguro de fidelizarlos.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_0dc42f38b35e45090e1a1c94755c2d43'] = '¿Cómo hacer?';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_e1b9cd2cf691574ade4e2e1077b03441'] = 'Conservar un cliente es más ventajoso que captar uno nuevo. Así, es necesario desarrollar su lealtad, es decir hacer todo lo posible para que vuelva a su tienda.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_7b6ac3f2cdb42a4462ff7ca3c4358f71'] = 'El boca a boca es uno de los mejores métodos para conseguir nuevos clientes satisfechos; un cliente contento atraerá otros nuevos clientes.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_410008089d5bb723438103a84d48a59c'] = 'Para alcanzar este objetivo usted puede organizar:';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_3e788301a1b0ce341aa5ce15bc520545'] = 'Operaciones puntuales: recompensas comerciales (ofertas especiales personalizadas, producto o servicios ofrecidos), recompensas no comerciales (prioridad en el envío  de un pedido  o de un producto), recompensas pecuniarias (enlaces, cupones del descuento, prioridad en el reembolso...).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_f299b58558601a85c98a2d1d7867d523'] = 'Operaciones sostenibles: las tarjetas de fidelidad o de puntos, que no sólo justifican la comunicación entre el comerciante y el cliente, pero también ofrecen ventajas a los clientes (ofertas, descuentos privados).';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_49c8045b620233da0fa2d7088b2cb1c9'] = 'Estas operaciones animan a los clientes a comprar y también a volver a la tienda virtual regularmente.';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_d46bd07675d08116e85f8a4c7866de53'] = '¡Su regalo de cumpleaños!';
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_ae1e2f44f5d28cf8e14e1a30cc105060'] = '¡Feliz cumpleaños!';
