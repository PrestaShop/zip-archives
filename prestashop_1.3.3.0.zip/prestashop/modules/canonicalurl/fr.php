<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{canonicalurl}prestashop>canonicalurl_ee096b45f2e0dcd83771ea27b049c76a'] = 'URL canonique';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_304a7444905effab23fcd6da6e2c9ab4'] = 'Améliore la SEO en évitant le statut \"duplicate content\" sur votre boutique.';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_d7141d13c32f8cbe353804bdc69f4a94'] = 'Vous devez paramétrer l\'URL canonique de votre site pour éviter le statut \"duplicate content\" sur votre boutique. ';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_b573a17fc6b9327afdebe42f777c744e'] = 'URL canonique : URL invalide.';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_e59cdd8d50a28028c669e58d55ad130d'] = 'Choisissez le nom de domaine principal pour votre référencement (ex : www.maboutique.com, maboutique.com, etc...). Note : ne pas inclure le dernier slash (\"/\"), le suffixe \"/index.php\", ou encore le préfixe \"http(s)://\".';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
