<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}prestashop>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Bloc langues';
$_MODULE['<{blocklanguages}prestashop>blocklanguages_c3e2756c30a7bec5b2344cf7e767693d'] = 'Ajoute un bloc permettant au client de choisir sa langue';
