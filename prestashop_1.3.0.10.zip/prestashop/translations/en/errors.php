<?php

global $_ERRORS;
$_ERRORS = array();
$_ERRORS['ae2d0232e1aaa43938729055e298be5a'] = 'identification number is incorrect or already used';

?>