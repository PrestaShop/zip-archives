<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gcheckout}prestashop>gcheckout_6c132b5e262594950586ae13a7d3aa94'] = 'Google checkout';
$_MODULE['<{gcheckout}prestashop>gcheckout_3f3c0194c5adbe6953eb571f125af16d'] = 'Implementación de API de Google Checkout ';
$_MODULE['<{gcheckout}prestashop>gcheckout_4402acab1c8f90dcf4a31dc96833bd86'] = 'No hay moneda configurada para este módulo';
$_MODULE['<{gcheckout}prestashop>gcheckout_82b8bb0d807e6d2e43a068f954c3559f'] = 'La ID del comerciante parece incorrecta';
$_MODULE['<{gcheckout}prestashop>gcheckout_9dd37c2106ceacbf0a40778b2109c386'] = 'La contraseña del comerciante parece incorrecta';
$_MODULE['<{gcheckout}prestashop>gcheckout_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{gcheckout}prestashop>gcheckout_cdd506f9916fb2a6c2a901eb79928176'] = 'Primero utilice el sandbox para probar el múdulo, luego podrá utilizarlo en modo real si toda la configuración se hizo correctamente. No olvide cambiar su contraseña e identificación mercantil según el modo';
$_MODULE['<{gcheckout}prestashop>gcheckout_650be61892bf690026089544abbd9d26'] = 'Modo';
$_MODULE['<{gcheckout}prestashop>gcheckout_7f80fcc452c2f1ed2bb51b39d0864df1'] = 'Real';
$_MODULE['<{gcheckout}prestashop>gcheckout_2652eec977dcb2a5aea85f5bec235b05'] = 'Sandbox';
$_MODULE['<{gcheckout}prestashop>gcheckout_76055653a95e0a559b734ec322d89632'] = 'Puede encontrar estas claves en su cuenta de comprobación de Google > Ajustes > Integración. En Sandbox y modo real tiene las mismas claves.';
$_MODULE['<{gcheckout}prestashop>gcheckout_229a7ec501323b94db7ff3157a7623c9'] = 'ID comerciante';
$_MODULE['<{gcheckout}prestashop>gcheckout_795acb9a0c89791314d3032fe65eeb92'] = 'Contraseña comerciante';
$_MODULE['<{gcheckout}prestashop>gcheckout_74692aae1cff5dc9dfd44f8c4e0540ad'] = 'Usted puede registrar la comunicación del servidor-a-servidor. Los ficheros de diario son';
$_MODULE['<{gcheckout}prestashop>gcheckout_be5d5d37542d75f93a87094459f76678'] = 'y';
$_MODULE['<{gcheckout}prestashop>gcheckout_ce103162a276684df5afb8221cfa0469'] = 'Si usted lo activa, está seguro de protegerlos poniendo un archivo .htaccess en el mismo directorio. Si usted olvida hacer eso, cualquiera podrá leerlos';
$_MODULE['<{gcheckout}prestashop>gcheckout_b2d37ae1cedf42ff874289b721860af2'] = 'Registros';
$_MODULE['<{gcheckout}prestashop>gcheckout_38fb7d24e0d60a048f540ecb18e13376'] = 'Guardar';
$_MODULE['<{gcheckout}prestashop>gcheckout_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Información';
$_MODULE['<{gcheckout}prestashop>gcheckout_c4ddab20febbb0e75bb211ac8cd4c541'] = 'Para utilizar su módulo de la comprobación de Google, tiene que configurar su cuenta Google (cuenta de sandbox y su cuenta). La conexión a la comprobación de la cuenta Google > ajustes; Integración. La URL del servicio repetido del API es:';
$_MODULE['<{gcheckout}prestashop>gcheckout_dba727a9adc372723baef4533a7fc9da'] = 'El método de callback debe fijarse a ';
$_MODULE['<{gcheckout}prestashop>gcheckout_e2e882d58bbd478e17c5a542d5d6fcda'] = 'Los pedidos deben pasarse con la misma moneda que la cuenta del vendedor. Los carritos en otras monedas serán convertidas si el cliente elige pagar con este módulo.';
$_MODULE['<{gcheckout}prestashop>gcheckout_ba794350deb07c0c96fe73bd12239059'] = 'Embalaje ';
$_MODULE['<{gcheckout}prestashop>gcheckout_9f06b28a40790c4c4df5739bce3c1eb0'] = 'Costos de envío';
$_MODULE['<{gcheckout}prestashop>gcheckout_8dd85f4218069de952672fe3180dacdb'] = 'Pagar con GoogleCheckout';
