tinyMCE.addI18n('et.searchreplace_dlg',{
searchnext_desc:"Otsi uuesti",
notfound:"Otsing on l\u00F5petatud. Otsis\u00F5na ei leitud.",
search_title:"Otsi",
replace_title:"Otsi/Asenda",
allreplaced:"K\u00F5ik otsis\u00F5na ilmingud on asendatud.",
findwhat:"Otsi mida",
replacewith:"Asenda millega",
direction:"Suund",
up:"\u00DCles",
down:"Alla",
mcase:"Vasta suurusele",
findnext:"Otsi j\u00E4rgmine",
replace:"Asenda",
replaceall:"Asenda k\u00F5ik"
});