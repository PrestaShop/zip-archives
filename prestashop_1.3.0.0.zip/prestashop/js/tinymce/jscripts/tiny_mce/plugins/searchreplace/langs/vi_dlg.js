tinyMCE.addI18n('vi.searchreplace_dlg',{
searchnext_desc:"T\u00ECm l\u1EA1i",
notfound:"K\u1EBFt th\u00FAc t\u00ECm ki\u1EBFm. Kh\u00F4ng th\u1EC3 t\u00ECm th\u1EA5y chu\u1ED7i t\u1EEB c\u1EA7n t\u00ECm.",
search_title:"T\u00ECm ki\u1EBFm",
replace_title:"T\u00ECm ki\u1EBFm/Thay th\u1EBF",
allreplaced:"\u0110\u00E3 thay th\u1EBF t\u1EA5t c\u1EA3 chu\u1ED7i t\u1EEB c\u1EA7n t\u00ECm.",
findwhat:"Chu\u1ED7i t\u1EEB c\u1EA7n t\u00ECm",
replacewith:"Thay th\u1EBF b\u1EB1ng chu\u1ED7i t\u1EEB",
direction:"H\u01B0\u1EDBng t\u00ECm ki\u1EBFm",
up:"L\u00EAn",
down:"Xu\u1ED1ng",
mcase:"Ph\u00E2n bi\u1EC7t ch\u1EEF hoa, ch\u1EEF th\u01B0\u1EDDng ",
findnext:"Ti\u1EBFp t\u1EE5c t\u00ECm",
replace:"Thay th\u1EBF",
replaceall:"Thay th\u1EBF t\u1EA5t c\u1EA3"
});