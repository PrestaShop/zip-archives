tinyMCE.addI18n('hu.paste_dlg',{
text_title:"Haszn\u00E1lja a Ctrl+V-t a billenty\u0171zet\u00E9n a beilleszt\u00E9shez.",
text_linebreaks:"Sort\u00F6r\u00E9sek megtart\u00E1sa",
word_title:"Haszn\u00E1lja a Ctrl+V-t a billenty\u0171zet\u00E9n a beilleszt\u00E9shez."
});