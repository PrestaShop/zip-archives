<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Your new admin password'] = 'Tu nueva contrase�a de Administrador';
$_LANGMAIL['Your password'] = 'Tu contrase�a';
$_LANGMAIL['Welcome!'] = 'Bienvenido !';
$_LANGMAIL['Order confirmation'] = 'Confirmaci�n de pedido';
$_LANGMAIL['Message from contact form'] = 'Mensaje desde el formulario de contacto';
$_LANGMAIL['My personal informations'] = 'Informaci�n personal';
$_LANGMAIL['Message from a customer'] = 'Mensaje de un cliente';

?>