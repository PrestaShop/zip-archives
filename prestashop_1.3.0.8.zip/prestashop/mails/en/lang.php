<?php

global $_LANGMAIL;
$_LANGMAIL = array();

?>