<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Your new admin password'] = 'Votre nouveau mot de passe administateur';
$_LANGMAIL['Your password'] = 'Votre nouveau mot de passe';
$_LANGMAIL['Welcome!'] = 'Bienvenue !';
$_LANGMAIL['Order confirmation'] = 'Confirmation de commande';
$_LANGMAIL['Message from contact form'] = 'Message depuis le formulaire de contact';
$_LANGMAIL['My personal informations'] = 'Mes informations personnelles';
$_LANGMAIL['Message from a customer'] = 'Message d\'un client';
$_LANGMAIL['Virtual product to download'] = 'Produit virtuel à télécharger';
$_LANGMAIL['Referral Program'] = 'Programme de parrainage';
$_LANGMAIL['Package in transit'] = 'Colis en cours d\'envoi';

?>