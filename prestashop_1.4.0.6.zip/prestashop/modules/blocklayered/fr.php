<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklayered}prestashop>blocklayered_84241e458cdd5162745500a59a3680f3'] = 'Block navigation à facette';
$_MODULE['<{blocklayered}prestashop>blocklayered_d7df62361bd02e736cbf22913f2f507e'] = 'Affiche un block avec les filtres de la navigation à facette';
$_MODULE['<{blocklayered}prestashop>blocklayered_c32516babc5b6c47eb8ce1bfc223253c'] = 'Catalogue';
$_MODULE['<{blocklayered}prestashop>blocklayered_b8f78b1a8b9e8a50b2426e028c702db2'] = 'Boutique par catégorie:';
