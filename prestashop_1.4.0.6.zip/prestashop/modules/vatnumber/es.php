<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{vatnumber}prestashop>vatnumber_cee549912e318726d2c4989bb507665f'] = 'Número de IVA europeo';
$_MODULE['<{vatnumber}prestashop>vatnumber_6927202cbf1f53ef0062c95d13850d51'] = 'Activar la gestión del número de IVA';
$_MODULE['<{vatnumber}prestashop>vatnumber_162b29cf61678af2aaac37f440265c28'] = 'Actualización de su país.';
$_MODULE['<{vatnumber}prestashop>vatnumber_0ca51bcd22e4d7b56b6f1d8a01cefc1f'] = 'La comprobación del número de IVA con el WebService se encuentra activada.';
$_MODULE['<{vatnumber}prestashop>vatnumber_467c214bb76759108ece49873eda44e4'] = 'La comprobación del número de IVA con el WebService se encuentra desactivada.';
$_MODULE['<{vatnumber}prestashop>vatnumber_56564e0a106b0e0e2dc57b5a105ed639'] = 'Su país';
$_MODULE['<{vatnumber}prestashop>vatnumber_038b34b36ec9eaf5f96d11e17f208f1b'] = '--Elija un país--';
$_MODULE['<{vatnumber}prestashop>vatnumber_ab73ac60f122e6493f53ba7699ae2139'] = 'Activar la comprobación del número de IVA con el WebService';
$_MODULE['<{vatnumber}prestashop>vatnumber_0a57ec92318a15681fb878bc2931480c'] = 'La comprobación del número de IVA con el WebService es lenta. Activar esta opción puede ralentizar su tienda.';
$_MODULE['<{vatnumber}prestashop>vatnumber_38fb7d24e0d60a048f540ecb18e13376'] = 'Guardar';
