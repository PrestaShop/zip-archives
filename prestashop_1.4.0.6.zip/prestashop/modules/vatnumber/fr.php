<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{vatnumber}prestashop>vatnumber_cee549912e318726d2c4989bb507665f'] = 'Numéro de TVA Europeen';
$_MODULE['<{vatnumber}prestashop>vatnumber_6927202cbf1f53ef0062c95d13850d51'] = 'Activer la gestion du numéro de TVA';
$_MODULE['<{vatnumber}prestashop>vatnumber_162b29cf61678af2aaac37f440265c28'] = 'Votre pays a été mis à jour.';
$_MODULE['<{vatnumber}prestashop>vatnumber_0ca51bcd22e4d7b56b6f1d8a01cefc1f'] = 'La vérification du numéro de TVA avec le WebService est maintenant activé.';
$_MODULE['<{vatnumber}prestashop>vatnumber_467c214bb76759108ece49873eda44e4'] = 'La vérification du numéro de TVA avec le WebService est maintenant desactivé.';
$_MODULE['<{vatnumber}prestashop>vatnumber_56564e0a106b0e0e2dc57b5a105ed639'] = 'Votre pays';
$_MODULE['<{vatnumber}prestashop>vatnumber_038b34b36ec9eaf5f96d11e17f208f1b'] = '-- Choisissez un pays --';
$_MODULE['<{vatnumber}prestashop>vatnumber_ab73ac60f122e6493f53ba7699ae2139'] = 'Activer la vérification du numéro de TVA avec le WebService';
$_MODULE['<{vatnumber}prestashop>vatnumber_0a57ec92318a15681fb878bc2931480c'] = 'La vérification du numéro de TVA avec le WebService est lente. Activer cette option peut ralentir votre boutique.';
$_MODULE['<{vatnumber}prestashop>vatnumber_38fb7d24e0d60a048f540ecb18e13376'] = 'Sauvegarder';
