<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{reverso}prestashop>reverso_86774f1550b9ad3cc207184b35afb514'] = 'ReversoForm';
$_MODULE['<{reverso}prestashop>reverso_1e9fcdadfd0ced6424c9692da9373fbf'] = 'Rellenar el formulario de autentificación con ReversoForm';
$_MODULE['<{reverso}prestashop>reverso_254f642527b45bc260048e30704edb39'] = 'Configuración';
$_MODULE['<{reverso}prestashop>reverso_3460276ef9eb483d13aa31b870077a0d'] = 'Número de serie';
$_MODULE['<{reverso}prestashop>reverso_af53b10cb956fa2562af3c3fcd1c08f6'] = 'Dirección del sitio';
$_MODULE['<{reverso}prestashop>reverso_06933067aafd48425d67bcb01bba5cb6'] = 'Actualizar';
$_MODULE['<{reverso}prestashop>reverso_a67fe5b600cc617a0cc6f782b2b466e1'] = 'Configuración de la cuenta ReversoForm';
$_MODULE['<{reverso}prestashop>reverso_af21713c577d79637cb7ce743b9522be'] = '¿No tiene cuenta Reverso?';
$_MODULE['<{reverso}prestashop>reverso_15e80d88e64872dffe151e5ba783270b'] = 'Regístrese ahora';
$_MODULE['<{reverso}prestashop>reverso_7ccf58c950043c9fbfed668df13ce608'] = 'Parámetros actualizados';
$_MODULE['<{reverso}prestashop>reverso_9dd6474008963ad22e9fd0f28447e7b2'] = 'Imposible encontrar el número';
$_MODULE['<{reverso}prestashop>reverso_87094afb0ee64892a41b1f6acab60b02'] = 'Completar el formulario automáticamente con su número de teléfono';
