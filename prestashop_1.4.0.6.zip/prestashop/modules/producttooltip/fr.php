<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{producttooltip}prestashop>producttooltip_4776f7eb5998034f7bbc63b6457d1ff4'] = 'Infobulles produit';
$_MODULE['<{producttooltip}prestashop>producttooltip_f4fe2ee6c6c8e0f1b13c02d6dd2c4b99'] = 'Affiche combien de personnes consultent un produit ainsi que les dates de dernière commande ou ajout au panier';
$_MODULE['<{producttooltip}prestashop>producttooltip_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{producttooltip}prestashop>producttooltip_e548d0d6a94a27306b8b31472a3e5ec3'] = 'Afficher le nombre de personnes qui consultent la fiche produit ?';
$_MODULE['<{producttooltip}prestashop>producttooltip_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{producttooltip}prestashop>producttooltip_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{producttooltip}prestashop>producttooltip_2c8de3180924949acc5f6250af689802'] = 'Période de validité :';
$_MODULE['<{producttooltip}prestashop>producttooltip_640fd0cc0ffa0316ae087652871f4486'] = 'minutes';
$_MODULE['<{producttooltip}prestashop>producttooltip_1e358b149c2d4105f3a74c1961d1d9fb'] = 'Afficher la date de la dernière commande ?';
$_MODULE['<{producttooltip}prestashop>producttooltip_011b9877bbda2534eefeb3cb6ab3594f'] = 'Si aucune commande à afficher, afficher la date du dernier ajout au panier ?';
$_MODULE['<{producttooltip}prestashop>producttooltip_a536f110cc080569666e95e8f49fda9b'] = 'Ne pas afficher les événements datant de plus de :';
$_MODULE['<{producttooltip}prestashop>producttooltip_44fdec47036f482b68b748f9d786801b'] = 'jours';
$_MODULE['<{producttooltip}prestashop>producttooltip_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour les paramètres';
$_MODULE['<{producttooltip}prestashop>producttooltip_f0f5fac9602d88bc27f0edf960dda8b8'] = 'Exemple :';
$_MODULE['<{producttooltip}prestashop>producttooltip_975f3743bcce9c5a2e30001aab592fb1'] = 'personne regarde actuellement';
$_MODULE['<{producttooltip}prestashop>producttooltip_e1a1dc1574c9f178c14e2952351aa47d'] = 'personnes regardent actuellement';
$_MODULE['<{producttooltip}prestashop>producttooltip_d296e0c3a7dffc0f4d02574bd502653f'] = 'ce produit';
$_MODULE['<{producttooltip}prestashop>producttooltip_71736c614b237f4368128077411f1699'] = 'Ce produit a été acheté dernièrement le';
$_MODULE['<{producttooltip}prestashop>producttooltip_4dda321f0231c2d50fcee5c20075dbbd'] = 'Ce produit a été ajouté au panier dernièrement le';
