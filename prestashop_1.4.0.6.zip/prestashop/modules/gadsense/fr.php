<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gadsense}prestashop>gadsense_8a41674922e424cde4dd47c91f9d62e8'] = 'Google Adsense';
$_MODULE['<{gadsense}prestashop>gadsense_4148996483a2cfeed90c66dc539c8f1a'] = 'Vous n\'avez pas encore paramétré votre code Google Adsense.';
$_MODULE['<{gadsense}prestashop>gadsense_fe98dd96c9736120bbadeac5a2957326'] = 'Intégrer le script Google Adsense dans sa boutique';
$_MODULE['<{gadsense}prestashop>gadsense_fa214007826415a21a8456e3e09f999d'] = 'Etes-vous sûr de vouloir supprimer vos paramètres ?';
$_MODULE['<{gadsense}prestashop>gadsense_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour.';
$_MODULE['<{gadsense}prestashop>gadsense_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres.';
$_MODULE['<{gadsense}prestashop>gadsense_30c2b4b5e19ac71fefa1b4d688a7a98f'] = 'Votre code';
$_MODULE['<{gadsense}prestashop>gadsense_81eeab9506186e2dca8faefa78d54067'] = 'Exemple :';
$_MODULE['<{gadsense}prestashop>gadsense_b17f3f4dcf653a5776792498a9b44d6a'] = 'Mettre à jour les paramètres';
