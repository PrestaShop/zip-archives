<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphxmlswfcharts}prestashop>graphxmlswfcharts_fd1d6df8df2837bc1690e3ca9d84f502'] = 'Cartas  XML/SWF';
$_MODULE['<{graphxmlswfcharts}prestashop>graphxmlswfcharts_f0f38a8ecaa33a7db97194b325992d1b'] = 'Las cartas de XML/SWF son unas herramientas simples, de un gran alcance, que pueden usar el flash de Adobe para crear cartas y gráficos atractivos de datos dinámicos.';
