<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphxmlswfcharts}prestashop>graphxmlswfcharts_fd1d6df8df2837bc1690e3ca9d84f502'] = 'XML/SWF Charts';
$_MODULE['<{graphxmlswfcharts}prestashop>graphxmlswfcharts_f0f38a8ecaa33a7db97194b325992d1b'] = 'XML/SWF Charts est un outil simple mais puissant utilisant Adobe Flash pour créer des graphiques à partir de données dynamiques.';
