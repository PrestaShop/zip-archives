<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}prestashop>productscategory_db33983df8ef521000b0ab60dcb5a83f'] = 'Categoría de productos';
$_MODULE['<{productscategory}prestashop>productscategory_c167dc9a6cdefdab35fb3b5e325cc815'] = 'Mostrar productos de la misma categoría en la página producto';
$_MODULE['<{productscategory}prestashop>productscategory_462390017ab0938911d2d4e964c0cab7'] = 'Parámetros actualizados con éxito';
$_MODULE['<{productscategory}prestashop>productscategory_f4f70727dc34561dfde1a3c529b6205c'] = 'Parámetros';
$_MODULE['<{productscategory}prestashop>productscategory_b6bf131edd323320bac67303a3f4de8a'] = 'Mostrar el precio del producto';
$_MODULE['<{productscategory}prestashop>productscategory_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{productscategory}prestashop>productscategory_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{productscategory}prestashop>productscategory_70f9a895dc3273d34a7f6d14642708ec'] = 'Mostrar el precio del producto en el bloque';
$_MODULE['<{productscategory}prestashop>productscategory_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{productscategory}prestashop>productscategory_dd1f775e443ff3b9a89270713580a51b'] = 'Anterior';
$_MODULE['<{productscategory}prestashop>productscategory_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{productscategory}prestashop>productscategory_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Siguiente';
