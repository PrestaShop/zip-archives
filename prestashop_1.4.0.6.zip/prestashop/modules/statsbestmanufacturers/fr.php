<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_4f29d8c727dcf2022ac241cb96c31083'] = 'Empty recordset returned';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_eab2b4237a7cd89c309119e35f62d168'] = 'Affichage';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_8bf8854bebe108183caeb845c7676ae4'] = 'de';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_2a0440eec72540c5b30d9199c01f348c'] = 'Quantité vendus ';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_ea067eb37801c5aab1a1c685eb97d601'] = 'Total des sommes versées ';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_72fd9b5482201824daae557360d91196'] = 'Meilleur fabricants ';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_aa1b814546fe3e2e96ef3a185e4df8e9'] = 'Une liste des meilleurs fabricants ';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
