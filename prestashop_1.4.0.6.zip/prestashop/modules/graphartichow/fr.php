<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphartichow}prestashop>graphartichow_6b1e6241446c46f7ab8d28ae83d53e71'] = 'Artichow';
$_MODULE['<{graphartichow}prestashop>graphartichow_45123e90e12e24029808ac94d442583d'] = 'Artichow est une librairie qui permet d\'afficher des graphiques simples basés sur des images utilisant PHP et GD.';
