<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statssales}prestashop>statssales_45c4b3e103155326596d6ccd2fea0f25'] = 'Commandes et CA';
$_MODULE['<{statssales}prestashop>statssales_09a6e97d1ccb13182c8fd316450dbebf'] = 'Affiche l\'évolution du chiffre d\'affaires et la répartition des commandes par statut';
$_MODULE['<{statssales}prestashop>statssales_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Tout afficher';
$_MODULE['<{statssales}prestashop>statssales_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtrer';
$_MODULE['<{statssales}prestashop>statssales_be11cd88b6b8d28325b01854907ba0d9'] = 'Ces graphiques représentent l\'évolution de vos commandes et chiffre d\'affaires pour une période donnée. Ce n\'est pas un outil d\'analyse avancé mais il vous permet toutefois de visualiser la rentabilité de votre boutique en un clin d\'oeil. Vous pouvez également comparer les ventes entre différentes périodes (Noël...). Seules les commandes valides sont inclues dans ces deux graphes.';
$_MODULE['<{statssales}prestashop>statssales_9ccb8353e945f1389a9585e7f21b5a0d'] = 'Commandes passées :';
$_MODULE['<{statssales}prestashop>statssales_156e5c5872c9af24a5c982da07a883c2'] = 'Produits commandés :';
$_MODULE['<{statssales}prestashop>statssales_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statssales}prestashop>statssales_ec3e48bb9aa902ba2ad608547fdcbfdc'] = 'Chiffre d\'affaires :';
$_MODULE['<{statssales}prestashop>statssales_0718e1ec4754e199aa9cb4bc43a6ff53'] = 'La répartition des états de commande est représentée ci-dessous.';
$_MODULE['<{statssales}prestashop>statssales_3991390ca135c8c780b4a7d9c7c7daf5'] = 'Aucune commande pour cette période';
$_MODULE['<{statssales}prestashop>statssales_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statssales}prestashop>statssales_75288849ad081e6ef15e00c37b7570f2'] = 'Plusieurs statuts de commande';
$_MODULE['<{statssales}prestashop>statssales_264a37d6022d76d1f7043daad3733a3e'] = 'Au sein de votre Back-office, plusieurs statuts de commande sont disponibles : En attente du paiement par chèque, Paiement accepté, Préparation en cours, En cours de livraison, Livré, Annulé, Remboursé, Erreur de paiement, Produits indisponibles et en attente du paiement par virement bancaire.';
$_MODULE['<{statssales}prestashop>statssales_e2e2d7a27ec3e81d16993f2d2e9d2ca2'] = 'Ces statuts ne peuvent être supprimés depuis le Back-office, cependant vous pouvez en ajouter de nouveaux.';
$_MODULE['<{statssales}prestashop>statssales_bb7ad89807bf69ddca986c142311f936'] = 'Commandes et produits';
$_MODULE['<{statssales}prestashop>statssales_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Commandes';
$_MODULE['<{statssales}prestashop>statssales_068f80c7519d0528fb08e82137a72131'] = 'Produits';
$_MODULE['<{statssales}prestashop>statssales_14f1c54626d722168ee62dff05ed811e'] = 'Chiffre d\'affaires en';
$_MODULE['<{statssales}prestashop>statssales_33eee7690a8cd62490ed9eeadd47d163'] = 'Pourcentage de commandes par statut';
