<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{importerOsc}prestashop>importerOsc_e273168c3697c35b8c737d14b1a5fb26'] = 'OsCommerce Importateur';
$_MODULE['<{importerOsc}prestashop>importerOsc_6042ff2da3ae0b5b78e5cc36ede31eb8'] = 'Ce module permet d\'importer à partir d\'OsCommerce vers prestashop';
$_MODULE['<{importerOsc}prestashop>importerOsc_2737b271f276b90d8a04ea4b9d18b920'] = 'Langue par défault OsCommerce';
