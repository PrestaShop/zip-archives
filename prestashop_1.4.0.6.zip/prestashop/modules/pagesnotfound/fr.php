<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Pages introuvables';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_52a8f5d93ac4baca3b296bdef71248c6'] = 'Affiche les pages demandées mais qui n\'existent pas';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_ae4e934750649272acb32c70c11349a0'] = 'Pages introuvables supprimées';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6cb944288ac528fcfd76b20156dddce1'] = 'Vous devez utiliser un fichier .htaccess redirigeant les erreurs 404 vers la page \"404.php\"';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Page';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Origine';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Compteur';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Aucune page enregistrée';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Suppression';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'Supprimer toutes les pages introuvables';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'Erreurs 404';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_c7cf97a9d6cb9554b31a1158dd94c1c5'] = 'Une erreur 404 est un code d\'erreur HTTP signifiant que le fichier demandé par l\'utilisateur est introuvable. Dans votre cas cela signifie qu\'un de vos visiteurs a tapé une mauvaise URL dans la barre d\'adresse ou que vous ou un autre site contient un lien mort quelque part. Quand elle est disponible, la page source est affichée afin de vous permettre de trouver ce lien mort. Dans le cas contraire, c\'est probablement un accès direct, ce qui peut également vouloir dire qu\'un utilisateur a mis en favoris une page qui n\'existe plus.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Comment attraper ces erreurs ?';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_535ff57deda0b45d32cb37fd430accc8'] = 'Si votre hébergeur supporte les fichiers .htaccess, vous pouvez en créer un à la racine de PrestaShop et insérer la ligne suivante :';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_260161f71496fa1b160c50c2c2ea2401'] = 'Un utilisateur qui demande une page non existante sera redirigé vers la page';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_feb436b0dabe28068aa6d866ac47bf0a'] = 'Ce module enregistre les accès à cette page avec : la page demandée initialement, la page source et le nombre de fois que c\'est arrivé.';
