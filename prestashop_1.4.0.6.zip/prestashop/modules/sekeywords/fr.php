<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sekeywords}prestashop>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Mots clés';
$_MODULE['<{sekeywords}prestashop>sekeywords_ed37c33642aec5c295e8d67ff1afa95c'] = 'Affiche les mots clés qui ont mené les visiteurs jusqu\'à votre boutique';
$_MODULE['<{sekeywords}prestashop>sekeywords_a6a5cc2d3979e54597c79a68448adee2'] = 'mot clé trouvé pour votre recherche.';
$_MODULE['<{sekeywords}prestashop>sekeywords_abc9f128fb01c8504e08e77bfc8af795'] = 'mots clés trouvés pour votre recherche.';
$_MODULE['<{sekeywords}prestashop>sekeywords_867343577fa1f33caa632a19543bd252'] = 'mots clés';
$_MODULE['<{sekeywords}prestashop>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Occurences';
$_MODULE['<{sekeywords}prestashop>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV ';
$_MODULE['<{sekeywords}prestashop>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filter par mot clé';
$_MODULE['<{sekeywords}prestashop>sekeywords_188ef1f71ff3ef1c5501dc5c8ee27f88'] = 'et minimum d\'occurences';
$_MODULE['<{sekeywords}prestashop>sekeywords_03e0e9ef8b776b5f7bcc590e51bfa63b'] = 'Appliquer';
$_MODULE['<{sekeywords}prestashop>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'Aucun mot clé';
$_MODULE['<{sekeywords}prestashop>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{sekeywords}prestashop>sekeywords_060ce52fbf64d0ad58c1b984a4230bb6'] = 'Identifier des mots de moteurs de recherche externes';
$_MODULE['<{sekeywords}prestashop>sekeywords_8443e994889501b92bff8f2d18d6ff4d'] = 'Il y a de nombreux moyens pour accéder à un site internet, mais l\'un des plus courants est de passer par un moteur de recherche. Identifier les mots clés qui amènent le plus de visiteurs est donc très important car cela vous permet de connaître les produits que vous devez mettre en avant afin d\'attirer toujours plus de visiteurs et donc de clients potentiels.';
$_MODULE['<{sekeywords}prestashop>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = 'Comment ça marche ?';
$_MODULE['<{sekeywords}prestashop>sekeywords_b1c0690abd0d8a2ac3fb6d4b2bf8299b'] = 'Quand un visiteur accède à un site internet, le serveur connaît l\'adresse du site précédent. Ce module analyse l\'adresse et identifie les mots clés inclus. Actuellement, il gère les moteurs suivants :';
$_MODULE['<{sekeywords}prestashop>sekeywords_be5d5d37542d75f93a87094459f76678'] = 'et';
$_MODULE['<{sekeywords}prestashop>sekeywords_eb10655ca8473952242f43a8ec6d420f'] = 'Bientôt il sera possible d\'ajouter dynamiquement de nouveaux moteurs de recherche à cette liste et ainsi contribuer au développement du module !';
$_MODULE['<{sekeywords}prestashop>sekeywords_8d01ac22a68176ddd7067da99508751d'] = '10 premiers mots clés';
$_MODULE['<{sekeywords}prestashop>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Autres';
