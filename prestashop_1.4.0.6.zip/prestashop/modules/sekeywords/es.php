<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sekeywords}prestashop>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Palabras clave en el motor de búsqueda';
$_MODULE['<{sekeywords}prestashop>sekeywords_ed37c33642aec5c295e8d67ff1afa95c'] = 'Mostrar qué palabras claves han llevado visitantes a su tienda';
$_MODULE['<{sekeywords}prestashop>sekeywords_a6a5cc2d3979e54597c79a68448adee2'] = 'palabra clave encontrada para su búsqueda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_abc9f128fb01c8504e08e77bfc8af795'] = 'palabras clave encontrada para su búsqueda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Palabras clave';
$_MODULE['<{sekeywords}prestashop>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Frecuencia';
$_MODULE['<{sekeywords}prestashop>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filtrar por palabra clave';
$_MODULE['<{sekeywords}prestashop>sekeywords_188ef1f71ff3ef1c5501dc5c8ee27f88'] = 'y un mínimo de incidencias';
$_MODULE['<{sekeywords}prestashop>sekeywords_03e0e9ef8b776b5f7bcc590e51bfa63b'] = 'Aplicar';
$_MODULE['<{sekeywords}prestashop>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'No hay palabras clave';
$_MODULE['<{sekeywords}prestashop>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{sekeywords}prestashop>sekeywords_060ce52fbf64d0ad58c1b984a4230bb6'] = 'Identifique las palabras claves externas en los motores de la búsqueda';
$_MODULE['<{sekeywords}prestashop>sekeywords_8443e994889501b92bff8f2d18d6ff4d'] = 'Hay muchas maneras de encontrar una Web, pero una de las más comunes es encontrarla con un buscador. Identificar la mayoría de las palabras claves incorporadas por sus nuevos visitantes es realmente importante, ya que le permite ver qué producto debe poner en valor si quiere más visitantes y clientes.';
$_MODULE['<{sekeywords}prestashop>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = '¿Cómo funciona?';
$_MODULE['<{sekeywords}prestashop>sekeywords_b1c0690abd0d8a2ac3fb6d4b2bf8299b'] = 'Cuando los visitantes vienen a su sitio Web, el servidor conoce su localización anterior. Este módulo analiza la URL y encuentra las palabras claves. Actualmente se utilizan los siguientes motores de búsqueda:';
$_MODULE['<{sekeywords}prestashop>sekeywords_be5d5d37542d75f93a87094459f76678'] = 'y';
$_MODULE['<{sekeywords}prestashop>sekeywords_eb10655ca8473952242f43a8ec6d420f'] = '¡Pronto será posible agregar dinámicamente un nuevo motor de búsqueda y colaborar en este módulo!';
$_MODULE['<{sekeywords}prestashop>sekeywords_8d01ac22a68176ddd7067da99508751d'] = '10 primeras palabras clave';
$_MODULE['<{sekeywords}prestashop>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Otros';
