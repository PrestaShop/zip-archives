<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockspecials}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Bloque promociones especiales';
$_MODULE['<{blockspecials}prestashop>blockspecials_8878bd8e86a6f57aacd3f6962f07ad77'] = 'Añadir un bloque con promociones especiales';
$_MODULE['<{blockspecials}prestashop>blockspecials_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmación';
$_MODULE['<{blockspecials}prestashop>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Parámetros actualizados';
$_MODULE['<{blockspecials}prestashop>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Parámetros ';
$_MODULE['<{blockspecials}prestashop>blockspecials_530c88f8210e022b39128e3f0409bbcf'] = 'Mostrar este bloque siempre';
$_MODULE['<{blockspecials}prestashop>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockspecials}prestashop>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockspecials}prestashop>blockspecials_a8a670d89a6d2f3fa59942fc591011ef'] = 'Mostrar este bloque aunque no haya productos disponibles';
$_MODULE['<{blockspecials}prestashop>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockspecials}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Promociones especiales';
$_MODULE['<{blockspecials}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Todas los promociones especiales';
$_MODULE['<{blockspecials}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'No hay promociones especiales en este momento';
