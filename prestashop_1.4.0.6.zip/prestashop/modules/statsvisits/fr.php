<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsvisits}prestashop>statsvisits_504c16c26a96283f91fb46a69b7c8153'] = 'Visites et visiteurs';
$_MODULE['<{statsvisits}prestashop>statsvisits_a985996212e180300abc7671c0f87b9a'] = 'Propose des graphiques montrant l\'évolution de vos visites et visiteurs';
$_MODULE['<{statsvisits}prestashop>statsvisits_9efcb563b932863f45ab70cbf1647a61'] = 'Une visite correspond au passage d\'un internaute sur votre boutique. Une seule visite est comptée pour toute la durée de sa session.';
$_MODULE['<{statsvisits}prestashop>statsvisits_f0f438eaff96f1b7297393df4f39a754'] = 'On appelle visiteur une personne inconnue - non inscrite ou non identifiée - naviguant sur votre boutique. Un visiteur peut donc visiter votre boutique plusieurs fois.';
$_MODULE['<{statsvisits}prestashop>statsvisits_54067074d24489ddb5654bf46642cb85'] = 'Nombre total de visites';
$_MODULE['<{statsvisits}prestashop>statsvisits_23e640d55e56db79971918936e95bf9d'] = 'Nombre total de visiteurs';
$_MODULE['<{statsvisits}prestashop>statsvisits_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsvisits}prestashop>statsvisits_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsvisits}prestashop>statsvisits_ffbee337f031c2282b311bac40bc8bb9'] = 'Déterminez l\'intérêt d\'une visite';
$_MODULE['<{statsvisits}prestashop>statsvisits_f3345d3c7e9115262ee0b84c9323c020'] = 'Le graphique d\'évolution des visiteurs ressemble fortement à celui des visites, mais vous apporte une information supplémentaire : vos visiteurs reviennent-ils ?';
$_MODULE['<{statsvisits}prestashop>statsvisits_411d6cd9206f9f510c274dbec2e28b0e'] = 'Si c\'est le cas, alors félicitations, votre site est bien conçu et plaît indéniablement.';
$_MODULE['<{statsvisits}prestashop>statsvisits_51ab590b150b00d5a64326d25a0320a4'] = 'Dans le cas contraire, la conclusion n\'est pas si simple. Le problème peut être esthétique ou ergonomique, ou alors l\'offre insuffisante. Il se peut également que ces visiteurs soient arrivés là par erreur, sans intérêt particulier pour votre boutique ; ce phénomène arrive couramment avec les moteurs de recherche.';
$_MODULE['<{statsvisits}prestashop>statsvisits_4793db9717cc512af1406b09766a0a1f'] = 'Cette information est surtout qualitative : c\'est à vous de déterminer l\'intérêt d\'une visite sans suite.';
$_MODULE['<{statsvisits}prestashop>statsvisits_39b960b0a5e2ebaaa638d946f1892050'] = 'Nombre de visites et visiteurs uniques';
$_MODULE['<{statsvisits}prestashop>statsvisits_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{statsvisits}prestashop>statsvisits_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visiteurs';
