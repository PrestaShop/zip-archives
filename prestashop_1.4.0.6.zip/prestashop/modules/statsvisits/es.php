<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsvisits}prestashop>statsvisits_504c16c26a96283f91fb46a69b7c8153'] = 'Visitas y Visitantes';
$_MODULE['<{statsvisits}prestashop>statsvisits_a985996212e180300abc7671c0f87b9a'] = 'Mostrar estadísticas sobre visitas y visitantes';
$_MODULE['<{statsvisits}prestashop>statsvisits_9efcb563b932863f45ab70cbf1647a61'] = 'Una visita corresponde a un usuario que visita su tienda. Hasta el final de la sesión se contabiliza una única visita.';
$_MODULE['<{statsvisits}prestashop>statsvisits_f0f438eaff96f1b7297393df4f39a754'] = 'Un visitante es una persona desconocida, que no se ha registrado ni abierto una sesión- que visita su tienda. Un visitante puede visitar su tienda varias veces.';
$_MODULE['<{statsvisits}prestashop>statsvisits_54067074d24489ddb5654bf46642cb85'] = 'Total de visitas:';
$_MODULE['<{statsvisits}prestashop>statsvisits_23e640d55e56db79971918936e95bf9d'] = 'Total de visitantes:';
$_MODULE['<{statsvisits}prestashop>statsvisits_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statsvisits}prestashop>statsvisits_ffbee337f031c2282b311bac40bc8bb9'] = 'Determinar el interés de las visitas';
$_MODULE['<{statsvisits}prestashop>statsvisits_f3345d3c7e9115262ee0b84c9323c020'] = 'La evolución del gráficovisitantes\' y del gráfico visitas\' proporciona una información adicional. ¿Los visitantes vuelven a visitar su tienda?';
$_MODULE['<{statsvisits}prestashop>statsvisits_411d6cd9206f9f510c274dbec2e28b0e'] = 'Si es el caso, enhorabuena, su sitio está bien pensado y resulta agradable.';
$_MODULE['<{statsvisits}prestashop>statsvisits_51ab590b150b00d5a64326d25a0320a4'] = 'En el caso contrario, la conclusión no es simple. El problema puede ser estético o ergonómico o la oferta no es suficiente. También es posible que el visitante haya llegado a su tienda sin un interés particular, es algo frecuente cuando se utilizan los motores de búsqueda.';
$_MODULE['<{statsvisits}prestashop>statsvisits_4793db9717cc512af1406b09766a0a1f'] = 'Esta información es sobre todo cualitativa.  Usted deberá determinar el interés de este tipo de visitas.';
$_MODULE['<{statsvisits}prestashop>statsvisits_39b960b0a5e2ebaaa638d946f1892050'] = 'Número de visitas y visitantes únicos';
$_MODULE['<{statsvisits}prestashop>statsvisits_d7e637a6e9ff116de2fa89551240a94d'] = 'Visitas';
$_MODULE['<{statsvisits}prestashop>statsvisits_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visitantes';
