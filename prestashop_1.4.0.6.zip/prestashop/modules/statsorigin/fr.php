<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Sites affluents';
$_MODULE['<{statsorigin}prestashop>statsorigin_7d69640885de8f6728246249b5b47f2d'] = 'Affiche les sites d\'origine de vos visiteurs';
$_MODULE['<{statsorigin}prestashop>statsorigin_14542f5997c4a02d4276da364657f501'] = 'Lien direct';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Origine';
$_MODULE['<{statsorigin}prestashop>statsorigin_87ed757da0ada41b18dbb926dcf2f802'] = 'Pourcentage des 10 meilleurs sites affluents par lesquels les visiteurs passent pour accéder à votre boutique.';
$_MODULE['<{statsorigin}prestashop>statsorigin_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Liens directs uniquement';
$_MODULE['<{statsorigin}prestashop>statsorigin_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsorigin}prestashop>statsorigin_64ae584c62d0992a911d52122ebefc9a'] = 'Qu\'est-ce qu\'un site affluent (référant) ?';
$_MODULE['<{statsorigin}prestashop>statsorigin_77de261cf4c31a96146bcf1b52fd9856'] = 'Lorsqu\'un internaute visite une page web, le site affluent est l\'URL du lien qu\'a suivi le visiteur pour accéder à sa page web actuelle.';
$_MODULE['<{statsorigin}prestashop>statsorigin_3e8320ca07ab88479144b380c82e51bd'] = 'Un référant vous permet de savoir quels sont les mots clés tapés par les visiteurs dans les moteurs de recherche quand ils tentent d\'aller sur votre boutique; et ainsi d\'optimiser le référencement de votre boutique.';
$_MODULE['<{statsorigin}prestashop>statsorigin_af19c8da1c414055c960a73d86471119'] = 'Un référant peut être :';
$_MODULE['<{statsorigin}prestashop>statsorigin_a3dec1a06e19a810a9a4884293f666d0'] = 'Quelqu\'un qui a mis un lien de votre boutique sur son site';
$_MODULE['<{statsorigin}prestashop>statsorigin_95b90f58e843b56885beabf4802676a9'] = 'Un partenaire avec lequel vous avez fait un échange de lien visant à rapporter des ventes ou attirer de nouveaux clients';
$_MODULE['<{statsorigin}prestashop>statsorigin_9465e6ab1ee03dea7b6c1eefdab8aa4b'] = '10 premiers sites';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Autres';
