<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksupplier}prestashop>blocksupplier_9ae42413e3cb9596efe3857f75bad3df'] = 'Bloque proveedor';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_e2452f139d5dd09e70de9e8ddbf6b371'] = 'Añadir un bloque para mostrar los proveedores';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'número de elementos no válido';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_bb30aac3161f999a357af767ce2fd7ec'] = 'Por favor, elija al menos uno de la lista';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_bfdff752293014f11f17122c92909ad5'] = 'Usar una lista de texto plano';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Mostrar';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_6a7f245843454cf4f28ad7c5e2572aa2'] = 'elementos';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_e7968f07cac2995b0dd917475a04b8be'] = 'Para mostrar los proveedores en lista de texto plano';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_b0fa976774d2acf72f9c62e9ab73de38'] = 'Usar un cuadro combinado';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_9df3ff87bf49ec39ccd11ae9aaaa593e'] = 'Para mostrar los proveedores dentro de un cuadro combinado';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Proveedores';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'Más sobre';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Todos los proveedores';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'No hay proveedores';
