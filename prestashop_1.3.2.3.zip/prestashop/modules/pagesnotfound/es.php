<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Página no encontrada';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_52a8f5d93ac4baca3b296bdef71248c6'] = 'Mostrar las páginas solicitadas por sus visitantes pero no encontradas';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6cb944288ac528fcfd76b20156dddce1'] = 'Usted debe utilizar un archivo .htaccess para volver a redirigir error 404 al \\\" de la página; 404.php\\\"';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Página';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referente';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contador';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Páginas no registradas';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'error 404';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_c7cf97a9d6cb9554b31a1158dd94c1c5'] = 'Error 404 es un código HTTP que significa que el archivo pedido por el usuario no se encuentra. En su caso esto significa que uno de sus visitantes introdujo una URL incorrecta en la  barra de direcciones o que usted tiene un enlace roto en alguna parte. Cuando está disponible, el referente se muestra, así puede encontrar la página que contiene el enlace roto. Si no, significa generalmente que es un acceso directo que ya no existe.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_a90083861c168ef985bf70763980aa60'] = '¿Como prevenir estos errores?';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_535ff57deda0b45d32cb37fd430accc8'] = 'Si su servidor soporta el archivo .htaccess, puede crear uno en el directorio raíz de PrestaShop e insertar la línea siguiente:';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_260161f71496fa1b160c50c2c2ea2401'] = 'El usuario que busca una página que no existe será reenviado a la página';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_feb436b0dabe28068aa6d866ac47bf0a'] = 'Este módulo registra los accesos a esta página: la página requerida, la referencia y el número de veces que se visitó.';
