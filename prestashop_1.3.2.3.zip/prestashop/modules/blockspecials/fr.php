<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockspecials}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Bloc promotions';
$_MODULE['<{blockspecials}prestashop>blockspecials_8878bd8e86a6f57aacd3f6962f07ad77'] = 'Ajoute un bloc proposant les produits en promotion actuellement';
$_MODULE['<{blockspecials}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Réductions';
$_MODULE['<{blockspecials}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Toutes les promos';
$_MODULE['<{blockspecials}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'Pas de promotion actuellement';
