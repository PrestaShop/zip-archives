<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gcheckout}prestashop>gcheckout_6c132b5e262594950586ae13a7d3aa94'] = 'Google Checkout';
$_MODULE['<{gcheckout}prestashop>gcheckout_3f3c0194c5adbe6953eb571f125af16d'] = 'Implémentation de l\'API de Google Checkout';
$_MODULE['<{gcheckout}prestashop>gcheckout_4402acab1c8f90dcf4a31dc96833bd86'] = 'Aucune devise disponible pour ce module';
$_MODULE['<{gcheckout}prestashop>gcheckout_82b8bb0d807e6d2e43a068f954c3559f'] = 'L\'ID marchand semble incorrect';
$_MODULE['<{gcheckout}prestashop>gcheckout_9dd37c2106ceacbf0a40778b2109c386'] = 'La clé marchand semble incorrecte';
$_MODULE['<{gcheckout}prestashop>gcheckout_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{gcheckout}prestashop>gcheckout_cdd506f9916fb2a6c2a901eb79928176'] = 'Utilisez le mode bac à sable pour tester le module avant de l\'utiliser en mode réel. N\'oubliez pas de changer vos clés et ID marchand selon le mode !';
$_MODULE['<{gcheckout}prestashop>gcheckout_650be61892bf690026089544abbd9d26'] = 'Mode';
$_MODULE['<{gcheckout}prestashop>gcheckout_7f80fcc452c2f1ed2bb51b39d0864df1'] = 'Réel';
$_MODULE['<{gcheckout}prestashop>gcheckout_2652eec977dcb2a5aea85f5bec235b05'] = 'Bac à sable';
$_MODULE['<{gcheckout}prestashop>gcheckout_76055653a95e0a559b734ec322d89632'] = 'Vous trouverez ces identifiants dans votre compte Google Checkout > Settings > Integration. Les modes réel et bac à sable ont tous les deux besoin de ces clés.';
$_MODULE['<{gcheckout}prestashop>gcheckout_229a7ec501323b94db7ff3157a7623c9'] = 'ID marchand';
$_MODULE['<{gcheckout}prestashop>gcheckout_795acb9a0c89791314d3032fe65eeb92'] = 'Clé marchand';
$_MODULE['<{gcheckout}prestashop>gcheckout_74692aae1cff5dc9dfd44f8c4e0540ad'] = 'Vous pouvez archiver les échanges de serveur à serveur. Les fichiers d\'archives sont';
$_MODULE['<{gcheckout}prestashop>gcheckout_be5d5d37542d75f93a87094459f76678'] = 'et';
$_MODULE['<{gcheckout}prestashop>gcheckout_ce103162a276684df5afb8221cfa0469'] = 'Si vous activez les logs, soyez certain de protéger ces fichiers en plaçant un fichier .htaccess dans le même répertoire. Si vous ne le faites pas, ils seront lisibles par tous vos clients.';
$_MODULE['<{gcheckout}prestashop>gcheckout_b2d37ae1cedf42ff874289b721860af2'] = 'Archivage';
$_MODULE['<{gcheckout}prestashop>gcheckout_38fb7d24e0d60a048f540ecb18e13376'] = 'Enregistrer';
$_MODULE['<{gcheckout}prestashop>gcheckout_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informations';
$_MODULE['<{gcheckout}prestashop>gcheckout_c4ddab20febbb0e75bb211ac8cd4c541'] = 'Pour utiliser votre module Google Checkout, vous devez configurer votre compte marchand (en mode bac à sable comme en mode réel). Accédez à votre compte Google Checkout puis allez dans Settings > Integration. L\'API callback URL doit être :';
$_MODULE['<{gcheckout}prestashop>gcheckout_dba727a9adc372723baef4533a7fc9da'] = 'La \"callback method\" doit être réglée sur';
$_MODULE['<{gcheckout}prestashop>gcheckout_e2e882d58bbd478e17c5a542d5d6fcda'] = 'Les commandes doivent être passées en utilisant la même devise que celle indiquée dans votre compte marchand. Les paniers utilisant d\'autres devises seront convertis si l\'utilisateur décide de payer par le biais de ce module.';
$_MODULE['<{gcheckout}prestashop>gcheckout_ba794350deb07c0c96fe73bd12239059'] = 'Emballage';
$_MODULE['<{gcheckout}prestashop>gcheckout_9f06b28a40790c4c4df5739bce3c1eb0'] = 'Frais de port';
$_MODULE['<{gcheckout}prestashop>gcheckout_8dd85f4218069de952672fe3180dacdb'] = 'Payer par GoogleCheckout';
