<?php

$objectType = 'manufacturer';
include('./supplier.php');

?>
