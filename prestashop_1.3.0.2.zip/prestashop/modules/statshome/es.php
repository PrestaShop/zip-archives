<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statshome}prestashop>statshome_ebfb30fd5243ea9bd08ad87767a48d02'] = 'Estadísticas condensadas para su Back Office';
$_MODULE['<{statshome}prestashop>statshome_28ddffd1b82be359f1e4923449bd005b'] = 'Muestre un pequeño bloque de estadísticas en la página de inicio de su Back Office ';
$_MODULE['<{statshome}prestashop>statshome_c33e404a441c6ba9648f88af3c68a1ca'] = 'Estadísticas';
$_MODULE['<{statshome}prestashop>statshome_4eb156db59c5508589ac9c40f2d08979'] = 'de ventas';
$_MODULE['<{statshome}prestashop>statshome_d53ddf87a983739d49e0da0c1fa64925'] = 'registros';
$_MODULE['<{statshome}prestashop>statshome_563873d38950b841aebf89c3be1b1a35'] = 'registro';
$_MODULE['<{statshome}prestashop>statshome_f8dd8e31c0fc28084d45bb517d6cfdc2'] = 'pedidos realizados';
$_MODULE['<{statshome}prestashop>statshome_8a6d9d2ea0d85d7399e44045975a05a0'] = 'pedido realizado';
$_MODULE['<{statshome}prestashop>statshome_f2fc2cd700fd9a2fe66ac16c35331b94'] = 'páginas de producto visitadas';
$_MODULE['<{statshome}prestashop>statshome_c6ec77de3e93b75196f91e2df9c567ca'] = 'página de producto visitada';
$_MODULE['<{statshome}prestashop>statshome_8ff922bbcd8ad41cdfc48d3c5163b2ab'] = 'Calendario';
$_MODULE['<{statshome}prestashop>statshome_03727ac48595a24daed975559c944a44'] = 'Día';
$_MODULE['<{statshome}prestashop>statshome_7cbb885aa1164b390a0bc050a64e1812'] = 'Mes';
$_MODULE['<{statshome}prestashop>statshome_537c66b24ef5c83b7382cdc3f34885f2'] = 'Año';
$_MODULE['<{statshome}prestashop>statshome_6799f652047c465ff8affc8c98cc4a74'] = 'Visitantes actualmente en línea:';
