<?php

$controller = new FrontController();
$controller->displayFooter();

?>