<?php

$controller = new FrontController();
$controller->setMedia();
$controller->displayHeader();

?>