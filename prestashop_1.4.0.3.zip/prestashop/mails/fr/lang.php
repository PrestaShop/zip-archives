<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Welcome!'] = 'Bienvenue !';
$_LANGMAIL['Message from contact form'] = 'Message depuis le formulaire de contact';
$_LANGMAIL['Your message has been correctly sent'] = 'Votre message a bien été envoyé';
$_LANGMAIL['New credit slip regarding your order #'] = '';
$_LANGMAIL['Virtual product to download'] = 'Produit virtuel à télécharger';
$_LANGMAIL[' \'Fwd: Customer message\''] = '';
$_LANGMAIL[' ((is_array($_LANGMAIL) AND key_exists($subject'] = '';
$_LANGMAIL['Order confirmation'] = 'Confirmation de commande';
$_LANGMAIL['Message from a customer'] = 'Message d\'un client';
$_LANGMAIL['New message regarding your order'] = '';
$_LANGMAIL['Your order return state has changed'] = '';
$_LANGMAIL['Your password'] = 'Votre nouveau mot de passe';
$_LANGMAIL['Password query confirmation'] = 'Confirmation de demande de mot de passe';
$_LANGMAIL['\'An answer to your message is available\''] = '';
$_LANGMAIL['New voucher regarding your order #'] = '';
$_LANGMAIL['Happy birthday!'] = '';
$_LANGMAIL['Newsletter confirmation'] = '';
$_LANGMAIL['Newsletter voucher'] = '';
$_LANGMAIL['Your wishlist\\\'s link'] = '';
$_LANGMAIL['Message from '] = '';
$_LANGMAIL['Your cart and your discount'] = '';
$_LANGMAIL['Thanks for your order'] = '';
$_LANGMAIL['You are one of our best customers'] = '';
$_LANGMAIL['We miss you'] = '';
$_LANGMAIL['Product available'] = '';
$_LANGMAIL['New order'] = '';
$_LANGMAIL['Product out of stock'] = '';
$_LANGMAIL['Error reporting from your PayPalAPI module'] = '';
$_LANGMAIL['Congratulations!'] = '';
$_LANGMAIL['Referral Program'] = 'Programme de parrainage';
$_LANGMAIL['A friend sent you a link to'] = '';

?>