tinyMCE.addI18n('ro.advhr_dlg',{
width:"Latime",
size:"Inaltime",
noshade:"Fara umbre"
});