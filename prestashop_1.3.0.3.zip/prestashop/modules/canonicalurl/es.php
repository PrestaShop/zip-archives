<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{canonicalurl}prestashop>canonicalurl_ee096b45f2e0dcd83771ea27b049c76a'] = 'URL canónica';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_304a7444905effab23fcd6da6e2c9ab4'] = 'Mejora la SEO evitando el estado « duplicate content » en su tienda.';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_d7141d13c32f8cbe353804bdc69f4a94'] = 'Debe parametrar la URL canónica de su sitio para evitar el estado « duplicate content » en su tienda.';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_b573a17fc6b9327afdebe42f777c744e'] = 'URL canónica : URL no valida';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmación';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_c888438d14855d7d96a2724ee9c306bd'] = 'Parámetros actualizados';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_f4f70727dc34561dfde1a3c529b6205c'] = 'Parámetros';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_e59cdd8d50a28028c669e58d55ad130d'] = 'Elija el nombre de dominio principal para su referenciamiento (ej : www.mitienda.com, etc…) Nota : no incluir la última barra invertida (« / »), el sufijo \"/index.php\" ni el prefijo \"http(s)://\".';
$_MODULE['<{canonicalurl}prestashop>canonicalurl_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
