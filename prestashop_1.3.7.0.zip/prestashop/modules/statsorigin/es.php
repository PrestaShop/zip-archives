<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Origen de los visitantes';
$_MODULE['<{statsorigin}prestashop>statsorigin_b860f6548aca73c7da23337804e6022e'] = 'Mostrar los sitios Web de origen de sus visitantes';
$_MODULE['<{statsorigin}prestashop>statsorigin_14542f5997c4a02d4276da364657f501'] = 'Enlace directo';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Origen';
$_MODULE['<{statsorigin}prestashop>statsorigin_3a137c6a46a87a887817f0a17b729e82'] = 'Este es el porcentaje de los 1o sitios más populaares de referencia a través de los cuales los visitantes llegaron a su tienda. rnrnrnrn';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Enlaces directos solamente';
$_MODULE['<{statsorigin}prestashop>statsorigin_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statsorigin}prestashop>statsorigin_64ae584c62d0992a911d52122ebefc9a'] = '¿Cuál es el sitio web referente?';
$_MODULE['<{statsorigin}prestashop>statsorigin_77de261cf4c31a96146bcf1b52fd9856'] = 'Cuando se visita una página web, el referente es la URL de la página web anterior desde la cual se siguió el enlace.';
$_MODULE['<{statsorigin}prestashop>statsorigin_3e8320ca07ab88479144b380c82e51bd'] = 'Un referente le permite saber qué palabras claves incorporan los visitantes en motores de búsqueda cuando intentan acceder a su tienda; y también optimizar su promoción en la Webrnrn';
$_MODULE['<{statsorigin}prestashop>statsorigin_af19c8da1c414055c960a73d86471119'] = 'Un referente puede ser';
$_MODULE['<{statsorigin}prestashop>statsorigin_1a96cc9152cd011db4cb78a773f68614'] = 'Alguien ha colocado un enlace en su sitio web hacia su tienda';
$_MODULE['<{statsorigin}prestashop>statsorigin_95b90f58e843b56885beabf4802676a9'] = 'Un colaborador con quien intercambió enlaces para aumentar las ventas o para atraer nueva clientela. ';
$_MODULE['<{statsorigin}prestashop>statsorigin_9465e6ab1ee03dea7b6c1eefdab8aa4b'] = '10 primeros sitios web';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Otros';
