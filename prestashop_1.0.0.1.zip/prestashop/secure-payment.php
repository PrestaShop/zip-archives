<?php

include(dirname(__FILE__).'/config/config.inc.php');
include(dirname(__FILE__).'/header.php');

$smarty->assign('shop_name', Tools::safeOutput(Configuration::get('PS_SHOP_NAME')));
$smarty->display(_PS_THEME_DIR_.'secure-payment.tpl');

include(dirname(__FILE__).'/footer.php');

?>