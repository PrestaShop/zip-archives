SET NAMES 'utf8';

INSERT INTO `PREFIX_configuration` (`name`, `value`, `date_add`, `date_upd`) VALUES
('PS_CARRIER_DEFAULT', '2', NOW(), NOW()),
('PAYPAL_BUSINESS', 'your-paypal@address.com', NOW(), NOW()),
('PAYPAL_SANDBOX', 0, NOW(), NOW()),
('BANK_WIRE_CURRENCIES', '2,1', NOW(), NOW()),
('CHEQUE_CURRENCIES', '2,1', NOW(), NOW()),
('PRODUCTS_VIEWED_NBR', '2', NOW(), NOW()),
('BLOCK_CATEG_DHTML', '1', NOW(), NOW()),
('BLOCK_CATEG_MAX_DEPTH', '3', NOW(), NOW()),
('MANUFACTURER_DISPLAY_FORM', '1', NOW(), NOW()),
('MANUFACTURER_DISPLAY_TEXT', '1', NOW(), NOW()),
('MANUFACTURER_DISPLAY_TEXT_NB', '5', NOW(), NOW()),
('NEW_PRODUCTS_NBR', '5', NOW(), NOW());

INSERT INTO `PREFIX_module` (`id_module`, `name`, `active`) VALUES
(1, 'homefeatured', 1),
(2, 'gsitemap', 1),
(3, 'cheque', 1),
(4, 'paypal', 1),
(5, 'editorial', 1),
(6, 'bankwire', 1),
(7, 'blockadvertising', 1),
(8, 'blockbestsellers', 1),
(9, 'blockcart', 1),
(10, 'blockcategories', 1),
(11, 'blockcurrencies', 1),
(12, 'blockinfos', 1),
(13, 'blocklanguages', 1),
(14, 'blockmanufacturer', 1),
(15, 'blockmyaccount', 1),
(16, 'blocknewproducts', 1),
(17, 'blockpaymentlogo', 1),
(18, 'blockpermanentlinks', 1),
(19, 'blocksearch', 1),
(20, 'blockspecials', 1),
(21, 'blocktags', 1),
(22, 'blockuserinfo', 1),
(23, 'blockvariouslinks', 1),
(24, 'blockviewed', 1);

INSERT INTO `PREFIX_hook_module` (`id_module`, `id_hook`, `position`) VALUES
(3, 1, 1),
(6, 1, 2),
(4, 1, 3),
(8, 2, 1),
(3, 4, 1),
(6, 4, 2),
(9, 6, 1),
(16, 6, 2),
(8, 6, 3),
(20, 6, 4),
(15, 7, 1),
(21, 7, 2),
(10, 7, 3),
(24, 7, 4),
(14, 7, 5),
(12, 7, 6),
(7, 7, 7),
(17, 7, 8),
(5, 8, 1),
(1, 8, 2),
(11, 14, 1),
(13, 14, 2),
(18, 14, 3),
(19, 14, 4),
(22, 14, 5),
(8, 19, 1),
(23, 21, 1);

INSERT INTO `PREFIX_carrier` (`id_carrier`, `id_tax`, `name`, `active`, `deleted`, `shipping_handling`) VALUES
(1, 0, 0, 1, 0, 0),
(2, 1, 'My carrier', 1, 0, 1);
INSERT INTO `PREFIX_carrier_lang` (`id_carrier`, `id_lang`, `delay`) VALUES
(1, 1, 'Pick up in-store'),
(1, 2, 'Retrait au magasin'),
(2, 1, 'Delivery next day!'),
(2, 2, 'Livraison le lendemain !');
INSERT INTO `PREFIX_carrier_zone` (`id_carrier`, `id_zone`) VALUES
(1, 1),
(2, 1),
(2, 2);

INSERT INTO `PREFIX_range_price` (`id_range_price`, `delimiter1`, `delimiter2`) VALUES
(1, 0, 10000);
INSERT INTO `PREFIX_range_weight` (`id_range_weight`, `delimiter1`, `delimiter2`) VALUES
(1, 0, 10000);
INSERT INTO `PREFIX_delivery` (`id_delivery`, `id_range_price`, `id_range_weight`, `id_carrier`, `id_zone`, `price`) VALUES
(1, NULL, 1, 2, 1, 5.00),
(2, NULL, 1, 2, 2, 5.00),
(4, 1, NULL, 2, 1, 5.00),
(5, 1, NULL, 2, 2, 5.00);

INSERT INTO `PREFIX_manufacturer` VALUES (1, 'Apple', NOW(), NOW());
INSERT INTO `PREFIX_supplier` VALUES (1, 'AppleStore', NOW(), NOW());

INSERT INTO `PREFIX_product` VALUES (1, 1, 1, 1, 2, 0, '0', 0.00, 100, 174.7492, 92.0000, 0.00, 10, '', 0.5, 2, 0, 1, NOW(), NOW());
INSERT INTO `PREFIX_product` VALUES (2, 1, 1, 1, 2, 0, '0', 0.00, 12, 66.0535, 33.0000, 0.00, 0, '', 0, 2, 0, 1, NOW(), NOW());
INSERT INTO `PREFIX_product` VALUES (3, 0, 0, 1, 3, 0, '0', 0.00, 15, 37.6254, 12.0000, 0.00, 0, '', 0, 2, 0, 1, NOW(), NOW());
INSERT INTO `PREFIX_product` VALUES (4, 0, 0, 1, 3, 0, '0', 0.00, 50, 50.1254, 24.0000, 0.00, 0, '', 0, 2, 0, 1, NOW(), NOW());
INSERT INTO `PREFIX_product` VALUES (5, 1, 1, 1, 1, 0, '0', 0.00, 274, 1504.180602, 1000.000000, 0.00, 0, '', 1.36, 2, 0, 1, NOW(), NOW());
INSERT INTO `PREFIX_product` VALUES (6, 1, 1, 1, 4, 0, '0', 0.00, 250, 1170.568561, 0.000000, 0.00, 0, '', 0.75, 2, 0, 1, NOW(), NOW());

INSERT INTO `PREFIX_product_lang` VALUES (1, 1, 'Look like a rock star. Your music says a lot about you. So should your iPod nano. A super-slim design says you always have room for music &mdash; up to 2,000 songs, in fact. Durable anodized aluminum says you won&rsquo;t let the rough and tumble of everyday life ruin your groove. And one of five colors says whatever you want. Choose your hue and make a statement. 						 						 						Carry a tune (or 2,000) 						Choose a 2GB, 4GB, or 8GB iPod nano and add a soundtrack to your life. Just use iTunes to import your CDs, shop for 99&cent; songs on the iTunes Store, then sync them to iPod nano. Possibly the world&rsquo;s coolest photo album, iPod nano holds up to 25,000 snapshots.2 iPod nano plays audiobooks and podcasts from the iTunes Store, too.', 'A thinner design. Five stylish colors. A brighter display. Up to 24 hours of battery life. Just about the only thing that hasn&rsquo;t changed is the name. In 2GB, 4GB, and 8GB models starting at $149, iPod nano puts up to 2,000 songs in your pocket.', 'ipod-nano', '', '', '', 'iPod Nano', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (1, 2, 'Jouez les rock stars. La musique que vous &eacute;coutez en dit long sur votre personnalit&eacute;. Il en va de même pour votre iPod nano. Un design ultra-fin laisse entendre que vous n''êtes jamais &agrave; court d''espace pour stocker des chansons : jusqu''&agrave; 2 000 tr&egrave;s pr&eacute;cis&eacute;ment. La r&eacute;sistance de l''aluminium anodis&eacute; indique que vous n''êtes pas du genre &agrave; laisser les al&eacute;as de la vie quotidienne vous faire perdre le rythme. Enfin, chacun des cinq coloris r&eacute;v&egrave;le tout ce qu''il vous pla&icirc;t de montrer. Alors, choisissez votre teinte et affirmez votre diff&eacute;rence.  				  				 				Prenez le large avec 2 000 chansons 				Choisissez un iPod nano de 2, 4 ou 8 Go et mettez votre vie en musique. Il vous suffit d''utiliser iTunes pour importer vos CD ou d''acheter des chansons &agrave; 0,99 &euro; sur iTunes Store, puis de les synchroniser sur votre iPod nano.', 'Un design plus fin. Cinq coloris tendan&agrave;ce. Un &eacute;cran plus lum&eacute;ineux. Jusqu''à 24 heures d''autonomie. La seule chose, ou presque, qui n''ait pas changé, c''est son nom', 'ipod-nano', '', '', '', 'iPod Nano', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (2, 1, 'One size fits all. You know what they say about good things and small packages. But when something 1.62 inches long and about half an ounce holds up to 240 songs, &ldquo;good&rdquo; and &ldquo;small&rdquo; don&rsquo;t cut it. Especially when you can listen to your music for up to 12 continuous hours.2 In fact, iPod shuffle just may be the biggest thing in small. 						 							 							Ready to wear 							Clip it to your coin pocket. Clip it to your bag. No matter where you clip your skip-free iPod shuffle, you&rsquo;ll have instant access to music. In silver, pink, green, blue, and orange, iPod shuffle goes with everything. Put it on, turn it up, and turn some heads.', 'In five brilliant colors and just $79, the 1GB iPod shuffle lets you wear up to 240 songs on your sleeve. Or your lapel. Or your belt. Clip on iPod shuffle and wear it as a badge of musical devotion.', 'ipod-shuffle', '', '', '', 'iPod shuffle', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (2, 2, 'Int&eacute;gration parfaite. Vous savez ce qu''on dit : compacit&eacute; rime rarement avec qualit&eacute;. Mais quand un appareil de 4,1cm de long et d''environ 15 g peut contenir jusqu''&agrave; 240 chansons, ces arguments ne tiennent plus. Surtout quand on peut &eacute;couter jusqu''&agrave; 12 heures de musique non-stop.2 Malgr&eacute; sa petite taille, iPod shuffle joue dans la cour des grands. 						 							 							Prêt-&agrave;-porter 							Accrochez-le &agrave; votre poche  de pantalon ou &agrave; votre sac. Quel que soit l''endroit o&ugrave; vous fixez votre iPod shuffle &agrave; lecture garantie sans saute, vous acc&eacute;dez instantan&eacute;ment &agrave; votre musique. En couleur argent, rose, vert, bleu ou orange, iPod shuffle se marie avec tout. Mettez-le, montez le son et faites des envieux.', 'Disponible en cinq coloris &eacute;clatants au prix de 79 &euro; seulement, le mod&egrave;le iPod shuffle 1 Go vous permet de porter jusqu''&agrave; 240 chanso&agrave;&agrave;ns accroch&eacute;es à votre manche. Ou au revers de votre veste. Ou encore à votre ceinture. ', 'ipod-shuffle', '', '', '', 'iPod shuffle', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (3, 1, 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis vitae justo. Cras ut ipsum. Integer tincidunt ligula ac sem. Praesent velit. Sed quam mauris, ullamcorper eget, dictum ac, consequat vel, orci. Donec quis turpis eget augue venenatis ornare. Donec risus quam, tempus et, cursus quis, tincidunt nec, ante. Quisque ut mi. Maecenas luctus nunc nec sem. Maecenas id ante vitae massa luctus aliquam. Etiam nisi enim, euismod et, consectetuer at, aliquet non, enim. Integer aliquam condimentum erat. Sed non orci. Vivamus lacinia gra', 'Ut dignissim. Aenean orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris purus. ', 'luxury-cover-for-ipod-video', '', '', '', 'Luxury cover for iPod video', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (3, 2, 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis vitae justo. Cras ut ipsum. Integer tincidunt ligula ac sem. Praesent velit. Sed quam mauris, ullamcorper eget, dictum ac, consequat vel, orci. Donec quis turpis eget augue venenatis ornare. Donec risus quam, tempus et, cursus quis, tincidunt nec, ante. Quisque ut mi. Maecenas luctus nunc nec sem. Maecenas id ante vitae massa luctus aliquam. Etiam nisi enim, euismod et, consectetuer at, aliquet non, enim. Integer aliquam condimentum erat. Sed non orci. Vivamus lacinia gra', 'Ut dignissim. Aenean orci. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris purus.', 'housse-luxe-pour-ipod-video', '', '', '', 'Housse luxe pour iPod vid&eacute;o', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (4, 1, 'Sed libero. Cras nibh urna, sagittis ac, laoreet eu, fermentum vel, nulla. Cras ipsum. Proin sit amet justo. Nam id massa. Nullam eget dui. Maecenas feugiat scelerisque sem. Ut in leo quis metus ullamcorper imperdiet. Quisque urna nisi, tempor at, feugiat in, varius vel, dui. Quisque vitae risus. Praesent blandit. In eros dui, congue nec, tempor quis, faucibus sit amet, magna. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus mi eros, pretium eu, nonummy at, dictum quis, libero. Aliquam non turpis. Morbi sit amet tellus. Praesent nonummy, massa a convallis ullamcorper, dui turpis eleifend leo, vitae sodales nibh eros blandit urna.', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Fusce vel est. Nunc nonummy. Etiam tincidunt. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Vivamus suscipit. Nam mattis. Maecenas elementum mi eget nunc.', 'ipod-nano-cover-myglove', '', '', '', 'iPod Nano cover MyGlove', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (4, 2, 'Caract&eacute;ristiques &bull; Cuir pour ganterie premi&egrave;re qualit&eacute; unique avec impressions de fleurs &bull; Doublure cuir pour ganterie blanc &bull; Molette cliquable accessible &agrave; travers le cuir fin &bull; Acc&egrave;s &eacute;cran int&eacute;gral &bull; Accessibilit&eacute; de tous les ports &bull; Protection renforc&eacute;e avec le rabat Compatibilit&eacute; &bull; iPod nano 2e g&eacute;n&eacute;ration &bull; iPod nano 1re g&eacute;n&eacute;ration', 'Fabriqu&eacute; dans un cuir pour ganterie, doux et de premi&egrave;re qualit&eacute;, cet &eacute;tui s''adapte &agrave; votre iPod nano comme un gant et permet un acc&egrave;s &agrave; toutes les commandes.', 'etui-pochette-en-cuir-imprime-myglove', '', '', '', 'Etui pochette en cuir imprim&eacute; MyGlove', 'En stock');
INSERT INTO `PREFIX_product_lang` VALUES (5, 1, '<p>MacBook Air is nearly as thin as your index finger. Practically every detail that could be streamlined has been. Yet it still has a 13.3-inch widescreen LED display, full-size keyboard, and large multi-touch trackpad. It&rsquo;s incomparably portable without the usual ultraportable screen and keyboard compromises.</p><p>The incredible thinness of MacBook Air is the result of numerous size- and weight-shaving innovations. From a slimmer hard drive to strategically hidden I/O ports to a lower-profile battery, everything has been considered and reconsidered with thinness in mind.</p><p>MacBook Air is designed and engineered to take full advantage of the wireless world. A world in which 802.11n Wi-Fi is now so fast and so available, people are truly living untethered &mdash; buying and renting movies online, downloading software, and sharing and storing files on the web. </p>', 'MacBook Air is ultrathin, ultraportable, and ultra unlike anything else. But you don&rsquo;t lose inches and pounds overnight. It&rsquo;s the result of rethinking conventions. Of multiple wireless innovations. And of breakthrough design. With MacBook Air, mobile computing suddenly has a new standard.', 'macbook-air', '', '', '', 'MacBook Air', '');
INSERT INTO `PREFIX_product_lang` VALUES (5, 2, '<p>MacBook Air est presque aussi fin que votre index. Pratiquement tout ce qui pouvait &ecirc;tre simplifi&eacute; l''a &eacute;t&eacute;. Il n''en dispose pas moins d''un &eacute;cran panoramique de 13,3 pouces, d''un clavier complet et d''un vaste trackpad multi-touch. Incomparablement portable il vous &eacute;vite les compromis habituels en mati&egrave;re d''&eacute;cran et de clavier ultra-portables.</p><p>L''incroyable finesse de MacBook Air est le r&eacute;sultat d''un grand nombre d''innovations en termes de r&eacute;duction de la taille et du poids. D''un disque dur plus fin &agrave; des ports d''E/S habilement dissimul&eacute;s en passant par une batterie plus plate, chaque d&eacute;tail a &eacute;t&eacute; consid&eacute;r&eacute; et reconsid&eacute;r&eacute; avec la finesse &agrave; l''esprit.</p><p>MacBook Air a &eacute;t&eacute; con&ccedil;u et &eacute;labor&eacute; pour profiter pleinement du monde sans fil. Un monde dans lequel la norme Wi-Fi 802.11n est d&eacute;sormais si rapide et si accessible qu''elle permet v&eacute;ritablement de se lib&eacute;rer de toute attache pour acheter des vid&eacute;os en ligne, t&eacute;l&eacute;charger des logiciels, stocker et partager des fichiers sur le Web. </p>', 'MacBook Air est ultra-fin, ultra-portable et ultra-diff&eacute;rent de tout le reste. Mais on ne perd pas des kilos et des centim&egrave;tres en une nuit. C''est le r&eacute;sultat d''une r&eacute;invention des normes. D''une multitude d''innovations sans fil. Et d''une r&eacute;volution dans le design. Avec MacBook Air, l''informatique mobile prend soudain une nouvelle dimension.', 'macbook-air', '', '', '', 'MacBook Air', '');
INSERT INTO `PREFIX_product_lang` VALUES (6, 1, 'Every MacBook has a larger hard drive, up to 250GB, to store growing media collections and valuable data.<br /><br />The 2.4GHz MacBook models now include 2GB of memory standard — perfect for running more of your favorite applications smoothly.', 'MacBook makes it easy to hit the road thanks to its tough polycarbonate case, built-in wireless technologies, and innovative MagSafe Power Adapter that releases automatically if someone accidentally trips on the cord.', 'macbook', '', '', '', 'MacBook', '');
INSERT INTO `PREFIX_product_lang` VALUES (6, 2, 'Chaque MacBook est &eacute;quip&eacute; d''un disque dur plus spacieux, d''une capacit&eacute; atteignant 250 Go, pour stocker vos collections multim&eacute;dia en expansion et vos donn&eacute;es pr&eacute;cieuses.<br /><br />Le mod&egrave;le MacBook &agrave; 2,4 GHz int&egrave;gre d&eacute;sormais 2 Go de m&eacute;moire en standard. L''id&eacute;al pour ex&eacute;cuter en souplesse vos applications pr&eacute;f&eacute;r&eacute;es.', 'MacBook vous offre la libert&eacute; de mouvement grâce &agrave; son bo&icirc;tier r&eacute;sistant en polycarbonate, &agrave; ses technologies sans fil int&eacute;gr&eacute;es et &agrave; son adaptateur secteur MagSafe novateur qui se d&eacute;connecte automatiquement si quelqu''un se prend les pieds dans le fil.', 'macbook', '', '', '', 'MacBook', '');

INSERT INTO `PREFIX_category` VALUES (2, 1, 1, 1, NOW(), NOW());
INSERT INTO `PREFIX_category` VALUES (3, 1, 1, 1, NOW(), NOW());
INSERT INTO `PREFIX_category` VALUES (4, 1, 1, 1, NOW(), NOW());

INSERT INTO `PREFIX_category_lang` VALUES (2, 1, 'iPods', 'Now that you can buy movies from the iTunes Store and sync them to your iPod, the whole world is your theater.', 'music-ipods', '', '', '');
INSERT INTO `PREFIX_category_lang` VALUES (2, 2, 'iPods', 'Il est temps, pour le meilleur lecteur de musique, de remonter sur sc&egrave;ne pour un rappel. Avec le nouvel iPod, le monde est votre sc&egrave;ne.', 'musique-ipods', '', '', '');
INSERT INTO `PREFIX_category_lang` VALUES (3, 1, 'Accessories', 'Wonderful accessories for your iPod', 'accessories-ipod', '', '', '');
INSERT INTO `PREFIX_category_lang` VALUES (3, 2, 'Accessoires', 'Tous les accessoires &agrave; la mode pour votre iPod', 'accessoires-ipod', '', '', '');
INSERT INTO `PREFIX_category_lang` VALUES (4, 1, 'Laptops', 'The latest Intel processor, a bigger hard drive, plenty of memory, and even more new features all fit inside just one liberating inch. The new Mac laptops have the performance, power, and connectivity of a desktop computer. Without the desk part.', 'laptops', 'Apple laptops', 'Apple laptops MacBook Air', 'Powerful and chic Apple laptops');
INSERT INTO `PREFIX_category_lang` VALUES (4, 2, 'Portables', 'Le tout dernier processeur Intel, un disque dur plus spacieux, de la m&eacute;moire &agrave; profusion et d''autres nouveaut&eacute;s. Le tout, dans &agrave; peine 2,59 cm qui vous lib&egrave;rent de toute entrave. Les nouveaux portables Mac r&eacute;unissent les performances, la puissance et la connectivit&eacute; d''un ordinateur de bureau. Sans la partie bureau.', 'portables-apple', 'portables apple', 'portables apple macbook air', 'portables apple puissants et design');

INSERT INTO `PREFIX_category_product` VALUES (1, 1, 1);
INSERT INTO `PREFIX_category_product` VALUES (1, 2, 2);
INSERT INTO `PREFIX_category_product` VALUES (1, 3, 3);
INSERT INTO `PREFIX_category_product` VALUES (1, 6, 4);
INSERT INTO `PREFIX_category_product` VALUES (2, 1, 1);
INSERT INTO `PREFIX_category_product` VALUES (2, 2, 2);
INSERT INTO `PREFIX_category_product` VALUES (3, 3, 3);
INSERT INTO `PREFIX_category_product` VALUES (3, 4, 4);
INSERT INTO `PREFIX_category_product` VALUES (4, 5, 1);
INSERT INTO `PREFIX_category_product` VALUES (4, 6, 2);

INSERT INTO `PREFIX_attribute_group` VALUES (1);
INSERT INTO `PREFIX_attribute_group` VALUES (2);
INSERT INTO `PREFIX_attribute_group` VALUES (3);

INSERT INTO `PREFIX_attribute_group_lang` VALUES (1, 1, 'Disk space', 'Disk space');
INSERT INTO `PREFIX_attribute_group_lang` VALUES (1, 2, 'Capacit&eacute;', 'Capacit&eacute;');
INSERT INTO `PREFIX_attribute_group_lang` VALUES (2, 1, 'Color', 'Color');
INSERT INTO `PREFIX_attribute_group_lang` VALUES (2, 2, 'Couleur', 'Couleur');
INSERT INTO `PREFIX_attribute_group_lang` VALUES (3, 1, 'ICU', 'Processor');
INSERT INTO `PREFIX_attribute_group_lang` VALUES (3, 2, 'ICU', 'Processeur');

INSERT INTO `PREFIX_attribute` VALUES (1, 1);
INSERT INTO `PREFIX_attribute` VALUES (2, 1);
INSERT INTO `PREFIX_attribute` VALUES (3, 2);
INSERT INTO `PREFIX_attribute` VALUES (4, 2);
INSERT INTO `PREFIX_attribute` VALUES (5, 2);
INSERT INTO `PREFIX_attribute` VALUES (6, 2);
INSERT INTO `PREFIX_attribute` VALUES (7, 2);
INSERT INTO `PREFIX_attribute` VALUES (8, 1);
INSERT INTO `PREFIX_attribute` VALUES (9, 1);
INSERT INTO `PREFIX_attribute` VALUES (10, 3);
INSERT INTO `PREFIX_attribute` VALUES (11, 3);
INSERT INTO `PREFIX_attribute` VALUES (12, 1);
INSERT INTO `PREFIX_attribute` VALUES (13, 1);
INSERT INTO `PREFIX_attribute` VALUES (14, 2);

INSERT INTO `PREFIX_attribute_lang` VALUES (1, 1, '2GB');
INSERT INTO `PREFIX_attribute_lang` VALUES (1, 2, '2Go');
INSERT INTO `PREFIX_attribute_lang` VALUES (2, 1, '4GB');
INSERT INTO `PREFIX_attribute_lang` VALUES (2, 2, '4Go');
INSERT INTO `PREFIX_attribute_lang` VALUES (3, 1, 'Metal');
INSERT INTO `PREFIX_attribute_lang` VALUES (3, 2, 'Metal');
INSERT INTO `PREFIX_attribute_lang` VALUES (4, 1, 'Blue');
INSERT INTO `PREFIX_attribute_lang` VALUES (4, 2, 'Bleu');
INSERT INTO `PREFIX_attribute_lang` VALUES (5, 1, 'Pink');
INSERT INTO `PREFIX_attribute_lang` VALUES (5, 2, 'Rose');
INSERT INTO `PREFIX_attribute_lang` VALUES (6, 1, 'Green');
INSERT INTO `PREFIX_attribute_lang` VALUES (6, 2, 'Vert');
INSERT INTO `PREFIX_attribute_lang` VALUES (7, 1, 'Orange');
INSERT INTO `PREFIX_attribute_lang` VALUES (7, 2, 'Orange');
INSERT INTO `PREFIX_attribute_lang` VALUES (8, 1, 'Optional 64GB solid-state drive');
INSERT INTO `PREFIX_attribute_lang` VALUES (8, 2, 'Disque dur SSD (solid-state drive) de 64 Go ');
INSERT INTO `PREFIX_attribute_lang` VALUES (9, 1, '80GB Parallel ATA Drive @ 4200 rpm');
INSERT INTO `PREFIX_attribute_lang` VALUES (9, 2, 'Disque dur PATA de 80 Go &agrave; 4 200 tr/min');
INSERT INTO `PREFIX_attribute_lang` VALUES (10, 1, '1.60GHz Intel Core 2 Duo');
INSERT INTO `PREFIX_attribute_lang` VALUES (10, 2, 'Intel Core 2 Duo &agrave; 1,6 GHz');
INSERT INTO `PREFIX_attribute_lang` VALUES (11, 1, '1.80GHz Intel Core 2 Duo');
INSERT INTO `PREFIX_attribute_lang` VALUES (11, 2, 'Intel Core 2 Duo &agrave; 1,8 GHz');
INSERT INTO `PREFIX_attribute_lang` VALUES (12, 1, '80GB: 20,000 Songs');
INSERT INTO `PREFIX_attribute_lang` VALUES (12, 2, '80 Go : 20 000 chansons');
INSERT INTO `PREFIX_attribute_lang` VALUES (13, 1, '160GB: 40,000 Songs');
INSERT INTO `PREFIX_attribute_lang` VALUES (13, 2, '160 Go : 40 000 chansons');
INSERT INTO `PREFIX_attribute_lang` VALUES (14, 2, 'Noir');
INSERT INTO `PREFIX_attribute_lang` VALUES (14, 1, 'Black');


INSERT INTO `PREFIX_product_attribute` VALUES (1, 4, 1, '', '', 0.00, 0.00, 22, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (2, 4, 1, '', '', 50.00, 0.00, 200, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (3, 2, 1, '', '', 0.00, 0.00, 40, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (4, 1, 1, '', '', 50.00, 0.00, 10, 0, 1);
INSERT INTO `PREFIX_product_attribute` VALUES (5, 3, 1, '', '', 0.00, 0.00, 31, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (6, 3, 1, '', '', 60.00, 0.00, 34, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (7, 6, 2, '', '', 0.00, 0.00, 10, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (8, 9, 2, '', '', 0.00, 0.00, 20, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (9, 5, 2, '', '', 0.00, 0.00, 30, 0, 1);
INSERT INTO `PREFIX_product_attribute` VALUES (10, 8, 2, '', '', 0.00, 0.00, 40, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (11, 7, 2, '', '', 0.00, 0.00, 32, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (12, 0, 5, '', '', 899.00, 0.00, 100, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (13, 0, 5, '', '', 0.00, 0.00, 99, 0, 1);
INSERT INTO `PREFIX_product_attribute` VALUES (14, 0, 5, '', '', 270.00, 0.00, 50, 0, 0);
INSERT INTO `PREFIX_product_attribute` VALUES (15, 0, 5, '', '', 1169.00, 0.00, 25, 0, 0);

INSERT INTO `PREFIX_product_attribute_combination` VALUES (1, 1);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (1, 3);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (1, 5);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (2, 2);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (2, 4);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (2, 6);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (3, 4);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (3, 9);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (4, 1);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (4, 2);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (4, 7);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (5, 5);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (5, 6);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (5, 10);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (6, 3);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (6, 8);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (7, 11);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (3, 12);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (9, 12);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (10, 12);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (3, 13);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (8, 13);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (10, 13);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (3, 14);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (9, 14);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (11, 14);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (3, 15);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (8, 15);
INSERT INTO `PREFIX_product_attribute_combination` VALUES (11, 15);

INSERT INTO `PREFIX_feature` (`id_feature`) VALUES (1);
INSERT INTO `PREFIX_feature` (`id_feature`) VALUES (2);
INSERT INTO `PREFIX_feature` (`id_feature`) VALUES (3);
INSERT INTO `PREFIX_feature` (`id_feature`) VALUES (4);
INSERT INTO `PREFIX_feature` (`id_feature`) VALUES (5);

INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (1, 1, 'Height');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (1, 2, 'Hauteur');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (2, 1, 'Width');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (2, 2, 'Largeur');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (3, 1, 'Depth');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (3, 2, 'Profondeur');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (4, 1, 'Weight');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (4, 2, 'Poids');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (5, 1, 'Headphone');
INSERT INTO `PREFIX_feature_lang` (`id_feature`, `id_lang`, `name`) VALUES (5, 2, 'Prise casque');

INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (1, 1, 11);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (1, 2, 15);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (2, 1, 12);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (2, 2, 16);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (3, 1, 14);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (3, 2, 18);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (4, 1, 13);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (4, 2, 17);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (5, 1, 10);
INSERT INTO `PREFIX_feature_product` (`id_feature`, `id_product`, `id_feature_value`) VALUES (5, 2, 10);

INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (11, 1, 1);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (15, 1, 1);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (12, 2, 1);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (16, 2, 1);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (14, 3, 1);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (18, 3, 1);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (13, 4, 1);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (17, 4, 1);

INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (9, 5, NULL);
INSERT INTO `PREFIX_feature_value` (`id_feature_value`, `id_feature`, `custom`) VALUES (10, 5, NULL);

INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (13, 1, '49,2 grammes');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (13, 2, '49,2 grammes');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (12, 2, '52,3 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (12, 1, '52,3 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (11, 2, '69,8 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (11, 1, '69,8 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (17, 2, '15,5 g');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (17, 1, '15,5 g');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (16, 2, '41,2 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (16, 1, '41,2 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (15, 2, '27,3 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (15, 1, '27,3 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (9, 1, 'Jack stereo');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (9, 2, 'Jack st&eacute;r&eacute;o');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (10, 1, 'Mini-jack stereo');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (10, 2, 'Mini-jack st&eacute;r&eacute;o');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (14, 1, '6,5 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (14, 2, '6,5 mm');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (18, 1, '10,5 mm (clip compris)');
INSERT INTO `PREFIX_feature_value_lang` (`id_feature_value`, `id_lang`, `value`) VALUES (18, 2, '10,5 mm (clip compris)');

INSERT INTO `PREFIX_image` VALUES (1, 1, 1, 1);
INSERT INTO `PREFIX_image` VALUES (2, 1, 2, 0);
INSERT INTO `PREFIX_image` VALUES (3, 1, 3, 0);
INSERT INTO `PREFIX_image` VALUES (4, 1, 4, 0);
INSERT INTO `PREFIX_image` VALUES (5, 2, 1, 1);
INSERT INTO `PREFIX_image` VALUES (6, 2, 2, 0);
INSERT INTO `PREFIX_image` VALUES (7, 2, 3, 0);
INSERT INTO `PREFIX_image` VALUES (8, 2, 4, 0);
INSERT INTO `PREFIX_image` VALUES (9, 2, 5, 0);
INSERT INTO `PREFIX_image` VALUES (10, 3, 1, 1);
INSERT INTO `PREFIX_image` VALUES (11, 3, 2, 0);
INSERT INTO `PREFIX_image` VALUES (12, 4, 1, 1);
INSERT INTO `PREFIX_image` VALUES (13, 4, 2, 0);
INSERT INTO `PREFIX_image` VALUES (14, 4, 3, 0);
INSERT INTO `PREFIX_image` VALUES (15, 5, 1, 1);
INSERT INTO `PREFIX_image` VALUES (16, 5, 2, 0);
INSERT INTO `PREFIX_image` VALUES (17, 5, 3, 0);
INSERT INTO `PREFIX_image` VALUES (18, 6, 4, 0);
INSERT INTO `PREFIX_image` VALUES (19, 6, 5, 0);
INSERT INTO `PREFIX_image` VALUES (20, 6, 1, 1);

INSERT INTO `PREFIX_image_lang` VALUES (1, 1, 'ipod-nano-alu');
INSERT INTO `PREFIX_image_lang` VALUES (1, 2, 'ipod-nano-alu');
INSERT INTO `PREFIX_image_lang` VALUES (2, 1, 'ipod-nano-green');
INSERT INTO `PREFIX_image_lang` VALUES (2, 2, 'ipod-nano-vert');
INSERT INTO `PREFIX_image_lang` VALUES (3, 1, 'ipod-nano-pink');
INSERT INTO `PREFIX_image_lang` VALUES (3, 2, 'ipod-nano-rose');
INSERT INTO `PREFIX_image_lang` VALUES (4, 1, 'ipod-nano-blue');
INSERT INTO `PREFIX_image_lang` VALUES (4, 2, 'ipod-nano-bleu');
INSERT INTO `PREFIX_image_lang` VALUES (5, 1, 'ipod-shuffle-metal');
INSERT INTO `PREFIX_image_lang` VALUES (5, 2, 'ipod-shuffle-metal');
INSERT INTO `PREFIX_image_lang` VALUES (6, 1, 'ipod-shuffle-blue');
INSERT INTO `PREFIX_image_lang` VALUES (6, 2, 'ipod-shuffle-bleu');
INSERT INTO `PREFIX_image_lang` VALUES (7, 1, 'ipod-shuffle-orange');
INSERT INTO `PREFIX_image_lang` VALUES (7, 2, 'ipod-shuffle-orange');
INSERT INTO `PREFIX_image_lang` VALUES (8, 1, 'ipod-shuffle-pink');
INSERT INTO `PREFIX_image_lang` VALUES (8, 2, 'ipod-shuffle-rose');
INSERT INTO `PREFIX_image_lang` VALUES (9, 1, 'ipod-shuffle-green');
INSERT INTO `PREFIX_image_lang` VALUES (9, 2, 'ipod-shuffle-vert');
INSERT INTO `PREFIX_image_lang` VALUES (10, 1, 'luxury-cover-for-ipod-video');
INSERT INTO `PREFIX_image_lang` VALUES (10, 2, 'housse-luxe-pour-ipod-video');
INSERT INTO `PREFIX_image_lang` VALUES (11, 1, 'cover');
INSERT INTO `PREFIX_image_lang` VALUES (11, 2, 'housse');
INSERT INTO `PREFIX_image_lang` VALUES (12, 1, 'myglove-ipod-nano');
INSERT INTO `PREFIX_image_lang` VALUES (12, 2, 'myglove-ipod-nano');
INSERT INTO `PREFIX_image_lang` VALUES (13, 1, 'myglove-ipod-nano');
INSERT INTO `PREFIX_image_lang` VALUES (13, 2, 'myglove-ipod-nano');
INSERT INTO `PREFIX_image_lang` VALUES (14, 1, 'myglove-ipod-nano');
INSERT INTO `PREFIX_image_lang` VALUES (14, 2, 'myglove-ipod-nano');
INSERT INTO `PREFIX_image_lang` VALUES (15, 1, 'MacBook Air');
INSERT INTO `PREFIX_image_lang` VALUES (15, 2, 'macbook-air-1');
INSERT INTO `PREFIX_image_lang` VALUES (16, 1, 'MacBook Air');
INSERT INTO `PREFIX_image_lang` VALUES (16, 2, 'macbook-air-2');
INSERT INTO `PREFIX_image_lang` VALUES (17, 1, 'MacBook Air');
INSERT INTO `PREFIX_image_lang` VALUES (17, 2, 'macbook-air-3');
INSERT INTO `PREFIX_image_lang` VALUES (18, 1, 'MacBook Air');
INSERT INTO `PREFIX_image_lang` VALUES (18, 2, 'macbook-air-4');
INSERT INTO `PREFIX_image_lang` VALUES (19, 1, 'MacBook Air');
INSERT INTO `PREFIX_image_lang` VALUES (19, 2, 'macbook-air-5');
INSERT INTO `PREFIX_image_lang` VALUES (20, 1, ' MacBook Air SuperDrive');
INSERT INTO `PREFIX_image_lang` VALUES (20, 2, 'superdrive-pour-macbook-air-1');
INSERT INTO `PREFIX_image_lang` VALUES (21, 1, ' MacBook Air SuperDrive');
INSERT INTO `PREFIX_image_lang` VALUES (21, 2, 'superdrive-pour-macbook-air-2');
INSERT INTO `PREFIX_image_lang` VALUES (22, 1, ' MacBook Air SuperDrive');
INSERT INTO `PREFIX_image_lang` VALUES (22, 2, 'superdrive-pour-macbook-air-3');

INSERT INTO `PREFIX_tag` VALUES (4, 1, 'nano');
INSERT INTO `PREFIX_tag` VALUES (3, 1, 'ipod');
INSERT INTO `PREFIX_tag` VALUES (5, 1, 'apple');
INSERT INTO `PREFIX_tag` VALUES (6, 2, 'ipod');
INSERT INTO `PREFIX_tag` VALUES (7, 2, 'nano');
INSERT INTO `PREFIX_tag` VALUES (8, 2, 'apple');
INSERT INTO `PREFIX_tag` VALUES (9, 1, 'luxury');
INSERT INTO `PREFIX_tag` VALUES (10, 1, 'cover');
INSERT INTO `PREFIX_tag` VALUES (11, 1, 'ipod');
INSERT INTO `PREFIX_tag` VALUES (12, 1, 'video');
INSERT INTO `PREFIX_tag` VALUES (13, 2, 'housse');
INSERT INTO `PREFIX_tag` VALUES (14, 2, 'ipod');
INSERT INTO `PREFIX_tag` VALUES (15, 2, 'video');
INSERT INTO `PREFIX_tag` VALUES (16, 2, 'luxe');
INSERT INTO `PREFIX_tag` VALUES (17, 1, 'shuffle');
INSERT INTO `PREFIX_tag` VALUES (18, 2, 'shuffle');
INSERT INTO `PREFIX_tag` VALUES (19, 2, 'macbook');
INSERT INTO `PREFIX_tag` VALUES (20, 2, 'macbookair');
INSERT INTO `PREFIX_tag` VALUES (21, 2, 'air');
INSERT INTO `PREFIX_tag` VALUES (22, 1, 'superdrive');

INSERT INTO `PREFIX_product_tag` VALUES (1, 2);
INSERT INTO `PREFIX_product_tag` VALUES (1, 6);
INSERT INTO `PREFIX_product_tag` VALUES (1, 7);
INSERT INTO `PREFIX_product_tag` VALUES (1, 8);
INSERT INTO `PREFIX_product_tag` VALUES (2, 6);
INSERT INTO `PREFIX_product_tag` VALUES (2, 18);
INSERT INTO `PREFIX_product_tag` VALUES (3, 13);
INSERT INTO `PREFIX_product_tag` VALUES (3, 14);
INSERT INTO `PREFIX_product_tag` VALUES (3, 15);
INSERT INTO `PREFIX_product_tag` VALUES (3, 16);
INSERT INTO `PREFIX_product_tag` VALUES (5, 8);
INSERT INTO `PREFIX_product_tag` VALUES (5, 19);
INSERT INTO `PREFIX_product_tag` VALUES (5, 20);
INSERT INTO `PREFIX_product_tag` VALUES (5, 21);
INSERT INTO `PREFIX_product_tag` VALUES (6, 5);
INSERT INTO `PREFIX_product_tag` VALUES (6, 22);

INSERT INTO `PREFIX_alias` (`alias`, `search`, `active`, `id_alias`) VALUES ('piod', 'ipod', 1, 4);
INSERT INTO `PREFIX_alias` (`alias`, `search`, `active`, `id_alias`) VALUES ('ipdo', 'ipod', 1, 3);
