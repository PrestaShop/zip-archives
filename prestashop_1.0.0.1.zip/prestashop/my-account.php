<?php

/* SSL Management */
$useSSL = true;

include(dirname(__FILE__).'/config/config.inc.php');
include(dirname(__FILE__).'/header.php');

if (!$cookie->isLogged())
    Tools::redirect('authentication.php?back=my-account.php');

$smarty->assign('voucherAllowed', intval(Configuration::get('PS_VOUCHERS')));
$smarty->display(_PS_THEME_DIR_.'my-account.tpl');

include(dirname(__FILE__).'/footer.php');

?>