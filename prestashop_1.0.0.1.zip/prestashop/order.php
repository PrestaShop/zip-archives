<?php

/* SSL Management */
$useSSL = true;

include_once(dirname(__FILE__).'/config/config.inc.php');
/* Step number is needed on some modules */
$step = intval(Tools::getValue('step'));
include_once(dirname(__FILE__).'/header.php');

$errors = array();

/* Class FreeOrder to use PaymentModule (abstract class, cannot be instancied) */
class	FreeOrder extends PaymentModule {}

/* If some products have disappear */
if (!$cart->checkQuantities())
{
	$step = 0;
	$errors[] = Tools::displayError('An item in your cart is no longer available, you cannot proceed with your order');
}

/* Check minimal account */
$orderTotal = $cart->getOrderTotal();

$orderTotalDefaultCurrency = Tools::convertPrice($orderTotal, Currency::getCurrency(intval(Configuration::get('PS_CURRENCY_DEFAULT'))));
$minimalPurchase = floatval(Configuration::get('PS_PURCHASE_MINIMUM'));
if ($orderTotalDefaultCurrency < $minimalPurchase)
{
	$step = 0;
	$errors[] = Tools::displayError('A minimum purchase total of').' '.Tools::displayPrice($minimalPurchase, Currency::getCurrency(intval($cart->id_currency))).
	' '.Tools::displayError('is required in order to validate your order');
}

if (!$cookie->isLogged() AND in_array($step, array(1, 2, 3)))
	Tools::redirect('authentication.php?back=order.php?step='.$step);

if ($cart->nbProducts())
{
	/* Manage discounts */
	if ((Tools::isSubmit('submitDiscount') OR isset($_GET['submitDiscount'])) AND Tools::getValue('discount_name'))
	{
		$discountName = Tools::getValue('discount_name');
		if (!Validate::isDiscountName($discountName))
			$errors[] = Tools::displayError('voucher name not valid');
		else
		{
			$discount = new Discount(intval(Discount::getIdByName($discountName)));
			if (is_object($discount) AND $discount->id)
			{
				if ($tmpError = $cart->checkDiscountValidity($discount, $cart->getDiscounts(), $cart->getOrderTotal(), $cart->getProducts(), true))
					$errors[] = $tmpError;
			}
			else
				$errors[] = Tools::displayError('voucher name not valid');
			if (!sizeof($errors))
			{
				$cart->addDiscount(intval($discount->id));
				Tools::redirect('order.php');
			}
			else
			{
				$smarty->assign(array(
					'errors' => $errors,
					'discount_name' => Tools::safeOutput($discountName)));
			}
		}
	}
	elseif (isset($_GET['deleteDiscount']) AND Validate::isUnsignedId($_GET['deleteDiscount']))
		$cart->deleteDiscount(intval($_GET['deleteDiscount']));

	/* Is there only virtual product in cart */
	if ($isVirtualCart = $cart->isVirtualCart())
		setNoCarrier();
	$smarty->assign('virtual_cart', $isVirtualCart);

	/* 4 steps to the order */
	switch (intval($step))
	{
		case 1:
			displayAddress();
			break;
		case 2:
			if(Tools::isSubmit('processAddress'))
				processAddress();
			autoStep(2);
			displayCarrier();
			break;
		case 3:
			if(Tools::isSubmit('processCarrier'))
				processCarrier();
			autoStep(3);
			checkFreeOrder();
			displayPayment();
			break;
		default:
			$smarty->assign('errors', $errors);
			displaySummary();
			break;
	}
}
else
{
	/* Default page */
	$smarty->assign('empty', 1);
	$smarty->display(_PS_THEME_DIR_.'shopping-cart.tpl');
}

include(dirname(__FILE__).'/footer.php');

/* Order process controller */
function autoStep($step)
{
	global $cart, $isVirtualCart;

	if ($step >= 2 AND (!$cart->id_address_delivery OR !$cart->id_address_invoice))
		Tools::redirect('order.php?step=1');
	$delivery = new Address(intval($cart->id_address_delivery));
	$invoice = new Address(intval($cart->id_address_invoice));
	if ($delivery->deleted OR $invoice->deleted)
	{
		if ($delivery->deleted)
			unset($cart->id_address_delivery);
		if ($invoice->deleted)
			unset($cart->id_address_invoice);
		Tools::redirect('order.php?step=1');
	}
	elseif ($step >= 3 AND !$cart->id_carrier AND !$isVirtualCart)
		Tools::redirect('order.php?step=2');
}

/* Bypass payment step if total is 0 */
function checkFreeOrder()
{
	global $cart;

	if ($cart->getOrderTotal() <= 0)
	{
		$order = new FreeOrder();
		$order->validateOrder(intval($cart->id), 2, 0, 'Free order');
		Tools::redirect('history.php');
	}
}

/**
 * Set id_carrier to 0 (no shipping price)
 *
 */
function setNoCarrier()
{
	global $cart;
	$cart->id_carrier = 0;
	$cart->update();
}

/*
 * Manage address
 */
function processAddress()
{
	global $cart, $smarty;
	$errors = array();
		
	if (!isset($_POST['id_address_delivery']) OR !Address::isCountryActiveById(intval($_POST['id_address_delivery'])))
		$errors[] = 'this address is not in a valid area';
	else
	{
		$cart->id_address_delivery = intval($_POST['id_address_delivery']);
		$cart->id_address_invoice = isset($_POST['same']) ? intval($_POST['id_address_delivery']) : intval($_POST['id_address_invoice']);
		$cart->update();
	
		if (isset($_POST['message']) AND !empty($_POST['message']))
		{
			if (!Validate::isMessage($_POST['message']))
				$errors[] = Tools::displayError('invalid message');
			elseif ($oldMessage = Message::getMessageByCartId(intval($cart->id)))
			{
				$message = new Message(intval($oldMessage['id_message']));
				$message->message = @htmlentities($_POST['message']);
				$message->update();
			}
			else
			{
				$message = new Message();
				$message->message = @htmlentities($_POST['message']);
				$message->id_cart = intval($cart->id);
				$message->id_customer = intval($cart->id_customer);
				$message->add();
			}
		}
	}
	if (sizeof($errors))
	{
		$smarty->assign('errors', $errors);
		displayAddress();
		include_once(dirname(__FILE__).'/footer.php');
		exit;
	}
}

/* Carrier step */
function processCarrier()
{
	global $cart, $smarty, $isVirtualCart, $orderTotal;
	
	$errors = array();

	$cart->recyclable = (isset($_POST['recyclable']) AND !empty($_POST['recyclable'])) ? 1 : 0;
	
	if (isset($_POST['gift']) AND !empty($_POST['gift']))
	{
	 	if (!Validate::isMessage($_POST['gift_message']))
			$errors[] = Tools::displayError('invalid gift message');
		else
		{
			$cart->gift = 1;
			$cart->gift_message = strip_tags($_POST['gift_message']);
		}
	}
	else
		$cart->gift = 0;

	$address = new Address(intval($cart->id_address_delivery));
	$country = new Country(intval($address->id_country));
	if (isset($_POST['id_carrier']) AND Validate::isInt($_POST['id_carrier']) AND sizeof(Carrier::checkCarrierZone(intval($_POST['id_carrier']), intval($country->id_zone))))
		$cart->id_carrier = intval($_POST['id_carrier']);
	elseif (!$isVirtualCart)
		$errors[] = Tools::displayError('invalid carrier or no carrier selected');

	$cart->update();
	
	if (sizeof($errors))
	{
		$smarty->assign('errors', $errors);
		displayCarrier();
		include(dirname(__FILE__).'/footer.php');
		exit;
	}
	$orderTotal = $cart->getOrderTotal();
}

/* Address step */
function displayAddress()
{
	global $smarty, $cookie, $cart;
	
	if (!Customer::getAddressesTotalById(intval($cookie->id_customer)))
		Tools::redirect('address.php?back=order.php?step=1');
	$customer = new Customer(intval($cookie->id_customer));
	if (is_object($customer) AND $customer->id)
		$smarty->assign('addresses', $customer->getAddresses(intval($cookie->id_lang)));
	if ($oldMessage = Message::getMessageByCartId(intval($cart->id)))
		$smarty->assign('oldMessage', Tools::safeOutput($oldMessage['message']));
	$smarty->assign('cart', $cart);

	$smarty->display(_PS_THEME_DIR_.'order-address.tpl');
}

/* Carrier step */
function displayCarrier()
{
	global $smarty, $cart, $cookie;

	$address = new Address(intval($cart->id_address_delivery));
	$country = new Country(intval($address->id_country));
	$result = Carrier::getCarriers(intval($cookie->id_lang), true, false, intval($country->id_zone));
	$resultsArray = array();
	foreach ($result AS $k => $row)
	{
		$row['name'] = (strval($row['name']) != '0' ? $row['name'] : Configuration::get('PS_SHOP_NAME'));
		$row['price'] = number_format($cart->getOrderShippingCost(intval($row['id_carrier'])), 2);
		$row['img'] = file_exists(_PS_SHIP_IMG_DIR_.intval($row['id_carrier']).'.jpg') ? _THEME_SHIP_DIR_.intval($row['id_carrier']).'.jpg' : '';
		$resultsArray[] = $row;
	}
	
	$smarty->assign(array(
		'checkedTOS' => $cookie->checkedTOS,
		'recyclablePackAllowed' => Configuration::get('PS_RECYCLABLE_PACK'),
		'giftAllowed' => Configuration::get('PS_GIFT_WRAPPING'),
		'conditions' => Configuration::get('PS_CONDITIONS'),
		'recyclable' => intval($cart->recyclable),
		'gift' => intval($cart->gift),
		'gift_message' => strip_tags($cart->gift_message),
		'carriers' => $resultsArray,
		'checked' => Validate::isUnsignedInt($cart->id_carrier) ? intval($cart->id_carrier) : intval(Configuration::get('PS_CARRIER_DEFAULT'))));
	$smarty->display(_PS_THEME_DIR_.'order-carrier.tpl');
}

/* Payment step */
function displayPayment()
{
	global $smarty, $cart, $currency, $cookie, $orderTotal;

	$cookie->checkedTOS = true;
	$smarty->assign(array(
		'HOOK_PAYMENT' => Module::hookExec('payment'),
		'total_price' => $orderTotal));
	$smarty->display(_PS_THEME_DIR_.'order-payment.tpl');
}

/* Confirmation step */
function displaySummary()
{
	global $smarty, $cart;
	
	if (file_exists(_PS_SHIP_IMG_DIR_.intval($cart->id_carrier).'.jpg'))
		$smarty->assign('carrierPicture', 1);
	$smarty->assign($cart->getSummaryDetails());
	$smarty->assign('voucherAllowed', Configuration::get('PS_VOUCHERS'));
	$smarty->display(_PS_THEME_DIR_.'shopping-cart.tpl');
}

?>