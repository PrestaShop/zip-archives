<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{feeder}prestashop>feeder_4dce2f12546b229088d3cc214c3c2f7d'] = 'Flux RSS de produits';
$_MODULE['<{feeder}prestashop>feeder_d70a880c7153de483014eababfa65f11'] = 'Générer un Flux RSS de produits';

?>