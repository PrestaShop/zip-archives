<?php

class Feeder extends Module
{
	private $_postErrors = array();
	
	public function __construct()
	{
		$this->name = 'feeder';
		$this->tab = 'Products';
		$this->version = 0.1;
		
		$this->_directory = dirname(__FILE__).'/../../';
		parent::__construct();
		
		/* The parent construct is required for translations */
		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('RSS products feed');
		$this->description = $this->l('Generate a RSS products feed');
	}
	
	function install()
	{
		if (!parent::install())
			return false;
		if (!$this->registerHook('header'))
			return false;
		return true;
	}
	
	function hookHeader($params)
	{
		global $smarty;
		
		$id_category = (Tools::getValue('id_category') ? '?id_category='.Tools::getValue('id_category') : '');
		$smarty->assign(array(
			'feedUrl' => 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/'.$this->name.'/rss.php'.$id_category,
		));
		return $this->display(__FILE__, 'feederHeader.tpl');
	}
}
?>