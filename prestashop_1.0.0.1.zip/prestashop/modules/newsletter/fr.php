<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{newsletter}prestashop>newsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Lettre d\'informations';
$_MODULE['<{newsletter}prestashop>newsletter_804a924e464fd21ed92f820224c4091d'] = 'Génère un fichier .CSV pour votre envoi d\'e-mails';
$_MODULE['<{newsletter}prestashop>newsletter_c3987e4cac14a8456515f0d200da04ee'] = 'Tous les pays';
$_MODULE['<{newsletter}prestashop>newsletter_fa01fd956e87307bce4c90a0de9b0437'] = 'Pays du client';
$_MODULE['<{newsletter}prestashop>newsletter_c0859b0a5241dff468da2a9a93c3284f'] = 'Opérer un filtre sur le pays des clients.';
$_MODULE['<{newsletter}prestashop>newsletter_f2ab5e3c58e5dbe15615f0060d036956'] = 'Inscrits lettre d\'info.';
$_MODULE['<{newsletter}prestashop>newsletter_583beb02b189c853ec3eeab6289379d3'] = 'Opérer un filtre sur les adhérants à la lettre d\'information.';
$_MODULE['<{newsletter}prestashop>newsletter_7e3a51a56ddd2846e21c33f05e0aea6f'] = 'Tous les clients';
$_MODULE['<{newsletter}prestashop>newsletter_39f7a3e2b56e9bfd753ba6325533a127'] = 'Inscrits';
$_MODULE['<{newsletter}prestashop>newsletter_011d8c5d94f729f013963d856cd78745'] = 'Non-inscrits';
$_MODULE['<{newsletter}prestashop>newsletter_793ee192a9124cd6f529460eef17d3e5'] = 'Opt-in';
$_MODULE['<{newsletter}prestashop>newsletter_68a845359abfecdfb5382003e94bcd34'] = 'Opérer un filtre sur les adhérants aux offre de partenaires.';
$_MODULE['<{newsletter}prestashop>newsletter_cbfbc813d2b33a2c264e878e31cf2cc0'] = 'Aucun client trouvé avec ces paramètres';
$_MODULE['<{newsletter}prestashop>newsletter_f8db2243069bf76570a084ea11d1c667'] = 'Le fichier .CSV a été créé avec succès';
$_MODULE['<{newsletter}prestashop>newsletter_55caa4828d4e935c2ba9f1558f1c4edd'] = 'clients trouvés';
$_MODULE['<{newsletter}prestashop>newsletter_48e3d5f66961b621c78f709afcd7d437'] = 'Télécharger le fichier';
$_MODULE['<{newsletter}prestashop>newsletter_d04e6ff103ecd59c2e24d89137fd772c'] = 'Erreur : impossible d\'écrire vers';
$_MODULE['<{newsletter}prestashop>newsletter_59cdd8834ac10abf9488b01f5c2dd21f'] = 'Exporter les inscrits à la newsletter';
$_MODULE['<{newsletter}prestashop>newsletter_f8a4ca012f7391148971485912ed4ab4'] = 'Génère un fichier CSV à partir des données clients';
$_MODULE['<{newsletter}prestashop>newsletter_dbb392a2dc9b38722e69f6032faea73e'] = 'Exporte un fichier CSV';
$_MODULE['<{newsletter}prestashop>newsletter_4713ef5f2d6fc1e8f088c850e696a04b'] = 'Export des clients';
$_MODULE['<{newsletter}prestashop>newsletter_70138a3753bc347e8ac5eeb5a87ec784'] = 'Génère un fichier CSV à partir des données clients';

?>