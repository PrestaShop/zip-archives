<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockinfos}prestashop>blockinfos_14e7895288c0eb3947753ac42df8074a'] = 'Bloc informations';
$_MODULE['<{blockinfos}prestashop>blockinfos_7570e5ca31c582e7a2d3ee759ccf5c86'] = 'Ajoute un bloc avec des liens vers vos pages d\'informations';
$_MODULE['<{blockinfos}prestashop>blockinfos_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informations';
$_MODULE['<{blockinfos}prestashop>blockinfos_065ab3a28ca4f16f55f103adc7d0226f'] = 'Livraison';
$_MODULE['<{blockinfos}prestashop>blockinfos_23e162ba6bf36c7560ebbc868d9e2552'] = 'Mentions légales';
$_MODULE['<{blockinfos}prestashop>blockinfos_229eb04083e06f419f9ac494329f957d'] = 'Conditions d\'utilisation';
$_MODULE['<{blockinfos}prestashop>blockinfos_cf23ee279844016288ea1c076638f3be'] = 'A propos...';

?>