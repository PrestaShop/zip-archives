<?php

class BlockInfos extends Module
{
    public function __construct()
    {
        $this->name = 'blockinfos';
        $this->tab = 'Blocks';
        $this->version = 1.0;

        parent::__construct();

        /* The parent construct is required for translations */
		$this->page = basename(__FILE__, '.php');
        $this->displayName = $this->l('Info block');
        $this->description = $this->l('Adds a block with several information links');
    }

    function install()
    {
        if (!parent::install() OR !$this->registerHook('leftColumn'))
			return false;
		return true;
    }

    function hookLeftColumn($params)
    {
		return $this->display(__FILE__, 'blockinfos.tpl');
	}
	
	function hookRightColumn($params)
	{
		return $this->hookLeftColumn($params);
	}
}

?>
