function setCurrency(id)
{
	$('form#setCurrency input#id_currency').val(id);
	$('form#setCurrency').submit();
}
