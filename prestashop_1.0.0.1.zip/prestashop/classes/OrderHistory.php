<?php

/**
  * Orders histories class, OrderHistory.php
  * Orders histories management
  * @category classes
  *
  * @author PrestaShop <support@prestashop.com>
  * @copyright PrestaShop
  * @license http://www.opensource.org/licenses/osl-3.0.php Open-source licence 3.0
  * @version 1.0
  *
  */

class		OrderHistory extends ObjectModel
{
	/** @var integer Order id */
	public 		$id_order;
	
	/** @var integer Order state id */
	public 		$id_order_state;
	
	/** @var integer Employee id for this history entry */
	public 		$id_employee;
	
	/** @var string Object creation date */
	public 		$date_add;

	/** @var string Object last modification date */
	public 		$date_upd;

	protected $tables = array ('order_history');
	
	protected	$fieldsRequired = array('id_order', 'id_order_state');
	protected	$fieldsValidate = array('id_order' => 'isUnsignedId', 'id_order_state' => 'isUnsignedId', 'id_employee' => 'isUnsignedId');

	protected 	$table = 'order_history';
	protected 	$identifier = 'id_order_history';

	public function getFields()
	{
		parent::validateFields();
		
		$fields['id_order'] = intval($this->id_order);
		$fields['id_order_state'] = intval($this->id_order_state);
		$fields['id_employee'] = intval($this->id_employee);
		$fields['date_add'] = pSQL($this->date_add);
				
		return $fields;
	}

	public function changeIdOrderState($new_order_state = NULL, $id_order)
	{
		if ($new_order_state != NULL)
		{
			Hook::updateOrderStatus(intval($new_order_state), intval($id_order));
			$this->id_order_state = intval($new_order_state);
		}
	}

	static public function getLastOrderState($id_order)
	{
		$result = Db::getInstance()->getRow('SELECT `id_order_state` FROM '._DB_PREFIX_.'order_history WHERE `id_order` = '.intval($id_order).' ORDER BY date_add DESC');
		if (!$result OR empty($result) OR !key_exists('id_order_state', $result))
			return false;
		return new OrderState(intval($result['id_order_state']));
	}

	public function addWithemail($autodate = true, $templateVars = false)
	{
		if (!parent::add($autodate))
			return false;

		$result = Db::getInstance()->getRow('
		SELECT osl.`template`, c.`lastname`, c.`firstname`, osl.`name` AS osname, c.`email`
		FROM `'._DB_PREFIX_.'order_history` oh
		LEFT JOIN `'._DB_PREFIX_.'orders` o ON oh.`id_order` = o.`id_order`
		LEFT JOIN `'._DB_PREFIX_.'customer` c ON o.`id_customer` = c.`id_customer`
		LEFT JOIN `'._DB_PREFIX_.'order_state` os ON oh.`id_order_state` = os.`id_order_state`
		LEFT JOIN `'._DB_PREFIX_.'order_state_lang` osl ON (os.`id_order_state` = osl.`id_order_state` AND osl.`id_lang` = o.`id_lang`)
		WHERE oh.`id_order_history` = '.intval($this->id).'
		AND os.`send_email` = 1');
	 	if (isset($result['template']) AND Validate::isEmail($result['email']))
		{
			$topic = $result['osname'];
			$data = array('{lastname}' => $result['lastname'], '{firstname}' => $result['firstname'], '{id_order}' => intval($this->id_order));
			if ($templateVars) $data = array_merge($data, $templateVars);
			$order = new Order(intval($this->id_order));
			if (Validate::isLoadedObject($order))
				Mail::Send(intval($order->id_lang), $result['template'], $topic, $data, $result['email'], $result['firstname'].' '.$result['lastname']);
		}
		return true;
	}
}

?>