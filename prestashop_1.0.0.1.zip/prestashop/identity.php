<?php

/* SSL Management */
$useSSL = true;

include(dirname(__FILE__).'/config/config.inc.php');
include(dirname(__FILE__).'/header.php');

if (!$cookie->isLogged())
	Tools::redirect('authentication.php?back=identity.php');

$customer = new Customer(intval($cookie->id_customer));

if (sizeof($_POST))
{
 	$exclusion = array('passwd', 'active', 'date_add', 'date_upd');
 	$fields = $customer->getFields();
	foreach ($fields AS $key => $value)
		if (!in_array($key, $exclusion))
			$customer->{$key} = key_exists($key, $_POST) ? trim($_POST[$key]) : 0;
}

if (isset($_POST['years']) AND isset($_POST['months']) AND isset($_POST['days']))
	$customer->birthday = intval($_POST['years']).'-'.intval($_POST['months']).'-'.intval($_POST['days']);

$errors = array();
if (Tools::isSubmit('submitIdentity'))
{
	if (!@checkdate(Tools::getValue('months'), Tools::getValue('days'), Tools::getValue('years')) AND 
	!(Tools::getValue('months') == '' AND Tools::getValue('days') == '' AND Tools::getValue('years') == ''))
		$errors[] = Tools::displayError('invalid birthday');
	else
	{
		$customer->birthday = (empty($_POST['years']) ? '' : intval($_POST['years']).'-'.intval($_POST['months']).'-'.intval($_POST['days']));
		if ($_POST['passwd'] != $_POST['confirmation'])
			$errors[] = Tools::displayError('password and confirmation do not match');
		else
			$errors = $customer->validateControler();
		if (!sizeof($errors))
		{
			$customer->lastname = Tools::strtoupper($customer->lastname);
		    $customer->firstname = Tools::strtolower($customer->firstname);
			if (Tools::getValue('passwd'))
				$cookie->passwd = $customer->passwd;
			
			if ($customer->update())
				Tools::redirect('my-account.php');
			$errors[] = Tools::displayError('impossible to update information');
		}
	}

	/* Clean POST values */
	foreach ($_POST AS $k => $val)
		$_POST[$k] = Tools::safeOutput($val);
}
else
	$_POST = array_map('stripslashes', $customer->getFields());

if ($customer->birthday)
	$birthday = split('-', $customer->birthday);
else
	$birthday = array('-', '-', '-');

/* Generate years, months and days */
$smarty->assign(array(
	'years' => Tools::dateYears(),
	'sl_year' => $birthday[0],
	'months' => Tools::dateMonths(),
	'sl_month' => $birthday[1],
	'days' => Tools::dateDays(),
	'sl_day' => $birthday[2],
	'errors' => $errors));

$smarty->display(_PS_THEME_DIR_.'identity.tpl');

include(dirname(__FILE__).'/footer.php');

?>