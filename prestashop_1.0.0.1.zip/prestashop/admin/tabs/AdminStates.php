<?php

/**
  * States tab for admin panel, AdminStates.php
  * @category admin
  *
  * @author PrestaShop <support@prestashop.com>
  * @copyright PrestaShop
  * @license http://www.opensource.org/licenses/osl-3.0.php Open-source licence 3.0
  * @version 1.0
  *
  */

include_once(dirname(__FILE__).'/../../classes/AdminTab.php');

class AdminStates extends AdminTab
{
	public function __construct()
	{
	 	$this->table = 'state';
	 	$this->className = 'State';
	 	$this->edit = true;
		
		$this->fieldsDisplay = array(
		'id_state' => array('title' => $this->l('ID'), 'align' => 'center', 'width' => 25),
		'name' => array('title' => $this->l('Name'), 'width' => 140),
		'iso_code' => array('title' => $this->l('ISO code'), 'align' => 'center', 'width' => 50));

		parent::__construct();
	}
	
	public function displayForm()
	{
		global $currentIndex, $cookie;
		
		$obj = $this->loadObject(true);
		
		echo '
		<form action="'.$currentIndex.'&submitAdd'.$this->table.'=1" method="post">
		'.($obj->id ? '<input type="hidden" name="id_'.$this->table.'" value="'.$obj->id.'" />' : '').'
			<fieldset class="width3"><legend><img src="../img/admin/world.gif" />'.$this->l('States').'</legend>
				<label>'.$this->l('Name:').' </label>
				<div class="margin-form">
					<input type="text" size="30" maxlength="5" name="name" value="'.$this->getFieldValue($obj, 'name').'" /> <sup>*</sup>
					<p style="clear: both;">'.$this->l('State name to display in addresses and on invoices').'</p>
				</div>
				<label>'.$this->l('ISO code:').' </label>
				<div class="margin-form">
					<input type="text" size="4" maxlength="2" name="iso_code" value="'.$this->getFieldValue($obj, 'iso_code').'" style="text-transform: uppercase;" /> <sup>*</sup>
					<p>'.$this->l('2-letter ISO code').' (<a href="http://simple.wikipedia.org/wiki/List_of_U.S._states" target="_blank">'.$this->l('official list here').'</a>)</p>
				</div>
				<label>'.$this->l('Country:').' </label>
				<div class="margin-form">
					<select name="id_country">';					
				$countries = Country::getCountries(intval($cookie->id_lang));
				foreach ($countries AS $country)
					echo '<option value="'.intval($country['id_country']).'"'.(($this->getFieldValue($obj, 'id_country') == $country['id_country']) ? ' selected="selected"' : '').'>'.$country['name'].'</option>';
				echo '
					</select>
					<p>'.$this->l('Country where state, region or city is located').'</p>
				</div>
				<label>'.$this->l('Status:').' </label>
				<div class="margin-form">
					<input type="radio" name="active" id="active_on" value="1" '.((!$obj->id OR $this->getFieldValue($obj, 'active')) ? 'checked="checked" ' : '').'/>
					<label class="t" for="active_on"> <img src="../img/admin/enabled.gif" alt="'.$this->l('Enabled').'" title="'.$this->l('Enabled').'" /></label>
					<input type="radio" name="active" id="active_off" value="0" '.((!$this->getFieldValue($obj, 'active') AND $obj->id) ? 'checked="checked" ' : '').'/>
					<label class="t" for="active_off"> <img src="../img/admin/disabled.gif" alt="'.$this->l('Disabled').'" title="'.$this->l('Disabled').'" /></label>
					<p>'.$this->l('Enabled or disabled').'</p>
				</div>				
				<div class="margin-form">
					<input type="submit" value="'.$this->l('   Save   ').'" name="submitAdd'.$this->table.'" class="button" />
				</div>
				<div class="small"><sup>*</sup> '.$this->l('Required field').'</div>
			</fieldset>
		</form>';
	}
}

?>