<?php

/**
  * Stats tab for admin panel, AdminStats.php
  * @category admin
  *
  * @author PrestaShop <support@prestashop.com>
  * @copyright PrestaShop
  * @license http://www.opensource.org/licenses/osl-3.0.php Open-source licence 3.0
  * @version 1.0
  *
  */

include_once(dirname(__FILE__).'/../../classes/AdminTab.php');

class AdminStats extends AdminTab
{

	public function postProcess()
	{
	}
	
	public function display()
	{
		echo $this->l('Coming soon');
	}
}

?>