<?php

include(dirname(__FILE__).'/../get-file.php');

?>