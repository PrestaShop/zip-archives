<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statshome}prestashop>statshome_ebfb30fd5243ea9bd08ad87767a48d02'] = 'Statistiques sur la page d\'accueil du panneau d\'administration';
$_MODULE['<{statshome}prestashop>statshome_28ddffd1b82be359f1e4923449bd005b'] = 'Affiche un petit bloc de statistiques sur votre page d\'accueil';
$_MODULE['<{statshome}prestashop>statshome_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistiques';
$_MODULE['<{statshome}prestashop>statshome_4eb156db59c5508589ac9c40f2d08979'] = 'de chiffre d\'affaire';
$_MODULE['<{statshome}prestashop>statshome_d53ddf87a983739d49e0da0c1fa64925'] = 'inscriptions';
$_MODULE['<{statshome}prestashop>statshome_563873d38950b841aebf89c3be1b1a35'] = 'inscription';
$_MODULE['<{statshome}prestashop>statshome_f8dd8e31c0fc28084d45bb517d6cfdc2'] = 'commandes passées';
$_MODULE['<{statshome}prestashop>statshome_8a6d9d2ea0d85d7399e44045975a05a0'] = 'commande passée';
$_MODULE['<{statshome}prestashop>statshome_f2fc2cd700fd9a2fe66ac16c35331b94'] = 'pages produit vues';
$_MODULE['<{statshome}prestashop>statshome_c6ec77de3e93b75196f91e2df9c567ca'] = 'page produit vue';
$_MODULE['<{statshome}prestashop>statshome_8ff922bbcd8ad41cdfc48d3c5163b2ab'] = 'Calendrier';
$_MODULE['<{statshome}prestashop>statshome_03727ac48595a24daed975559c944a44'] = 'Jour';
$_MODULE['<{statshome}prestashop>statshome_7cbb885aa1164b390a0bc050a64e1812'] = 'Mois';
$_MODULE['<{statshome}prestashop>statshome_537c66b24ef5c83b7382cdc3f34885f2'] = 'Année';
$_MODULE['<{statshome}prestashop>statshome_1e6d57e813355689e9c77e947d73ad8f'] = 'du';
$_MODULE['<{statshome}prestashop>statshome_33caa076f23f453dd4061726f3706325'] = 'au';
$_MODULE['<{statshome}prestashop>statshome_c9cc8cce247e49bae79f15173ce97354'] = 'Mettre à jour';
$_MODULE['<{statshome}prestashop>statshome_6799f652047c465ff8affc8c98cc4a74'] = 'Visiteurs actuellement connectés :';
