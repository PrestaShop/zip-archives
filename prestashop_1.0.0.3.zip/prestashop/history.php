<?php

/* SSL Management */
$useSSL = true;

include(dirname(__FILE__).'/config/config.inc.php');

//CSS ans JS file calls
$js_files = array(
	_THEME_JS_DIR_.'history.js'
);

include(dirname(__FILE__).'/header.php');

if (!$cookie->isLogged())
	Tools::redirect('authentication.php?back=history.php');

if ($orders = Order::getCustomerOrders(intval($cookie->id_customer)))
	foreach ($orders AS $key => $order)
		$orders[$key]['total_paid'] = Tools::displayPrice(floatval($order['total_paid']), new Currency(intval($order['id_currency'])), false, false);

$smarty->assign('orders', $orders);
$smarty->display(_PS_THEME_DIR_.'history.tpl');

include(dirname(__FILE__).'/footer.php');

?>