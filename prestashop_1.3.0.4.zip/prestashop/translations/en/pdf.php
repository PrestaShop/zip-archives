<?php

global $_LANGPDF;
$_LANGPDF = array();
$_LANGPDF['PDF_invoice15b57bef332e7e0327d89fe93711a954'] = 'An electronic version of this invoice is available in your account. To access it, log in to the';

?>