<?php

define('PS_ADMIN_DIR', getcwd());

include(PS_ADMIN_DIR.'/../get-file.php');

?>