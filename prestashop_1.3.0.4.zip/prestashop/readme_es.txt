PrestaShop <contact@prestashop.com>
Open-source licence 3.0 (http://www.opensource.org/licenses/osl-3.0.php)

VERSI�N: Prestashop 1.3RC1

PREPARACI�N
===========

Para instalar PrestaShop, necesita un servidor web remoto o en su ordenador (MAMP), con acceso a una base de datos como MySQL.
Tendr� acceso a phpMyAdmin para crear una base de datos y para indicar la informaci�n en la base de datos en el instalador.

Si no de acogida y no puede crear su tienda, le ofrecemos una tienda "llave en mano, que le permite crear su tienda en l�nea en menos de 10 minutos sin ning�n conocimiento t�cnico.
Le invitamos a visitar: 
	http://www.prestabox.com/

INSTALACI�N
============

Simplemente vaya a su directorio web y el uso PrestaShop instalador :-)

Si usted tiene cualquier error de PHP, tal vez usted no tiene PHP5 o necesitas activarlo en su web host.
Por favor, vaya a nuestro foro para encontrar la configuraci�n de la instalaci�n pre-(PHP 5, htaccess) para determinados servicios de hospedaje (1 & 1, gratis, Lycos, OVH, Infomaniak, Am�n, GoDaddy, etc.)

Ingl�s webhost ajustes espec�ficos:
	http://www.prestashop.com/forums/viewthread/2946/installation_configuration___upgrade/preinstallation_settings_php_5_htaccess_for_certain_hosting_services

Si usted no encuentra ninguna soluci�n para lanzar el instalador, por favor enviar en nuestro foro:
	http://www.prestashop.com/forums/viewforum/7/installation_configuration___upgrade

Siempre hay soluciones para sus problemas ;-)

DOCUMENTACI�N
=============

Para cualquier documentaci�n adicional (procedimientos), por favor lea nuestra wiki:
	http://www.prestashop.com/wiki/

FOROS
======

Usted puede tambi�n discute, ayudar y contribuir con la comunidad PrestaShop en nuestros foros:
	http://www.prestashop.com/forums/

Gracias por descargar y utilizar el comercio electr�nico PrestaShop soluci�n de c�digo abierto!

==========================
=     The PrestaTeam'    =
=   www.PrestaShop.com   =
==========================
