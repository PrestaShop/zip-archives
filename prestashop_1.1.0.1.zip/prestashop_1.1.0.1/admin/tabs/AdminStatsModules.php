<?php

/**
  * Statistics
  * @category stats
  *
  * @author Damien Metzger / Epitech
  * @copyright Epitech / PrestaShop
  * @license http://www.opensource.org/licenses/osl-3.0.php Open-source licence 3.0
  * @version 1.1
  */

include_once(dirname(__FILE__).'/AdminStatsTab.php');

class AdminStatsModules extends AdminStatsTab
{
}

?>
