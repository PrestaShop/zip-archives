tinyMCE.addI18n('ro.paste_dlg',{
text_title:"Folositi CTRL+v pentru a lipi in aceasta zona.",
text_linebreaks:"Pastreaza linii noi.",
word_title:"Folositi CTRL+v pentru a lipi in aceasta zona."
});