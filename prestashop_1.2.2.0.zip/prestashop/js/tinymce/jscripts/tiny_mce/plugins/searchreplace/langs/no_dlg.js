tinyMCE.addI18n('no.searchreplace_dlg',{
searchnext_desc:"S\u00F8k igjen",
notfound:"S\u00F8ket avsluttet. Fant ikke s\u00F8kestrengen.",
search_title:"S\u00F8k",
replace_title:"S\u00F8k/Erstatt",
allreplaced:"Alle forekomster av s\u00F8kestrengen er erstattet.",
findwhat:"Finn hva",
replacewith:"Erstatt med",
direction:"Retning",
up:"Oppover",
down:"Nedover",
mcase:"Skill mellom store og sm\u00E5 tegn",
findnext:"Finn neste",
replace:"Erstatt",
replaceall:"Erstatt alt"
});