tinyMCE.addI18n('it.searchreplace_dlg',{
searchnext_desc:"Trova successivo",
notfound:"Ricerca completata. Nessun risultato trovato.",
search_title:"Trova",
replace_title:"Trova/Sostituisci",
allreplaced:"Tutte le occorrenze del criterio di ricerca sono state sostituite.",
findwhat:"Trova:",
replacewith:"Sostituisci con:",
direction:"Direzione",
up:"Avanti",
down:"Indietro",
mcase:"Maiuscole/minuscole",
findnext:"Trova succ.",
replace:"Sostituisci",
replaceall:"Sost. tutto"
});