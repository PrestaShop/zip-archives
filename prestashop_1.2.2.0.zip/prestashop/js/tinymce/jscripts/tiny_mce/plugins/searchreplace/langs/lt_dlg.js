tinyMCE.addI18n('lt.searchreplace_dlg',{
searchnext_desc:"Ie\u0161koti dar kart\u0105",
notfound:"Paie\u0161ka baigta. Paie\u0161kos fraz\u0117 nerasta.",
search_title:"Ie\u0161koti",
replace_title:"Ie\u0161koti/Pakeisti",
allreplaced:"Visi paie\u0161kos fraz\u0117s pasikartojimai pakeisti.",
findwhat:"Ko ie\u0161koti",
replacewith:"Kuo pakeisti",
direction:"Kryptis",
up:"\u012E vir\u0161\u0173",
down:"\u012E apa\u010Di\u0105",
mcase:"Visi\u0161kas atitikimas",
findnext:"Ie\u0161koti sek.",
replace:"Pakeisti",
replaceall:"Pakeisti visus"
});