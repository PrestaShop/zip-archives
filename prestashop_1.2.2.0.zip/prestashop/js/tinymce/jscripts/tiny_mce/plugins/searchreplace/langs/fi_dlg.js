tinyMCE.addI18n('fi.searchreplace_dlg',{
searchnext_desc:"Etsi uudestaan",
notfound:"Haku on valmis. Haettua teksti\u00E4 ei l\u00F6ytynyt.",
search_title:"Haku",
replace_title:"Etsi ja korvaa",
allreplaced:"Kaikki l\u00F6ydetyt merkkijonot korvattiin.",
findwhat:"Etsit\u00E4\u00E4n",
replacewith:"Korvataan",
direction:"Suunta",
up:"Yl\u00F6s",
down:"Alas",
mcase:"Huomioi isot ja pienet kirjaimet",
findnext:"Etsi seuraavaa",
replace:"Korvaa",
replaceall:"Korvaa kaikki"
});