tinyMCE.addI18n('sk.searchreplace_dlg',{
searchnext_desc:"N\u00E1jdi znova",
notfound:"Vyh\u013Ead\u00E1vanie ukon\u010Den\u00E9. Re\u0165azec nemusel by\u0165 n\u00E1jden\u00FD.",
search_title:"N\u00E1jdi",
replace_title:"N\u00E1jdi/Nahra\u010F",
allreplaced:"V\u0161etky v\u00FDskyty re\u0165azca boly zmenen\u00E9.",
findwhat:"N\u00E1jdi v\u00FDraz",
replacewith:"Nahra\u010F s",
direction:"Smer",
up:"Nahor",
down:"Dolu",
mcase:"Presn\u00E1 zhoda",
findnext:"N\u00E1jdi \u010Fal\u0161\u00ED",
replace:"Nahra\u010F",
replaceall:"Nahradi\u0165 v\u0161etko"
});